# Animazioni Combat — istruzioni di wiring finale

## Stato

Questa build include il sistema di animazioni di combattimento **quasi** completo:

- ✅ Il model `BattleRuntime` ha `animationTick: Int` e `animationEvent: AnimationEvent`
- ✅ Il `GameViewModel` incrementa il tick e setta l'evento corretto in:
  - `basicAttack()` → PLAYER_HIT / PLAYER_CRIT / PLAYER_PERFECT
  - `useSkill()` → PLAYER_ULTIMATE se ultimate, PLAYER_PERFECT / PLAYER_HIT altrimenti
  - `resolveEnemyAttack()` → PLAYER_HIT (è il player che prende)
  - `dodge()` → ENEMY_DODGE se perfect/good
- ✅ `ui/BattleAnimations.kt` definisce 3 helper composable pronti all'uso:
  - `rememberScreenShake(tickKey, event)` → Pair(dx, dy) in dp
  - `PerfectFlashOverlay(tickKey, event)` → overlay fullscreen
  - `rememberEnemyHitPulse(tickKey, event)` → scale factor
- ❌ **`GameApp.kt` non chiama ancora questi helper.** Il gioco compila e gira, ma le animazioni nuove non si vedono finché non applichi i 3 edit sotto.

Il progetto compila comunque perché i campi hanno default sicuri (`0` e `NONE`) e non impattano il resto della logica.

---

## I 3 edit da applicare in `app/src/main/java/com/genspark/chronosshatter/ui/GameApp.kt`

### Edit 1 — dichiara gli animation state in `BattleScreen`

Cerca il commento `// TODO ANIM` (intorno a riga 217) e scommenta la riga. Il blocco deve diventare:

```kotlin
val enemy = battle.enemy

val (shakeX, shakeY) = rememberScreenShake(battle.animationTick, battle.animationEvent)
val enemyPulse = rememberEnemyHitPulse(battle.animationTick, battle.animationEvent)

LaunchedEffect(battle.enemy, battle.battleResolved) {
```

### Edit 2 — applica shake al Box root e aggiungi il flash overlay

Il `Box` root della BattleScreen (quello subito dopo il blocco `enragePulse`) deve diventare così:

```kotlin
Box(
    modifier = Modifier
        .fillMaxSize()
        .background(gradientBackground(if (battle.enemyEnraged) "#EF4444" else skin.npcAccentHex))
        .graphicsLayer {
            translationX = shakeX
            translationY = shakeY
        }
) {
    // ...tutto il contenuto esistente del Box resta com'è...

    // Floating overlay message (già esistente)
    FloatingOverlay(battle.overlayMessage, battle.overlayIsPositive)

    // ⬇ AGGIUNGI QUESTA RIGA appena prima della chiusura del Box:
    PerfectFlashOverlay(battle.animationTick, battle.animationEvent)
}
```

Import da aggiungere in testa al file se non c'è già:
```kotlin
import androidx.compose.ui.graphics.graphicsLayer
```

### Edit 3 — applica il pulse alla `EnemyCard`

Trova la chiamata `enemy?.let { EnemyCard(uiState, battle.enemyEnraged) }` e sostituiscila con:

```kotlin
enemy?.let {
    Box(modifier = Modifier.graphicsLayer { scaleX = enemyPulse; scaleY = enemyPulse }) {
        EnemyCard(uiState, battle.enemyEnraged)
    }
}
```

---

## Risultato atteso dopo i 3 edit

- **Hit normale** → shake leggero (~7dp, 220ms)
- **Crit** → shake medio + scale pulse della enemy card + flash rosso-chiaro
- **Perfect** → shake medio + flash bianco pieno schermo (260ms)
- **Ultimate** → shake forte (18dp, 420ms) + flash oro
- **Perfect dodge** → flash azzurro breve (240ms)
- **Player colpito** → shake leggero rosso

## Test manuale rapido

1. Apri `res/values/strings.xml` e verifica `app_name`.
2. Avvia in Android Studio su un emulatore API 26+.
3. Menu → GIOCA → attacca al centro della timing bar: dovresti vedere il flash bianco e lo shake.
4. Usa Chrono Burst quando carico: flash oro + shake forte.

## Se qualcosa non compila dopo i tuoi edit

Controlla che l'import `import com.genspark.chronosshatter.model.AnimationEvent` sia presente in `GameApp.kt` (serve per il tipo dell'enum, Kotlin a volte non lo auto-importa in Compose).
