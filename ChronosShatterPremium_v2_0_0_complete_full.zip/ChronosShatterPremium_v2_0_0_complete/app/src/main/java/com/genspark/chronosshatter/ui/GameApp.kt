@file:OptIn(
    androidx.compose.foundation.layout.ExperimentalLayoutApi::class,
    androidx.compose.foundation.ExperimentalFoundationApi::class,
)

package com.genspark.chronosshatter.ui

import android.app.Activity
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Upgrade
import androidx.compose.material3.Badge
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import com.genspark.chronosshatter.model.FloatingDamage
import com.genspark.chronosshatter.model.UpgradeStat
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.key
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.genspark.chronosshatter.data.GameCatalog
import com.genspark.chronosshatter.model.DailyChallenge
import com.genspark.chronosshatter.model.DialogueChoice
import com.genspark.chronosshatter.model.EnemyBehavior
import com.genspark.chronosshatter.model.GameUiState
import com.genspark.chronosshatter.model.Screen
import com.genspark.chronosshatter.model.SkillType
import com.genspark.chronosshatter.viewmodel.GameViewModel
import kotlinx.coroutines.delay

@Composable
fun GameApp(
    viewModel: GameViewModel,
    activity: Activity,
    onPremiumClick: () -> Unit,
) {
    val uiState = viewModel.uiState
    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF090D18)) {
        when (uiState.screen) {
            Screen.ONBOARDING -> OnboardingScreen(onFinish = { viewModel.completeOnboarding() })
            Screen.MENU    -> MainMenuScreen(uiState, viewModel, onPremiumClick)
            Screen.BATTLE  -> BattleScreen(uiState, viewModel, activity)
            Screen.SHOP    -> ShopScreen(uiState, viewModel, onPremiumClick)
            Screen.UPGRADE -> UpgradeScreen(uiState, viewModel)
            Screen.CREDITS -> CreditsScreen(viewModel)
            Screen.SETTINGS -> SettingsScreen(uiState, viewModel)
        }
    }
}

@Composable
private fun MainMenuScreen(uiState: GameUiState, viewModel: GameViewModel, onPremiumClick: () -> Unit) {
    val skin = remember(uiState.progress.equippedSkinId) {
        GameCatalog.skins.first { it.id == uiState.progress.equippedSkinId }
    }
    val infiniteTransition = rememberInfiniteTransition(label = "menu_pulse")
    val titlePulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        label = "title",
        animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradientBackground(skin.accentHex))
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "⚔ CHRONOS SHATTER",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.scale(titlePulse),
                    textAlign = TextAlign.Center,
                )
                Text(
                    text = "PIEGA IL TEMPO. DISTRUGGI IL TIRANTE.",
                    color = parseColor(skin.accentHex),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                )
            }
        }

        ChapterCard(uiState)
        StatBanner(uiState, skin.accentHex)
        if (uiState.todaysChallenges.isNotEmpty()) {
            DailyChallengesCard(uiState, viewModel)
        }
        ProgressLoopCard()

        if (uiState.progress.bestStage > 0) {
            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x33F59E0B))) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("🏆 Stage Massimo", color = Color(0xFFFDE68A), fontWeight = FontWeight.Bold)
                    Text("Stage ${uiState.progress.bestStage}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                }
            }
        }

        MenuButton("▶  GIOCA", Icons.Default.PlayArrow, color = parseColor(skin.accentHex)) { viewModel.startRun() }
        // Upgrade button — mostra badge se ci sono punti disponibili
        Box {
            MenuButton("⬆  Upgrade Eroe", Icons.Default.AutoAwesome, color = Color(0xFF10B981)) {
                viewModel.navigate(Screen.UPGRADE)
            }
            if (uiState.progress.upgradePoints > 0) {
                Badge(
                    modifier = Modifier.align(Alignment.TopEnd).padding(end = 8.dp, top = 4.dp),
                    containerColor = Color(0xFFEF4444),
                ) { Text("${uiState.progress.upgradePoints}", color = Color.White, fontSize = 11.sp) }
            }
        }
        MenuButton("🛒  Shop Skin", Icons.Default.ShoppingCart) { viewModel.navigate(Screen.SHOP) }
        MenuButton("⚙  Impostazioni", Icons.Default.Settings) { viewModel.navigate(Screen.SETTINGS) }
        MenuButton("★  Crediti", Icons.Default.Star) { viewModel.navigate(Screen.CREDITS) }

        if (!uiState.progress.premium) {
            PremiumCard(uiState, onPremiumClick)
        } else {
            ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x33F59E0B))) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.WorkspacePremium, null, tint = Color(0xFFFDE68A))
                    Spacer(Modifier.width(8.dp))
                    Text("✨ PREMIUM ATTIVO — no ads, revive gratis, skin esclusiva", color = Color(0xFFFDE68A), fontWeight = FontWeight.Bold)
                }
            }
        }

        UpgradePanel(uiState, viewModel)

        Text(
            text = uiState.globalMessage,
            color = Color(0xFFA5B4FC),
            style = MaterialTheme.typography.bodyMedium,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun BattleScreen(uiState: GameUiState, viewModel: GameViewModel, activity: Activity) {
    val battle = uiState.battle
    val skin = remember(uiState.progress.equippedSkinId) {
        GameCatalog.skins.first { it.id == uiState.progress.equippedSkinId }
    }
    val enemy = battle.enemy
    val density = LocalDensity.current
    val (shakeXDp, shakeYDp) = rememberScreenShake(battle.animationTick, battle.animationEvent)
    val shakeX = with(density) { shakeXDp.dp.toPx() }
    val shakeY = with(density) { shakeYDp.dp.toPx() }
    val enemyPulse = rememberEnemyHitPulse(battle.animationTick, battle.animationEvent)

    LaunchedEffect(battle.enemy, battle.battleResolved) {
        while (battle.enemy != null && !battle.battleResolved) {
            delay(16)
            viewModel.updateTiming()
        }
    }

    LaunchedEffect(battle.enemyIntentStartedAt) {
        val intent = battle.enemyIntent ?: return@LaunchedEffect
        delay(intent.telegraphMs)
        if (viewModel.uiState.battle.enemyIntent != null) viewModel.resolveEnemyAttack()
    }

    val enragePulse = rememberInfiniteTransition(label = "enrage")
    val enrageAlpha by enragePulse.animateFloat(
        initialValue = 0f,
        targetValue = if (battle.enemyEnraged) 0.15f else 0f,
        label = "enrage_alpha",
        animationSpec = infiniteRepeatable(tween(500), RepeatMode.Reverse),
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradientBackground(if (battle.enemyEnraged) "#EF4444" else skin.npcAccentHex))
            .graphicsLayer {
                translationX = shakeX
                translationY = shakeY
            },
    ) {
        if (battle.enemyEnraged) {
            Box(Modifier.fillMaxSize().background(Color(0x33EF4444).copy(alpha = enrageAlpha)))
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("Stage ${battle.stage} • ${stageChapterTitle(battle.stage)}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text(battle.encounterLabel, color = Color(0xFF93C5FD), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    battle.activeBuffLabel?.let {
                        Text("✦ $it", color = Color(0xFFA78BFA), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("💰 ${uiState.progress.coins}", color = Color(0xFFFDE68A), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Lv ${uiState.progress.level}", color = Color(0xFF94A3B8), fontSize = 12.sp)
                }
            }

            StatusBar("❤ HP", battle.playerHp, uiState.progress.maxHp, Color(0xFF22C55E))
            StatusBar("⚡ EN", battle.playerEnergy, uiState.progress.maxEnergy, Color(0xFF38BDF8))
            if (battle.playerShield > 0) {
                Text("🛡 Scudo: ${battle.playerShield}", color = Color(0xFFBFDBFE), fontWeight = FontWeight.Bold)
            }
            UltimateBar(battle.ultimateCharge, uiState.progress.maxUltimateCharge)
            StatusEffectRow(uiState)

            AnimatedVisibility(visible = battle.comboCount >= 2) {
                ComboDisplay(battle.comboCount, battle.comboMultiplier)
            }

            AnimatedVisibility(
                visible = battle.showBossIntro,
                enter = scaleIn() + fadeIn(),
                exit = scaleOut() + fadeOut(),
            ) {
                BossIntroCard(enemy, viewModel)
            }

            enemy?.let { EnemyCard(uiState, battle.enemyEnraged, enemyPulse) }

            AnimatedVisibility(visible = battle.pendingDialogue != null) {
                DialogueCard(
                    speaker = battle.pendingDialogue?.speaker.orEmpty(),
                    line = battle.pendingDialogue?.line.orEmpty(),
                    choices = battle.pendingDialogue?.choices.orEmpty(),
                    onChoice = viewModel::resolveDialogue,
                )
            }

            TimingBar(battle.timingCursor, battle.lastTimingLabel, battle.enemyEnraged, battle.timingSlowTurns > 0)

            AnimatedVisibility(visible = battle.enemyIntent != null) {
                battle.enemyIntent?.let { intent ->
                    val intentColor = when {
                        intent.speedTag == "FULMINEO" || intent.speedTag == "DEVASTANTE" -> Color(0xAA7F1D1D)
                        else -> Color(0xAA78350F)
                    }
                    Card(colors = CardDefaults.cardColors(containerColor = intentColor)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("⚠ ${intent.label}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                                Text(intent.speedTag, color = Color(0xFFFCA5A5), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Text("Danno previsto: ${intent.damage}${if (intent.energyDrain > 0) "  -${intent.energyDrain} EN" else ""}", color = Color(0xFFFECACA))
                            Button(
                                onClick = { viewModel.dodge() },
                                enabled = battle.dodgeAttemptsLeft > 0,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Text(if (battle.dodgeAttemptsLeft > 0) "⚡ SCHIVA" else "Nessuna schivata rimasta", fontWeight = FontWeight.Bold)
                            }
                            Text("PERFECT/GOOD = evade + counter • OK = graze • MISS = quasi pieno danno", color = Color(0xFFFED7AA), fontSize = 11.sp)
                        }
                    }
                }
            }

            SkillPanel(uiState, viewModel)

            Button(
                onClick = { viewModel.basicAttack() },
                enabled = battle.pendingDialogue == null && battle.enemyIntent == null && !battle.battleResolved && !battle.showBossIntro,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = ButtonDefaults.buttonColors(containerColor = parseColor(skin.accentHex)),
            ) {
                Text("⚔ ATTACCA", fontWeight = FontWeight.Black, fontSize = 17.sp)
            }

            BattleLog(uiState)

            if (battle.battleResolved) {
                ResultCard(uiState, viewModel, activity)
            }
        }

        PerfectFlashOverlay(battle.animationTick, battle.animationEvent)
        FloatingOverlay(battle.overlayMessage, battle.overlayIsPositive)
        // Floating damage numbers — spawned by ViewModel on each hit
        FloatingDamageOverlay(
            floatingDamages = battle.floatingDamages,
            onRemove = viewModel::removeFloatingDamage,
        )
    }
}

@Composable
private fun ShopScreen(uiState: GameUiState, viewModel: GameViewModel, onPremiumClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D1117))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("🛒 Skin Shop", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black)
            OutlinedButton(onClick = { viewModel.navigate(Screen.MENU) }) { Text("← Menu") }
        }
        ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x44FDE68A))) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("💰 Coin disponibili", color = Color(0xFFFDE68A))
                Text("${uiState.progress.coins}", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
            }
        }
        Text(
            "Skin vendibili per personaggio e palette NPC, con micro-bonus non pay-to-win. ${uiState.shopMessage}",
            color = Color(0xFFD1D5DB),
        )
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(GameCatalog.skins) { skin ->
                val owned = uiState.progress.ownedSkinIds.contains(skin.id)
                val equipped = uiState.progress.equippedSkinId == skin.id
                val accentC = parseColor(skin.accentHex)
                val npcColor = parseColor(skin.npcAccentHex)
                ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = accentC.copy(alpha = if (equipped) 0.35f else 0.18f))) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            ColorSwatch(accentC, equipped)
                            ColorSwatch(npcColor, false)
                            Column(Modifier.weight(1f)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(skin.name, color = Color.White, fontWeight = FontWeight.Black)
                                    RarityBadge(skin.rarityLabel)
                                }
                                Text(skin.description, color = Color(0xFFE5E7EB), fontSize = 13.sp)
                                Text("Hero Accent + NPC Accent inclusi", color = Color(0xFFBFDBFE), fontSize = 11.sp)
                            }
                        }
                        if (!skin.premiumOnly) {
                            Text(
                                "Prezzo: ${skin.price} coin  |  crit +${"%.0f".format(skin.bonusCrit * 100)}%  |  reward +${skin.bonusCoinsPercent}%",
                                color = Color(0xFFC7D2FE),
                                fontSize = 12.sp,
                            )
                        } else {
                            Text("🌟 ESCLUSIVA PREMIUM — Richiede acquisto Premium", color = Color(0xFFFDE68A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            when {
                                equipped -> Button(onClick = {}, enabled = false) { Text("✓ Equipaggiata") }
                                owned -> Button(onClick = { viewModel.equipSkin(skin.id) }) { Text("Equip") }
                                skin.premiumOnly && !uiState.progress.premium -> OutlinedButton(onClick = onPremiumClick) { Text("⭐ Vai Premium") }
                                else -> Button(onClick = { viewModel.buySkin(skin.id) }) { Text("Compra") }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CreditsScreen(viewModel: GameViewModel) {
    val uiState = viewModel.uiState
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("★ Crediti", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            OutlinedButton(onClick = { viewModel.navigate(Screen.MENU) }) { Text("← Menu") }
        }
        // Player stats card
        ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x331D4ED8))) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("📊 Le Tue Statistiche", color = Color.White, fontWeight = FontWeight.Black)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallStat("Lv", uiState.progress.level.toString())
                    SmallStat("Best", "Stage ${uiState.progress.bestStage}")
                    SmallStat("Run", uiState.progress.runsPlayed.toString())
                    SmallStat("Kills", uiState.progress.totalEnemiesDefeated.toString())
                    SmallStat("Coin", uiState.progress.coins.toString())
                    SmallStat("ATK", uiState.progress.attack.toString())
                }
            }
        }
        CreditItem("⚔ Combat System", "Timing PERFECT/GOOD/OK/MISS, dodge attivo, bleed, stun, slow, combo e kill streak.")
        CreditItem("🌀 Ultimate System", "Barra Ultimate con Chrono Burst e 12 skill totali, carica progressiva e payoff devastante.")
        CreditItem("💰 Economia", "Coin, daily challenges, rewarded revive/coin, interstitial bilanciati, premium no-ads e skin.")
        CreditItem("🎭 Dialoghi", "10 dialoghi ramificati con conseguenze reali su skill, skin, HP, buff e reward.")
        CreditItem("👾 Roster Nemici", "20 nemici con archetipi distinti (Aggressive, Fast, Defensive, Trickster, Berserk, Boss).")
        CreditItem("🎨 Skin Shop", "14 skin con rarità STARTER/RARE/EPIC/LEGENDARY/MYTHIC e micro-bonus non pay-to-win.")
        CreditItem("📅 Daily Challenges", "9 sfide giornaliere a rotazione: coin reward, progressione continua e motivation loop.")
        CreditItem("🧬 Legacy Fusion", "Concept, skin e reference del progetto web Chronos originale inclusi nel pacchetto migliorato.")
        CreditItem("🎨 UI Mobile", "HUD responsive, timing bar adattiva, 6 capitoli, feedback visivo/audio/haptic.")
        Text("v1.4.0 — Build premium migliorata, con fusion pack legacy incluso e pronta per QA finale / Play Store listing.", color = Color(0xFFD1D5DB), fontSize = 13.sp)
    }
}

@Composable
private fun SettingsScreen(uiState: GameUiState, viewModel: GameViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF020617))
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("⚙ Impostazioni", color = Color.White, style = MaterialTheme.typography.headlineMedium)
            OutlinedButton(onClick = { viewModel.navigate(Screen.MENU) }) { Text("← Menu") }
        }
        SettingToggle("🔊 Audio FX", uiState.progress.audioEnabled, viewModel::toggleAudio)
        SettingToggle("📳 Haptics", uiState.progress.hapticsEnabled, viewModel::toggleHaptics)
        if (!uiState.progress.premium) {
            SettingToggle("📢 Ads standard", uiState.progress.adsEnabled, viewModel::toggleAds)
        }
        Text("Il Premium disattiva automaticamente gli ads e sblocca la skin Oracle Leggendaria.", color = Color(0xFFCBD5E1), fontSize = 13.sp)
    }
}

@Composable
private fun ChapterCard(uiState: GameUiState) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x332563EB))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("📖 Progressione Capitolo", color = Color.White, fontWeight = FontWeight.Bold)
            Text(stageChapterTitle(uiState.progress.stageReached), color = Color(0xFFBFDBFE), fontWeight = FontWeight.Black, fontSize = 20.sp)
            Text(stageChapterSubtitle(uiState.progress.stageReached), color = Color(0xFFCBD5E1), fontSize = 13.sp)
        }
    }
}

@Composable
private fun ProgressLoopCard() {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x2210B981))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("🔁 Gameplay Loop", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Combat → Rewards → Upgrade → Next Stage", color = Color(0xFF86EFAC), fontWeight = FontWeight.Black)
            Text("Sessioni brevi, reward veloci, sblocchi continui di skill e skin.", color = Color(0xFFD1FAE5), fontSize = 13.sp)
        }
    }
}

@Composable
private fun StatBanner(uiState: GameUiState, accentHex: String) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x441E293B))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Profilo", color = Color.White, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SmallStat("Lv", uiState.progress.level.toString())
                SmallStat("ATK", uiState.progress.attack.toString())
                SmallStat("DEF", uiState.progress.defense.toString())
                SmallStat("Coin", uiState.progress.coins.toString())
                SmallStat("Run", uiState.progress.runsPlayed.toString())
                SmallStat("Kills", uiState.progress.totalEnemiesDefeated.toString())
            }
            Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text("EXP ${uiState.progress.exp}/${uiState.progress.expToNext}", color = Color(0xFF94A3B8), fontSize = 12.sp)
                LinearProgressIndicator(
                    progress = { (uiState.progress.exp.toFloat() / uiState.progress.expToNext.toFloat()).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(10.dp)),
                    color = parseColor(accentHex),
                    trackColor = Color(0xFF334155),
                )
            }
        }
    }
}

@Composable
private fun ComboDisplay(combo: Int, multiplier: Float) {
    val infiniteTransition = rememberInfiniteTransition(label = "combo")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        label = "cs",
        animationSpec = infiniteRepeatable(tween(300), RepeatMode.Reverse),
    )
    val comboColor = when {
        combo >= 8 -> Color(0xFFEF4444)
        combo >= 5 -> Color(0xFFF59E0B)
        else -> Color(0xFF22C55E)
    }
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = comboColor.copy(alpha = 0.2f))) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = "${if (combo >= 8) "🔥" else "⚡"} COMBO ×$combo",
                color = comboColor,
                fontWeight = FontWeight.Black,
                fontSize = if (combo >= 5) 20.sp else 16.sp,
                modifier = Modifier.scale(if (combo >= 5) scale else 1f),
            )
            Text(
                text = "+${"%.0f".format((multiplier - 1f) * 100)}% danno",
                color = comboColor.copy(alpha = 0.8f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
            )
        }
    }
}

@Composable
private fun UltimateBar(charge: Int, max: Int) {
    val filled = charge >= max
    val barColor = if (filled) Color(0xFFEF4444) else Color(0xFF8B5CF6)
    val infiniteTransition = rememberInfiniteTransition(label = "ult")
    val alpha by infiniteTransition.animateFloat(
        initialValue = if (filled) 0.6f else 1f,
        targetValue = 1f,
        label = "ua",
        animationSpec = infiniteRepeatable(tween(600), RepeatMode.Reverse),
    )
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(
                if (filled) "🌀 ULTIMATE PRONTO!" else "🌀 Ultimate ${charge}/${max}",
                color = if (filled) barColor else Color(0xFF94A3B8),
                fontSize = 12.sp,
                fontWeight = if (filled) FontWeight.Black else FontWeight.Normal,
                modifier = Modifier.alpha(alpha),
            )
        }
        LinearProgressIndicator(
            progress = { (charge.toFloat() / max.toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(10.dp)),
            color = barColor,
            trackColor = Color(0xFF1E293B),
        )
    }
}

@Composable
private fun StatusEffectRow(uiState: GameUiState) {
    val battle = uiState.battle
    val chips = buildList {
        if (battle.enemyBleedTurns > 0) add("🩸 Bleed ${battle.enemyBleedTurns}T")
        if (battle.enemyStunTurns > 0) add("🧊 Stun ${battle.enemyStunTurns}T")
        if (battle.timingSlowTurns > 0) add("⏳ Slow ${battle.timingSlowTurns}T")
        if (battle.perfectStreak > 1) add("⭐ Perfect Streak ${battle.perfectStreak}")
    }
    if (chips.isEmpty()) return
    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        chips.forEach { chip ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0x33233455))) {
                Text(chip, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
            }
        }
    }
}

@Composable
private fun BossIntroCard(enemy: com.genspark.chronosshatter.model.EnemyDefinition?, viewModel: GameViewModel) {
    if (enemy == null) return
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xEE0D0D0D))) {
        Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("━━━━━━━━━━━━━━━━━━━━", color = Color(0xFFEF4444))
            Text("⚠  BOSS  ⚠", color = Color(0xFFEF4444), fontWeight = FontWeight.Black, fontSize = 22.sp)
            Text(enemy.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp, textAlign = TextAlign.Center)
            Text(enemy.title, color = Color(0xFF94A3B8), fontSize = 14.sp)
            Text("\"${enemy.introLine}\"", color = Color(0xFFFECACA), fontStyle = FontStyle.Italic, textAlign = TextAlign.Center)
            Text("━━━━━━━━━━━━━━━━━━━━", color = Color(0xFFEF4444))
            Button(onClick = { viewModel.dismissBossIntro() }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEF4444)), modifier = Modifier.fillMaxWidth()) {
                Text("AFFRONTA IL BOSS", fontWeight = FontWeight.Black)
            }
        }
    }
}

@Composable
private fun PremiumCard(uiState: GameUiState, onPremiumClick: () -> Unit) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x33F59E0B))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("✨ Premium Upgrade", color = Color(0xFFFDE68A), fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text("• Rimuove tutti gli ads\n• Sblocca Oracle Leggendaria\n• Revive gratuito\n• Bonus iniziale e supporto allo sviluppo", color = Color(0xFFFDE68A), fontSize = 13.sp)
            Text("Ads attivi: ${if (uiState.progress.adsEnabled) "Sì" else "No"}", color = Color(0xFFFCD34D), fontSize = 12.sp)
            Button(onClick = onPremiumClick, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF59E0B))) {
                Text("⭐ Acquista Premium", fontWeight = FontWeight.Black, color = Color.Black)
            }
        }
    }
}

@Composable
private fun UpgradePanel(uiState: GameUiState, viewModel: GameViewModel) {
    // Il pannello inline è stato rimosso: usa la schermata dedicata ⬆ Upgrade
}

@Composable
private fun EnemyCard(uiState: GameUiState, enraged: Boolean, pulseScale: Float) {
    val enemy = uiState.battle.enemy ?: return
    val maxHp = uiState.battle.enemyMaxHp.coerceAtLeast(enemy.maxHp)
    val hpPercent = uiState.battle.enemyHp.toFloat() / maxHp.toFloat()
    val barColor = when {
        enraged -> Color(0xFFEF4444)
        hpPercent < 0.3f -> Color(0xFFF97316)
        else -> parseColor(enemy.colorHex)
    }
    ElevatedCard(
        colors = CardDefaults.elevatedCardColors(containerColor = parseColor(enemy.colorHex).copy(alpha = if (enraged) 0.35f else 0.22f)),
        modifier = Modifier.graphicsLayer {
            scaleX = pulseScale
            scaleY = pulseScale
        },
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(enemy.name, color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Black)
                        if (enraged) Text("⚠ ENRAGED", color = Color(0xFFEF4444), fontSize = 11.sp, fontWeight = FontWeight.Black)
                    }
                    Text(enemy.title, color = Color(0xFFE2E8F0), fontSize = 13.sp)
                }
                BehaviorBadge(enemy.behavior)
            }
            StatusBar("Enemy HP", uiState.battle.enemyHp, maxHp, barColor)
            Text("\"${enemy.introLine}\"", color = Color(0xFFF8FAFC), fontStyle = FontStyle.Italic, fontSize = 13.sp)
        }
    }
}

@Composable
private fun BehaviorBadge(behavior: EnemyBehavior) {
    val (label, color) = when (behavior) {
        EnemyBehavior.AGGRESSIVE -> "AGGRESSIVO" to Color(0xFFEF4444)
        EnemyBehavior.DEFENSIVE -> "DIFENSIVO" to Color(0xFF94A3B8)
        EnemyBehavior.FAST, EnemyBehavior.PHANTOM -> "VELOCE" to Color(0xFF38BDF8)
        EnemyBehavior.TRICKSTER -> "TRICKSTER" to Color(0xFFF59E0B)
        EnemyBehavior.BERSERK, EnemyBehavior.BERSERKER_FURY -> "BERSERK" to Color(0xFFF97316)
        EnemyBehavior.BOSS -> "⚠ BOSS" to Color(0xFFEF4444)
    }
    Box(
        Modifier
            .background(color.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp),
    ) {
        Text(label, color = color, fontSize = 10.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun TimingBar(cursor: Float, label: String, enraged: Boolean, slowed: Boolean) {
    val perfectColor = if (enraged) Color(0xFFEF4444) else Color(0xFF22C55E)
    val goodColor = if (enraged) Color(0x44F97316) else Color(0x2222C55E)
    val cursorClamped = cursor.coerceIn(0f, 1f)
    val cursorSize = 28.dp
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("⏱ Timing", color = Color.White, fontWeight = FontWeight.Bold)
            if (slowed) Text("⏳ SLOW ATTIVO", color = Color(0xFFBFDBFE), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            if (enraged) Text("⚠ ZONA RIDOTTA", color = Color(0xFFFCA5A5), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .height(34.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF1E293B)),
        ) {
            val usableWidth = maxWidth - cursorSize
            // GOOD zone
            Box(
                Modifier
                    .fillMaxWidth(0.36f)
                    .align(Alignment.Center)
                    .height(34.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(goodColor),
            )
            // PERFECT zone
            Box(
                Modifier
                    .fillMaxWidth(if (enraged) 0.09f else 0.12f)
                    .align(Alignment.Center)
                    .height(34.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(perfectColor.copy(alpha = 0.45f)),
            )
            // Cursor
            Box(
                modifier = Modifier
                    .offset(x = usableWidth * cursorClamped)
                    .size(cursorSize)
                    .clip(CircleShape)
                    .background(if (slowed) Color(0xFFBFDBFE) else Color.White)
                    .border(2.dp, perfectColor, CircleShape)
                    .align(Alignment.CenterStart),
            )
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("GOOD", color = goodColor.copy(alpha = 0.95f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text("PERFECT", color = perfectColor, fontSize = 10.sp, fontWeight = FontWeight.Black)
            Text("GOOD", color = goodColor.copy(alpha = 0.95f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Text(
            text = label.ifBlank {
                when {
                    slowed -> "⏳ Slow attivo — finestra PERFECT più facile da centrare."
                    enraged -> "⚠ ENRAGED: zona PERFECT ridotta. Massima precisione!"
                    else -> "Colpisci al centro (P) per PERFECT  •  fascia verde per GOOD"
                }
            },
            color = when {
                enraged -> Color(0xFFFCA5A5)
                slowed -> Color(0xFFBFDBFE)
                else -> Color(0xFF94A3B8)
            },
            fontSize = 12.sp,
            fontWeight = if (enraged || slowed) FontWeight.Bold else FontWeight.Normal,
        )
    }
}

@Composable
private fun SkillPanel(uiState: GameUiState, viewModel: GameViewModel) {
    val battle = uiState.battle
    val unlockedSkills = GameCatalog.skills.filter { uiState.progress.unlockedSkillIds.contains(it.id) }
    if (unlockedSkills.isEmpty()) return
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("🔮 Abilità", color = Color.White, fontWeight = FontWeight.Bold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            unlockedSkills.forEach { skill ->
                val cooldown = battle.abilityCooldowns[skill.id] ?: 0
                val isUlt = skill.isUltimate
                val ultReady = isUlt && battle.ultimateCharge >= uiState.progress.maxUltimateCharge
                val enabled = (cooldown == 0) &&
                    (if (isUlt) ultReady else battle.playerEnergy >= skill.energyCost) &&
                    battle.enemyIntent == null && battle.pendingDialogue == null && !battle.battleResolved && !battle.showBossIntro

                val chipColor = when {
                    isUlt && ultReady -> Color(0xFFEF4444)
                    isUlt -> Color(0xFF6B21A8)
                    skill.type == SkillType.HEAL -> Color(0xFF166534)
                    skill.stunTurns > 0 -> Color(0xFF0F766E)
                    skill.bleedTurns > 0 -> Color(0xFF7F1D1D)
                    skill.type == SkillType.BREAK -> Color(0xFF92400E)
                    else -> Color(0xFF1E3A5F)
                }
                AssistChip(
                    onClick = { viewModel.useSkill(skill.id) },
                    enabled = enabled,
                    label = {
                        Text(
                            text = when {
                                isUlt && ultReady -> "🌀 ${skill.name} READY!"
                                isUlt -> "🌀 ${skill.name} [${battle.ultimateCharge}/${uiState.progress.maxUltimateCharge}]"
                                cooldown > 0 -> "${skill.name} CD:$cooldown"
                                else -> "${skill.name} [${skill.energyCost}EN]"
                            },
                            fontWeight = if (isUlt && ultReady) FontWeight.Black else FontWeight.Normal,
                        )
                    },
                    colors = AssistChipDefaults.assistChipColors(containerColor = chipColor.copy(alpha = if (enabled) 0.5f else 0.2f)),
                )
            }
        }
    }
}

@Composable
private fun BattleLog(uiState: GameUiState) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x221E293B))) {
        Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("📋 Battle Log", color = Color(0xFF64748B), fontSize = 11.sp)
            uiState.battle.battleLog.takeLast(5).forEach { line ->
                val lineColor = when {
                    line.startsWith("💀") || line.startsWith("⚠") || line.startsWith("✖") -> Color(0xFFFCA5A5)
                    line.startsWith("✓") || line.startsWith("⭐") || line.startsWith("💥") || line.startsWith("✨") -> Color(0xFF86EFAC)
                    line.startsWith("💊") || line.startsWith("🧊") || line.startsWith("⏳") -> Color(0xFF7DD3FC)
                    else -> Color(0xFFCBD5E1)
                }
                Text(line, color = lineColor, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun ResultCard(uiState: GameUiState, viewModel: GameViewModel, activity: Activity) {
    val won = uiState.battle.playerHp > 0
    val bg = if (won) Color(0xAA0F3D15) else Color(0xAA3D0F0F)
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = bg)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                uiState.battle.overlayMessage,
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
            if (won) {
                Text(
                    "+${uiState.battle.pendingRewardCoins} coin  |  +${uiState.battle.pendingRewardExp} EXP" +
                        if (uiState.battle.killStreak >= 3) "  |  🔥 Streak ×${uiState.battle.killStreak}" else "",
                    color = Color(0xFFFDE68A),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Danno totale inflitto: ${uiState.battle.totalDamageDealt}", color = Color(0xFF94A3B8), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { viewModel.advanceAfterBattle(activity) }, modifier = Modifier.weight(1f)) {
                        Text("Next Stage ▶", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { viewModel.watchRewardedForCoins(activity) }, modifier = Modifier.weight(1f)) {
                        Text(if (uiState.progress.premium) "🎁 +100 coin" else "📺 +100 coin")
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { viewModel.watchRewardedForRevive(activity) },
                        enabled = uiState.battle.reviveAvailable,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                    ) {
                        Text(if (uiState.progress.premium) "💊 Revive free" else "💊 Revive", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { viewModel.navigate(Screen.MENU) }, modifier = Modifier.weight(1f)) { Text("← Menu") }
                }
            }
        }
    }
}

@Composable
private fun DialogueCard(speaker: String, line: String, choices: List<DialogueChoice>, onChoice: (DialogueChoice) -> Unit) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0xCC172554))) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(speaker, color = Color(0xFF93C5FD), fontWeight = FontWeight.Black)
            Text("\"$line\"", color = Color(0xFFE0F2FE), fontStyle = FontStyle.Italic)
            Divider(color = Color(0xFF1E3A8A))
            choices.forEach { choice ->
                OutlinedButton(onClick = { onChoice(choice) }, modifier = Modifier.fillMaxWidth()) {
                    Text(choice.text, textAlign = TextAlign.Start, modifier = Modifier.fillMaxWidth())
                }
            }
        }
    }
}

@Composable
private fun FloatingOverlay(message: String, isPositive: Boolean) {
    if (message.isBlank()) return
    var visible by remember(message) { mutableStateOf(true) }
    LaunchedEffect(message) {
        delay(1200)
        visible = false
    }
    AnimatedVisibility(visible = visible, enter = fadeIn() + scaleIn(), exit = fadeOut()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
                text = message,
                color = if (isPositive) Color(0xFF86EFAC) else Color(0xFFFCA5A5),
                fontWeight = FontWeight.Black,
                fontSize = 28.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .background(Color(0xAA000000), RoundedCornerShape(12.dp))
                    .padding(horizontal = 20.dp, vertical = 10.dp),
            )
        }
    }
}

@Composable
private fun SettingToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x221E293B))) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White)
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

@Composable
private fun StatusBar(label: String, value: Int, max: Int, color: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text("$label $value/$max", color = Color.White, fontSize = 12.sp)
        LinearProgressIndicator(
            progress = { (value.coerceAtLeast(0).toFloat() / max.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f) },
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(10.dp)),
            color = color,
            trackColor = Color(0xFF334155),
        )
    }
}

@Composable
private fun MenuButton(text: String, icon: ImageVector, color: Color = Color(0xFF6366F1), onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = color.copy(alpha = 0.85f))) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(10.dp))
        Text(text, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Suppress("unused")
@Composable
private fun UpgradeButton(text: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick) { Text(text, fontWeight = FontWeight.Bold) }
}

@Composable
private fun SmallStat(label: String, value: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0x441E293B))) {
        Column(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = Color(0xFF94A3B8), fontSize = 11.sp)
            Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
private fun RarityBadge(rarity: String) {
    val color = when (rarity) {
        "LEGENDARY" -> Color(0xFFF59E0B)
        "EPIC" -> Color(0xFFA78BFA)
        "RARE" -> Color(0xFF60A5FA)
        "STARTER" -> Color(0xFF94A3B8)
        else -> Color(0xFF94A3B8)
    }
    Box(Modifier.background(color.copy(alpha = 0.2f), RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 2.dp)) {
        Text(rarity, color = color, fontSize = 9.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun CreditItem(title: String, description: String) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x221E293B))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold)
            Text(description, color = Color(0xFFCBD5E1), fontSize = 13.sp)
        }
    }
}

@Composable
private fun ColorSwatch(color: Color, equipped: Boolean) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(color)
            .border(if (equipped) 3.dp else 1.dp, if (equipped) Color.White else Color.White.copy(alpha = 0.3f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        if (equipped) Text("✓", color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
    }
}

private fun gradientBackground(accent: String): Brush {
    val base = parseColor(accent)
    return Brush.verticalGradient(colors = listOf(Color(0xFF020617), base.copy(alpha = 0.5f), Color(0xFF0F172A)))
}

private fun parseColor(value: String): Color = try {
    Color(android.graphics.Color.parseColor(value))
} catch (_: IllegalArgumentException) {
    Color(0xFF8B5CF6)
}

@Composable
private fun DailyChallengesCard(uiState: GameUiState, viewModel: GameViewModel) {
    ElevatedCard(colors = CardDefaults.elevatedCardColors(containerColor = Color(0x3306B6D4))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("📅 Sfide Giornaliere", color = Color(0xFF67E8F9), fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text("Reset: mezzanotte", color = Color(0xFF94A3B8), fontSize = 11.sp)
            }
            uiState.todaysChallenges.forEach { challenge ->
                val progress = viewModel.getDailyProgress(challenge)
                val completed = progress >= challenge.target
                val claimed = uiState.progress.dailyClaimedIds.contains(challenge.id)
                val barColor = when {
                    claimed -> Color(0xFF6B7280)
                    completed -> Color(0xFF22C55E)
                    else -> Color(0xFF06B6D4)
                }
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = "${if (claimed) "✅" else if (completed) "🎯" else "⬜"} ${challenge.title}",
                                color = if (claimed) Color(0xFF6B7280) else Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                            )
                            Text(challenge.description, color = Color(0xFF94A3B8), fontSize = 11.sp)
                        }
                        if (completed && !claimed) {
                            Button(
                                onClick = { viewModel.claimDailyChallenge(challenge.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF22C55E)),
                                modifier = Modifier.height(32.dp),
                                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                            ) {
                                Text("+${challenge.coinReward}💰", fontWeight = FontWeight.Black, fontSize = 12.sp)
                            }
                        } else {
                            Text(
                                text = "${minOf(progress, challenge.target)}/${challenge.target}",
                                color = barColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                            )
                        }
                    }
                    LinearProgressIndicator(
                        progress = { (progress.toFloat() / challenge.target.toFloat()).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(10.dp)),
                        color = barColor,
                        trackColor = Color(0xFF1E293B),
                    )
                }
            }
        }
    }
}

private fun stageChapterTitle(stage: Int): String = when {
    stage >= 16 -> "Capitolo VI — Il Cuore del Tempo"
    stage >= 11 -> "Capitolo V — Trono del Tirante"
    stage >= 8 -> "Capitolo IV — Citadel Collapse"
    stage >= 5 -> "Capitolo III — Fratture Ribelli"
    stage >= 2 -> "Capitolo II — Echo Breach"
    else -> "Capitolo I — Primo Frammento"
}

private fun stageChapterSubtitle(stage: Int): String = when {
    stage >= 16 -> "Boss leggendari, timing al limite, reward massimi. Solo i migliori arrivano qui."
    stage >= 11 -> "Boss e archetipi avanzati, reward alti e finestre timing strette."
    stage >= 8 -> "Elite, dot, crowd control e pattern rapidi. Usa le skill con giudizio."
    stage >= 5 -> "Dialoghi ramificati e nuove abilità iniziano a cambiare il meta."
    stage >= 2 -> "Stage più impegnativi con nemici veloci e difensivi."
    else -> "Onboarding rapido: impari timing, dodge e gestione energia."
}

// ═══════════════════════════════════════════════════════════════════
//  ONBOARDING SCREEN — 3 slide, HorizontalPager
// ═══════════════════════════════════════════════════════════════════

private data class OnboardSlide(
    val emoji: String,
    val title: String,
    val body: String,
    val accentHex: String,
)

private val ONBOARD_SLIDES = listOf(
    OnboardSlide("⚔", "Piega il Tempo",
        "Colpisci il cursore nella zona PERFECT per danni massimi, slow-motion e combo multiplier. Ogni tap conta.",
        "#6366F1"),
    OnboardSlide("🛡", "Schiva & Sopravvivi",
        "Usa l'energia per abilità devastanti. Schivia gli attacchi nemici nella finestra giusta. La difesa è potere.",
        "#10B981"),
    OnboardSlide("💰", "Potenzia & Conquista",
        "Guadagna coin combattendo, aggiorna le statistiche nell'Upgrade Screen e sblocca skin con bonus unici.",
        "#F59E0B"),
)

@Composable
private fun OnboardingScreen(onFinish: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { ONBOARD_SLIDES.size })
    val scope = rememberCoroutineScope()
    val infiniteTransition = rememberInfiniteTransition(label = "onboard_pulse")
    val bgPulse by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f, label = "bg",
        animationSpec = infiniteRepeatable(tween(3000), RepeatMode.Reverse),
    )

    val slide = ONBOARD_SLIDES[pagerState.currentPage]
    val accent = parseColor(slide.accentHex)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF090D18),
                        accent.copy(alpha = 0.18f + bgPulse * 0.08f),
                        Color(0xFF090D18),
                    )
                )
            ),
        contentAlignment = Alignment.Center,
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Spacer(Modifier.height(24.dp))

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f),
            ) { page ->
                val s = ONBOARD_SLIDES[page]
                val pg = parseColor(s.accentHex)
                Column(
                    modifier = Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(s.emoji, fontSize = 80.sp)
                    Spacer(Modifier.height(24.dp))
                    Text(
                        s.title, color = Color.White,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(16.dp))
                    Text(
                        s.body, color = Color(0xFFCBD5E1),
                        fontSize = 16.sp,
                        lineHeight = 24.sp,
                        textAlign = TextAlign.Center,
                    )
                    Spacer(Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .size(56.dp, 4.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(pg.copy(alpha = 0.5f)),
                    )
                }
            }

            // Dot indicators
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                repeat(ONBOARD_SLIDES.size) { i ->
                    val selected = pagerState.currentPage == i
                    Box(
                        modifier = Modifier
                            .size(if (selected) 24.dp else 8.dp, 8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (selected) accent else Color(0xFF334155))
                            .clickable { scope.launch { pagerState.animateScrollToPage(i) } },
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            val isLast = pagerState.currentPage == ONBOARD_SLIDES.lastIndex
            Button(
                onClick = {
                    if (isLast) onFinish()
                    else scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = accent),
                shape = RoundedCornerShape(14.dp),
            ) {
                Text(
                    if (isLast) "Inizia l'Avventura ⚔" else "Avanti →",
                    fontWeight = FontWeight.Black, fontSize = 16.sp,
                )
            }

            if (!isLast) {
                androidx.compose.material3.TextButton(onClick = onFinish) {
                    Text("Salta", color = Color(0xFF64748B), fontSize = 13.sp)
                }
            } else {
                Spacer(Modifier.height(36.dp))
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  UPGRADE SCREEN — schermata dedicata con stats, CRIT e preview
// ═══════════════════════════════════════════════════════════════════

@Composable
private fun UpgradeScreen(uiState: GameUiState, viewModel: GameViewModel) {
    val p = uiState.progress
    val skin = remember(p.equippedSkinId) {
        GameCatalog.skins.firstOrNull { it.id == p.equippedSkinId } ?: GameCatalog.skins.first()
    }
    val accent = parseColor(skin.accentHex)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(gradientBackground(skin.accentHex))
            .padding(20.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "⬆ Upgrade Eroe",
                color = Color.White,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
            )
            OutlinedButton(
                onClick = { viewModel.navigate(Screen.MENU) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
            ) { Text("← Menu") }
        }

        // Punti disponibili
        ElevatedCard(
            colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF1E293B)),
            shape = RoundedCornerShape(16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column {
                    Text("Punti Upgrade", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    Text(
                        "${p.upgradePoints}",
                        color = if (p.upgradePoints > 0) accent else Color(0xFF64748B),
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Black,
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Livello ${p.level}", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Prossimo: ${p.exp}/${p.expToNext} XP", color = Color(0xFF94A3B8), fontSize = 12.sp)
                    LinearProgressIndicator(
                        progress = { (p.exp.toFloat() / p.expToNext).coerceIn(0f, 1f) },
                        modifier = Modifier.width(120.dp).height(4.dp)
                            .clip(RoundedCornerShape(2.dp)).padding(top = 4.dp),
                        color = accent,
                        trackColor = Color(0xFF334155),
                    )
                }
            }
        }

        if (p.upgradePoints <= 0) {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(16.dp),
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("🎯", fontSize = 36.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Nessun punto disponibile",
                        color = Color(0xFF94A3B8), fontWeight = FontWeight.Bold,
                    )
                    Text(
                        "Sali di livello combattendo per ottenerne altri.",
                        color = Color(0xFF64748B), fontSize = 13.sp, textAlign = TextAlign.Center,
                    )
                }
            }
        }

        // Stat cards grid
        val stats = listOf(
            Triple("attack",  "⚔  Attacco",  "${p.attack} ATK"),
            Triple("defense", "🛡  Difesa",   "${p.defense} DEF"),
            Triple("hp",      "❤  Salute",   "${p.maxHp} HP"),
            Triple("energy",  "⚡  Energia",  "${p.maxEnergy} EN"),
            Triple("crit",    "💥  Critico",  "${(p.critChance * 100).toInt()}% CRIT"),
        )
        val deltas = mapOf(
            "attack" to "+3 ATK", "defense" to "+2 DEF", "hp" to "+14 HP",
            "energy" to "+10 EN", "crit" to "+2% CRIT",
        )

        Text("Statistiche Eroe", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)

        stats.chunked(2).forEach { pair ->
            Row(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth(),
            ) {
                pair.forEach { (key, label, value) ->
                    UpgradeStatCard(
                        modifier = Modifier.weight(1f),
                        label = label,
                        currentValue = value,
                        delta = deltas[key] ?: "",
                        accent = accent,
                        canUpgrade = p.upgradePoints > 0,
                        onClick = { viewModel.spendUpgrade(key) },
                    )
                }
                // fill odd row
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        // Suggerimento skin bonus
        val bonusCrit = (skin.bonusCrit * 100).toInt()
        if (bonusCrit > 0 || skin.bonusCoinsPercent > 0) {
            ElevatedCard(
                colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(16.dp),
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text("✨", fontSize = 24.sp)
                    Column {
                        Text("Bonus Skin: ${skin.name}", color = accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        if (bonusCrit > 0) Text("+$bonusCrit% Critico passivo", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                        if (skin.bonusCoinsPercent > 0) Text("+${skin.bonusCoinsPercent}% Monete", color = Color(0xFFCBD5E1), fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun UpgradeStatCard(
    modifier: Modifier,
    label: String,
    currentValue: String,
    delta: String,
    accent: Color,
    canUpgrade: Boolean,
    onClick: () -> Unit,
) {
    val scale by animateFloatAsState(if (canUpgrade) 1f else 0.97f, label = "card_scale")
    ElevatedCard(
        modifier = modifier.scale(scale).clickable(enabled = canUpgrade, onClick = onClick),
        colors = CardDefaults.elevatedCardColors(
            containerColor = if (canUpgrade) Color(0xFF1E293B) else Color(0xFF0F172A),
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.elevatedCardElevation(if (canUpgrade) 6.dp else 0.dp),
    ) {
        Column(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            Text(label, color = Color(0xFF94A3B8), fontSize = 12.sp, fontWeight = FontWeight.Medium)
            Text(currentValue, color = Color.White, fontWeight = FontWeight.Black, fontSize = 18.sp)
            if (canUpgrade) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(accent.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Text("TAP  $delta", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                Text("—", color = Color(0xFF334155), fontSize = 11.sp)
            }
        }
    }
}

// ═══════════════════════════════════════════════════════════════════
//  FLOATING DAMAGE NUMBERS — overlay animato durante il combattimento
// ═══════════════════════════════════════════════════════════════════

@Composable
fun FloatingDamageOverlay(
    floatingDamages: List<FloatingDamage>,
    onRemove: (Long) -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        floatingDamages.forEach { fd ->
            key(fd.id) {
                FloatingDamageNumber(fd = fd, onExpired = { onRemove(fd.id) })
            }
        }
    }
}

@Composable
private fun FloatingDamageNumber(fd: FloatingDamage, onExpired: () -> Unit) {
    var visible by remember { mutableStateOf(true) }
    val offsetY by animateFloatAsState(
        targetValue = if (visible) -120f else -200f,
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "fd_y",
    )
    val alpha by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = tween(900),
        label = "fd_alpha",
    )
    val scale by animateFloatAsState(
        targetValue = if (visible) 1f else 0.5f,
        animationSpec = tween(300),
        label = "fd_scale",
    )
    LaunchedEffect(fd.id) {
        delay(150)
        visible = false
        delay(900)
        onExpired()
    }

    val color = when {
        fd.isMiss    -> Color(0xFF94A3B8)
        fd.isHeal    -> Color(0xFF4ADE80)
        fd.isPerfect -> Color(0xFFFBBF24)
        fd.isCrit    -> Color(0xFFF87171)
        else         -> Color.White
    }
    val fontSize = when {
        fd.isPerfect || fd.isCrit -> 26.sp
        fd.isMiss                 -> 16.sp
        else                      -> 22.sp
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 40.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = fd.text,
            color = color.copy(alpha = alpha),
            fontSize = fontSize,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .offset { IntOffset(x = 0, y = offsetY.toInt()) }
                .scale(scale),
        )
    }
}
