package com.genspark.chronosshatter.viewmodel

import android.app.Activity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.genspark.chronosshatter.ads.AdsManager
import com.genspark.chronosshatter.audio.FeedbackManager
import com.genspark.chronosshatter.data.GameCatalog
import com.genspark.chronosshatter.data.GameRepository
import com.genspark.chronosshatter.model.FloatingDamage
import com.genspark.chronosshatter.model.AnimationEvent
import com.genspark.chronosshatter.model.BattleRuntime
import com.genspark.chronosshatter.model.DailyChallenge
import com.genspark.chronosshatter.model.DailyChallengeType
import com.genspark.chronosshatter.model.DialogueChoice
import com.genspark.chronosshatter.model.EnemyBehavior
import com.genspark.chronosshatter.model.EnemyDefinition
import com.genspark.chronosshatter.model.EnemyIntent
import com.genspark.chronosshatter.model.GameUiState
import com.genspark.chronosshatter.model.PlayerProgress
import com.genspark.chronosshatter.model.Screen
import com.genspark.chronosshatter.model.SkillType
import com.genspark.chronosshatter.model.applyLevelProgress
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class GameViewModel(
    private val repository: GameRepository,
    private val feedbackManager: FeedbackManager,
    private val adsManager: AdsManager,
) : ViewModel() {

    var uiState by mutableStateOf(GameUiState(progress = repository.loadProgress()))
        private set

    private val rng = Random(System.currentTimeMillis())

    init {
        adsManager.initialize()
        val normalized = normalizeProgress(uiState.progress)
        val withScreen = if (!normalized.onboardingDone) {
            uiState.copy(progress = normalized, screen = Screen.ONBOARDING)
        } else {
            uiState.copy(progress = normalized)
        }
        if (normalized != uiState.progress || withScreen.screen != uiState.screen) {
            repository.saveProgress(normalized)
            uiState = withScreen
        }
        checkAndResetDailyChallenges()
    }

    fun navigate(screen: Screen) {
        if (screen == Screen.MENU) {
            checkAndResetDailyChallenges()
        }
        uiState = uiState.copy(screen = screen, globalMessage = "Pronto per la prossima frattura.")
    }

    /** Chiamato dall'ultima slide di onboarding. */
    fun completeOnboarding() {
        val updated = uiState.progress.copy(onboardingDone = true)
        repository.saveProgress(updated)
        uiState = uiState.copy(progress = updated, screen = Screen.MENU)
    }

    fun updateTiming() {
        val battle = uiState.battle
        if (battle.enemy == null || battle.battleResolved) return
        val slowModifier = if (battle.timingSlowTurns > 0) 0.72f else 1f
        val speedMod = when {
            battle.enemyEnraged -> 1.45f
            battle.stage > 10 -> 1.25f
            battle.stage > 6 -> 1.12f
            else -> 1f
        }
        val speed = battle.timingSpeed * speedMod * slowModifier
        var cursor = battle.timingCursor
        var forward = battle.timingForward
        cursor += if (forward) speed else -speed
        if (cursor >= 1f) {
            cursor = 1f
            forward = false
        } else if (cursor <= 0f) {
            cursor = 0f
            forward = true
        }
        uiState = uiState.copy(battle = battle.copy(timingCursor = cursor, timingForward = forward))
    }

    fun startRun() {
        checkAndResetDailyChallenges()
        val progress = normalizeProgress(uiState.progress)
        val updatedProgress = progress.copy(runsPlayed = progress.runsPlayed + 1)
        repository.saveProgress(updatedProgress)
        val battle = BattleRuntime(
            stage = max(1, updatedProgress.stageReached),
            playerHp = updatedProgress.maxHp,
            playerEnergy = updatedProgress.maxEnergy / 2,
            playerShield = 0,
            abilityCooldowns = updatedProgress.unlockedSkillIds.associateWith { 0 },
            battleLog = listOf("⚔ Entri nella frattura. Il tempo si spezza attorno a te."),
            interstitialCounter = uiState.battle.interstitialCounter,
            ultimateCharge = updatedProgress.ultimateCharge,
        )
        uiState = uiState.copy(progress = updatedProgress, screen = Screen.BATTLE, battle = battle)
        setupStage(battle.stage)
    }

    private fun setupStage(stage: Int) {
        val enemy = selectEnemy(stage)
        val isBoss = enemy.behavior == EnemyBehavior.BOSS
        val randomEvent = if (stage > 1 && stage % 3 == 0) GameCatalog.randomEvents.random(rng) else null
        val dialogue = if (stage == 1 || stage % 4 == 0) GameCatalog.dialogues.random(rng) else null
        val appliedBuffLabel = randomEvent?.battleModifier ?: uiState.battle.activeBuffLabel
        val introLog = mutableListOf<String>()
        val encounterLabel = when {
            isBoss -> "Boss breach"
            stage % 5 == 0 -> "Elite hunt"
            randomEvent != null -> "Evento instabile"
            else -> "Combattimento rapido"
        }

        if (isBoss) {
            introLog += "━━━━━━━━━━━━━━━━━━━━━━"
            introLog += "⚠ BOSS: ${enemy.name}"
            introLog += enemy.introLine
            introLog += "━━━━━━━━━━━━━━━━━━━━━━"
        } else {
            introLog += "Stage $stage ▶ ${enemy.name} appare."
        }
        randomEvent?.let { introLog += "✦ Evento: ${it.title}" }
        dialogue?.let { introLog += "💬 ${it.speaker}: \"${it.line.take(60)}...\"" }

        var playerHp = uiState.battle.playerHp
        var playerEnergy = uiState.battle.playerEnergy
        var shield = uiState.battle.playerShield
        var updatedProgress = uiState.progress
        randomEvent?.let {
            playerHp = min(uiState.progress.maxHp, playerHp + it.hpDelta)
            playerEnergy = min(uiState.progress.maxEnergy, playerEnergy + it.energyDelta)
            shield += it.shieldDelta
            if (it.coinsDelta != 0) {
                updatedProgress = updatedProgress.copy(coins = max(0, updatedProgress.coins + it.coinsDelta))
                repository.saveProgress(updatedProgress)
            }
            introLog += it.description
        }

        val stageEnemyHp = scaledEnemyHp(enemy, stage, appliedBuffLabel)
        val stageTimingSpeed = when (enemy.behavior) {
            EnemyBehavior.FAST, EnemyBehavior.PHANTOM -> 0.030f
            EnemyBehavior.BOSS -> 0.024f
            EnemyBehavior.DEFENSIVE -> 0.019f
            EnemyBehavior.TRICKSTER -> 0.026f
            else -> 0.022f
        }

        uiState = uiState.copy(
            progress = updatedProgress,
            battle = uiState.battle.copy(
                stage = stage,
                enemy = enemy,
                enemyHp = stageEnemyHp,
                enemyMaxHp = stageEnemyHp,
                enemyEnraged = false,
                enemyBleedTurns = 0,
                enemyBleedDamage = 0,
                enemyStunTurns = 0,
                timingSlowTurns = 0,
                playerHp = playerHp,
                playerEnergy = playerEnergy,
                playerShield = shield,
                battleLog = introLog,
                pendingDialogue = dialogue,
                pendingRandomEvent = randomEvent,
                activeBuffLabel = appliedBuffLabel,
                encounterLabel = encounterLabel,
                battleResolved = false,
                timingSpeed = stageTimingSpeed,
                overlayMessage = if (isBoss) "⚠ BOSS!" else enemy.name,
                overlayIsPositive = false,
                lastTimingLabel = "",
                enemyIntent = null,
                dodgeAttemptsLeft = dodgeChargesForEnemy(enemy),
                comboCount = 0,
                comboMultiplier = 1f,
                showBossIntro = isBoss,
                reviveAvailable = true,
                animationEvent = AnimationEvent.NONE,
            ),
        )
    }

    fun dismissBossIntro() {
        uiState = uiState.copy(battle = uiState.battle.copy(showBossIntro = false))
    }

    fun resolveDialogue(choice: DialogueChoice) {
        val battle = uiState.battle
        val progress = uiState.progress
        val updatedSkills = choice.grantSkillId?.let { progress.unlockedSkillIds + it } ?: progress.unlockedSkillIds
        val updatedSkins = choice.unlockSkinId?.let { progress.ownedSkinIds + it } ?: progress.ownedSkinIds
        val newUltCharge = min(progress.maxUltimateCharge, battle.ultimateCharge + choice.ultimateChargeBonus)
        val normalized = normalizeProgress(
            progress.copy(
                coins = max(0, progress.coins + choice.coinsDelta),
                unlockedSkillIds = updatedSkills,
                ownedSkinIds = updatedSkins,
                ultimateCharge = newUltCharge,
            ),
        )
        repository.saveProgress(normalized)

        val updatedBattle = battle.copy(
            playerHp = min(normalized.maxHp, battle.playerHp + choice.healDelta),
            enemyHp = max(1, battle.enemyHp + choice.enemyHpDelta),
            activeBuffLabel = choice.nextBattleBuff ?: battle.activeBuffLabel,
            battleLog = (battle.battleLog + listOf("✓ ${choice.response}")).takeLast(10),
            pendingDialogue = null,
            overlayMessage = choice.response.take(30),
            overlayIsPositive = true,
            abilityCooldowns = battle.abilityCooldowns + normalized.unlockedSkillIds.associateWith { battle.abilityCooldowns[it] ?: 0 },
            ultimateCharge = newUltCharge,
        )
        uiState = uiState.copy(progress = normalized, battle = updatedBattle)
    }

    fun basicAttack() {
        val battle = uiState.battle
        val enemy = battle.enemy ?: return
        if (battle.battleResolved || battle.pendingDialogue != null || battle.enemyIntent != null || battle.showBossIntro) return
        val timing = evaluateTiming(battle.timingCursor)
        // Track daily perfect hits
        if (timing == "PERFECT") {
            val updatedProgress = uiState.progress.copy(dailyPerfectHits = uiState.progress.dailyPerfectHits + 1)
            repository.saveProgress(updatedProgress)
            uiState = uiState.copy(progress = updatedProgress)
        }
        val equippedSkin = currentSkin()
        val critChance = 0.08f + equippedSkin.bonusCrit + when (timing) {
            "PERFECT" -> 0.22f
            "GOOD" -> 0.08f
            else -> 0f
        }
        val crit = rng.nextFloat() < critChance
        val comboBonus = 1f + (battle.comboCount * 0.08f).coerceAtMost(0.80f)
        val base = (uiState.progress.attack * when (timing) {
            "PERFECT" -> 1.8f
            "GOOD" -> 1.3f
            "OK" -> 1.0f
            else -> 0.75f
        } * comboBonus).toInt()
        val damage = max(6, base - enemy.defense + if (crit) 15 else 0)
        val energyGain = when (timing) {
            "PERFECT" -> 20
            "GOOD" -> 15
            "OK" -> 10
            else -> 5
        }
        val newCombo = if (timing != "MISS") battle.comboCount + 1 else 0
        val ultCharge = min(
            uiState.progress.maxUltimateCharge,
            battle.ultimateCharge + when (timing) {
                "PERFECT" -> 18
                "GOOD" -> 10
                "OK" -> 6
                else -> 2
            },
        )

        val message = when {
            newCombo >= 8 && timing == "PERFECT" && crit -> "🔥 x${newCombo} COMBO PERFECT CRIT!"
            newCombo >= 5 -> "⚡ x${newCombo} COMBO!"
            crit && timing == "PERFECT" -> "💥 PERFECT CRIT!"
            crit -> "✨ CRIT!"
            timing == "PERFECT" -> "⭐ PERFECT!"
            timing == "MISS" -> "✗ MANCATO"
            else -> timing
        }

        val animEvent = when {
            crit && timing == "PERFECT" -> AnimationEvent.PLAYER_PERFECT
            crit -> AnimationEvent.PLAYER_CRIT
            timing == "PERFECT" -> AnimationEvent.PLAYER_PERFECT
            timing == "MISS" -> AnimationEvent.NONE
            else -> AnimationEvent.PLAYER_HIT
        }

        trackDailyComboRecord(newCombo)

        applyPlayerAction(
            damage = damage,
            energyDelta = energyGain,
            cooldownSkill = null,
            logLine = "${message} ▶ $damage danni${if (crit) " (crit)" else ""}${if (newCombo > 1) " [combo×$newCombo]" else ""}.",
            overlay = message,
            playCritical = crit || timing == "PERFECT",
            timingResult = timing,
            newCombo = newCombo,
            ultChargeGain = ultCharge - battle.ultimateCharge,
            animEvent = animEvent,
        )
    }

    fun useSkill(skillId: String) {
        val battle = uiState.battle
        if (battle.battleResolved || battle.pendingDialogue != null || battle.enemyIntent != null || battle.showBossIntro) return
        val skill = GameCatalog.skills.firstOrNull { it.id == skillId } ?: return
        if (!uiState.progress.unlockedSkillIds.contains(skillId)) return
        val cooldown = battle.abilityCooldowns[skillId] ?: 0
        if (cooldown > 0 || battle.playerEnergy < skill.energyCost) return
        val enemy = battle.enemy ?: return
        if (skill.isUltimate && battle.ultimateCharge < uiState.progress.maxUltimateCharge) return
        // Track daily skill + ultimate uses
        val dailyUpdated = uiState.progress.copy(
            dailySkillUses = uiState.progress.dailySkillUses + 1,
            dailyUltimatesUsed = uiState.progress.dailyUltimatesUsed + if (skill.isUltimate) 1 else 0,
        )
        repository.saveProgress(dailyUpdated)
        uiState = uiState.copy(progress = dailyUpdated)

        val timing = evaluateTiming(battle.timingCursor)
        val multiplierBoost = if (timing == "PERFECT") 1.2f else if (timing == "GOOD") 1.05f else 1f
        val comboBonus = 1f + (battle.comboCount * 0.06f).coerceAtMost(0.60f)
        val baseDamage = when (skill.type) {
            SkillType.ATTACK, SkillType.BREAK, SkillType.BUFF, SkillType.ULTIMATE ->
                ((uiState.progress.attack * skill.powerMultiplier) * multiplierBoost * comboBonus).toInt() + skill.flatDamage
            SkillType.HEAL -> 0
        }
        val damage = when (skill.type) {
            SkillType.BREAK -> max(12, baseDamage - max(0, enemy.defense / 2))
            SkillType.ULTIMATE -> max(20, baseDamage)
            SkillType.ATTACK, SkillType.BUFF -> max(10, baseDamage - enemy.defense)
            SkillType.HEAL -> 0
        }
        val heal = skill.healAmount + if (timing == "PERFECT") 8 else 0
        val shield = skill.grantsShield + if (timing == "PERFECT") 6 else 0
        val energyDelta = skill.energyGain - skill.energyCost
        val newCombo = if (damage > 0) battle.comboCount + 1 else 0
        val appliedBleedDamage = if (skill.bleedTurns > 0) skill.bleedDamage + if (timing == "PERFECT") 3 else 0 else 0

        val log = buildString {
            append(
                when (skill.type) {
                    SkillType.HEAL -> "${skill.name}: +$heal HP, +$shield scudo${if (timing == "PERFECT") " [PERFECT BONUS!]" else ""}."
                    SkillType.BREAK -> "${skill.name}: frantuma la guardia per $damage danni${if (timing == "PERFECT") " [PERFECT BREAK!]" else ""}!"
                    SkillType.ULTIMATE -> "🌀 ${skill.name}: ULTIMATE SCATENATO per $damage danni DEVASTANTI!"
                    SkillType.BUFF -> "${skill.name}: pressione tattica per $damage danni e vantaggio di tempo."
                    SkillType.ATTACK -> "${skill.name}: scarica $damage danni${if (timing == "PERFECT") " POTENZIATI" else ""}!"
                },
            )
            if (skill.bleedTurns > 0) append(" Bleed ${skill.bleedTurns}T.")
            if (skill.stunTurns > 0) append(" Stun ${skill.stunTurns}T.")
            if (skill.slowTurns > 0) append(" Slow ${skill.slowTurns}T.")
        }

        val overlay = when {
            skill.isUltimate -> "🌀 ULTIMATE!"
            skill.stunTurns > 0 -> "🧊 STUN!"
            skill.bleedTurns > 0 -> "🩸 BLEED!"
            skill.type == SkillType.BREAK -> "💥 BREAK!"
            else -> skill.name.take(18)
        }

        trackDailyComboRecord(newCombo)

        applyPlayerAction(
            damage = damage,
            energyDelta = energyDelta,
            cooldownSkill = skillId to skill.cooldownTurns,
            logLine = log,
            overlay = overlay,
            playCritical = skill.isUltimate || (timing == "PERFECT" && damage > 0),
            timingResult = timing,
            healAmount = heal,
            shieldAmount = shield,
            newCombo = newCombo,
            ultChargeGain = if (skill.isUltimate) -battle.ultimateCharge else if (timing == "PERFECT") 14 else 10,
            enemyBleedTurns = skill.bleedTurns,
            enemyBleedDamage = appliedBleedDamage,
            enemyStunTurns = skill.stunTurns,
            timingSlowTurns = skill.slowTurns,
            animEvent = when {
                skill.isUltimate -> AnimationEvent.PLAYER_ULTIMATE
                timing == "PERFECT" && damage > 0 -> AnimationEvent.PLAYER_PERFECT
                damage > 0 -> AnimationEvent.PLAYER_HIT
                else -> AnimationEvent.NONE
            },
        )
    }

    private fun applyPlayerAction(
        damage: Int,
        energyDelta: Int,
        cooldownSkill: Pair<String, Int>?,
        logLine: String,
        overlay: String,
        playCritical: Boolean,
        timingResult: String,
        healAmount: Int = 0,
        shieldAmount: Int = 0,
        newCombo: Int = 0,
        ultChargeGain: Int = 0,
        enemyBleedTurns: Int = 0,
        enemyBleedDamage: Int = 0,
        enemyStunTurns: Int = 0,
        timingSlowTurns: Int = 0,
        animEvent: AnimationEvent = AnimationEvent.NONE,
    ) {
        playPlayerHit(playCritical)
        // Spawn floating damage number
        if (damage > 0) {
            val fdText = when {
                timingResult == "PERFECT" && playCritical -> "💥 PERFECT! $damage"
                timingResult == "PERFECT"                 -> "⭐ $damage"
                playCritical                              -> "💥 $damage!"
                else                                      -> "$damage"
            }
            spawnFloatingDamage(fdText, isPerfect = timingResult == "PERFECT", isCrit = playCritical)
        }
        if (healAmount > 0) spawnFloatingDamage("+$healAmount ❤", isHeal = true)
        if (timingResult == "MISS") spawnFloatingDamage("MISS", isMiss = true)
        val battle = uiState.battle
        val progress = uiState.progress
        val enemy = battle.enemy ?: return

        val newShield = battle.playerShield + shieldAmount
        val newEnemyHp = battle.enemyHp - damage
        val newPlayerHp = min(progress.maxHp, battle.playerHp + healAmount)
        val newEnergy = (battle.playerEnergy + energyDelta).coerceIn(0, progress.maxEnergy)
        val newUltCharge = (battle.ultimateCharge + ultChargeGain).coerceIn(0, progress.maxUltimateCharge)
        val updatedCooldowns = battle.abilityCooldowns.mapValues { (key, value) ->
            if (key == cooldownSkill?.first) cooldownSkill.second
            else if (value > 0 && damage > 0) value - 1 else value
        }
        val resultingBleedTurns = if (enemyBleedTurns > 0) max(battle.enemyBleedTurns, enemyBleedTurns) else battle.enemyBleedTurns
        val resultingBleedDamage = if (enemyBleedTurns > 0) max(battle.enemyBleedDamage, enemyBleedDamage) else battle.enemyBleedDamage
        val resultingStunTurns = max(battle.enemyStunTurns, enemyStunTurns)
        val resultingSlowTurns = max(battle.timingSlowTurns, timingSlowTurns)
        val perfectStreak = when (timingResult) {
            "PERFECT" -> battle.perfectStreak + 1
            "MISS" -> 0
            else -> battle.perfectStreak
        }

        val enrageThresholdHp = (battle.enemyMaxHp * enemy.enrageThreshold).toInt()
        val shouldEnrage = !battle.enemyEnraged && newEnemyHp > 0 && newEnemyHp <= enrageThresholdHp
        val extraStatusLines = buildList {
            if (enemyBleedTurns > 0) add("🩸 ${enemy.name} sanguina per $resultingBleedDamage per $resultingBleedTurns turni.")
            if (enemyStunTurns > 0) add("🧊 ${enemy.name} è stordito!")
            if (timingSlowTurns > 0) add("⏳ Il flusso temporale rallenta per $resultingSlowTurns turni.")
            if (shouldEnrage) add("⚠ ${enemy.name}: ${enemy.enrageLine}")
        }
        val newLog = (battle.battleLog + logLine + extraStatusLines).takeLast(10)

        if (newEnemyHp <= 0) {
            winBattle(
                battle = battle,
                progress = progress,
                newPlayerHp = newPlayerHp,
                newEnergy = newEnergy,
                newShield = newShield,
                updatedCooldowns = updatedCooldowns,
                enemy = enemy,
                log = newLog,
                newCombo = newCombo,
                newUltCharge = newUltCharge,
                perfectStreak = perfectStreak,
            )
        } else {
            uiState = uiState.copy(
                battle = battle.copy(
                    enemyHp = newEnemyHp,
                    enemyEnraged = battle.enemyEnraged || shouldEnrage,
                    enemyBleedTurns = resultingBleedTurns,
                    enemyBleedDamage = resultingBleedDamage,
                    enemyStunTurns = resultingStunTurns,
                    timingSlowTurns = resultingSlowTurns,
                    playerHp = newPlayerHp,
                    playerEnergy = newEnergy,
                    playerShield = newShield,
                    abilityCooldowns = updatedCooldowns,
                    battleLog = newLog,
                    overlayMessage = overlay,
                    overlayIsPositive = true,
                    lastTimingLabel = overlay,
                    comboCount = newCombo,
                    comboMultiplier = 1f + (newCombo * 0.08f).coerceAtMost(0.80f),
                    perfectStreak = perfectStreak,
                    ultimateCharge = newUltCharge,
                    totalDamageDealt = battle.totalDamageDealt + damage,
                    animationTick = battle.animationTick + 1,
                    animationEvent = animEvent,
                ),
            )
            triggerEnemyIntent()
        }
    }

    private fun winBattle(
        battle: BattleRuntime,
        progress: PlayerProgress,
        newPlayerHp: Int,
        newEnergy: Int,
        newShield: Int,
        updatedCooldowns: Map<String, Int>,
        enemy: EnemyDefinition,
        log: List<String>,
        newCombo: Int,
        newUltCharge: Int,
        perfectStreak: Int,
    ) {
        val skin = currentSkin()
        val coinBonus = 1f + skin.bonusCoinsPercent / 100f
        val comboBonus = 1f + (battle.killStreak * 0.1f).coerceAtMost(0.5f)
        val rewardCoins = (enemy.rewardCoins * coinBonus * comboBonus).toInt()
        val rewardExp = enemy.rewardExp + (perfectStreak * 5)
        val newStreak = battle.killStreak + 1
        val streakMsg = if (newStreak >= 3) " 🔥 KILL STREAK ×$newStreak! +BONUS COIN!" else ""

        var updatedProgress = progress.copy(
            coins = progress.coins + rewardCoins,
            stageReached = max(progress.stageReached, battle.stage + 1),
            bestStage = max(progress.bestStage, battle.stage),
            totalEnemiesDefeated = progress.totalEnemiesDefeated + 1,
            ultimateCharge = newUltCharge,
            dailyKills = progress.dailyKills + 1,
            dailyStages = progress.dailyStages + 1,
            dailyMaxCombo = max(progress.dailyMaxCombo, battle.comboCount),
        ).applyLevelProgress(rewardExp)

        val initialSkills = updatedProgress.unlockedSkillIds
        updatedProgress = normalizeProgress(updatedProgress)
        val newlyUnlockedSkills = updatedProgress.unlockedSkillIds - initialSkills
        val skillUnlockLine = newlyUnlockedSkills.takeIf { it.isNotEmpty() }?.joinToString(", ") {
            GameCatalog.skills.firstOrNull { skill -> skill.id == it }?.name ?: it
        }

        val rewardableSkins = GameCatalog.skins.filter { !it.premiumOnly && !updatedProgress.ownedSkinIds.contains(it.id) }
        val droppedSkin = if (rewardableSkins.isNotEmpty() && rng.nextFloat() < 0.18f) rewardableSkins.random(rng) else null
        if (droppedSkin != null) {
            updatedProgress = updatedProgress.copy(ownedSkinIds = updatedProgress.ownedSkinIds + droppedSkin.id)
        }
        repository.saveProgress(updatedProgress)

        val deathLog = buildList {
            addAll(log)
            add("💀 ${enemy.name}: \"${enemy.deathLine}\"")
            add("✓ Vittoria$streakMsg — +$rewardCoins coin, +$rewardExp EXP.")
            skillUnlockLine?.let { add("✨ Nuove abilità: $it") }
            droppedSkin?.let { add("🎁 Drop skin: ${it.name}") }
        }.takeLast(10)

        uiState = uiState.copy(
            progress = updatedProgress,
            globalMessage = droppedSkin?.let { "Nuovo drop cosmetico: ${it.name}" }
                ?: skillUnlockLine?.let { "Abilità sbloccate: $it" }
                ?: "Loop completato: ricompense incassate.",
            battle = battle.copy(
                enemyHp = 0,
                enemyBleedTurns = 0,
                enemyBleedDamage = 0,
                enemyStunTurns = 0,
                playerHp = newPlayerHp,
                playerEnergy = newEnergy,
                playerShield = newShield,
                abilityCooldowns = updatedCooldowns,
                battleLog = deathLog,
                overlayMessage = if (newStreak >= 3) "🔥 KILL STREAK!" else "⭐ VITTORIA!",
                overlayIsPositive = true,
                battleResolved = true,
                pendingRewardCoins = rewardCoins,
                pendingRewardExp = rewardExp,
                enemyIntent = null,
                comboCount = newCombo,
                killStreak = newStreak,
                perfectStreak = perfectStreak,
                ultimateCharge = newUltCharge,
            ),
        )
    }

    private fun triggerEnemyIntent() {
        val currentBattle = uiState.battle
        val enemy = currentBattle.enemy ?: return
        val progress = uiState.progress
        if (currentBattle.enemyIntent != null || currentBattle.battleResolved) return

        var battle = currentBattle
        val statusLines = mutableListOf<String>()
        var enemyHp = battle.enemyHp
        var bleedTurns = battle.enemyBleedTurns
        val bleedDamage = battle.enemyBleedDamage
        if (bleedTurns > 0 && bleedDamage > 0) {
            enemyHp = max(0, enemyHp - bleedDamage)
            bleedTurns -= 1
            statusLines += "🩸 Bleed infligge $bleedDamage danni a ${enemy.name}."
        }

        if (enemyHp <= 0) {
            winBattle(
                battle = battle.copy(enemyHp = 0, enemyBleedTurns = bleedTurns, enemyBleedDamage = bleedDamage),
                progress = progress,
                newPlayerHp = battle.playerHp,
                newEnergy = battle.playerEnergy,
                newShield = battle.playerShield,
                updatedCooldowns = battle.abilityCooldowns,
                enemy = enemy,
                log = (battle.battleLog + statusLines).takeLast(10),
                newCombo = battle.comboCount,
                newUltCharge = battle.ultimateCharge,
                perfectStreak = battle.perfectStreak,
            )
            return
        }

        val refreshedBattle = battle.copy(
            enemyHp = enemyHp,
            enemyBleedTurns = bleedTurns,
            battleLog = (battle.battleLog + statusLines).takeLast(10),
        )

        if (refreshedBattle.enemyStunTurns > 0) {
            uiState = uiState.copy(
                battle = refreshedBattle.copy(
                    enemyStunTurns = refreshedBattle.enemyStunTurns - 1,
                    timingSlowTurns = max(0, refreshedBattle.timingSlowTurns - 1),
                    overlayMessage = "🧊 STUN!",
                    overlayIsPositive = true,
                    battleLog = (refreshedBattle.battleLog + "🧊 ${enemy.name} perde il turno.").takeLast(10),
                    animationTick = refreshedBattle.animationTick + 1,
                    animationEvent = AnimationEvent.ENEMY_DODGE,
                ),
            )
            return
        }

        val telegraphed = rng.nextFloat() < when (enemy.behavior) {
            EnemyBehavior.BOSS -> 0.95f
            EnemyBehavior.FAST, EnemyBehavior.PHANTOM -> 0.75f
            else -> 0.60f
        }
        val enrageMultiplier = if (refreshedBattle.enemyEnraged) 1.4f else 1f
        val intent = when (enemy.behavior) {
            EnemyBehavior.AGGRESSIVE -> EnemyIntent(
                label = if (refreshedBattle.enemyEnraged) "⚠ FURIA AGGRESSIVA" else if (telegraphed) "Attacco Diretto" else "Assalto improvviso",
                damage = ((enemy.attack * 1.1f + refreshedBattle.stage * 1.5f) * enrageMultiplier).toInt(),
                speedTag = if (telegraphed) "VELOCE" else "SNEAK",
                telegraphMs = if (telegraphed) if (refreshedBattle.enemyEnraged) 1400L else 1800L else 700L,
            )
            EnemyBehavior.DEFENSIVE -> EnemyIntent(
                label = if (telegraphed) "Contrattacco" else "Guard break",
                damage = ((enemy.attack * 0.8f + refreshedBattle.stage) * enrageMultiplier).toInt(),
                energyDrain = 12,
                speedTag = if (telegraphed) "LENTO" else "CONTROL",
                telegraphMs = if (telegraphed) 2400L else 900L,
            )
            EnemyBehavior.FAST, EnemyBehavior.PHANTOM -> EnemyIntent(
                label = if (refreshedBattle.enemyEnraged) "⚡ BLITZ FINALE" else if (telegraphed) "Blitz" else "Flash strike",
                damage = ((enemy.attack * 1.3f + refreshedBattle.stage * 2f) * enrageMultiplier).toInt(),
                speedTag = "FULMINEO",
                telegraphMs = if (telegraphed) if (refreshedBattle.enemyEnraged) 900L else 1200L else 550L,
            )
            EnemyBehavior.TRICKSTER -> EnemyIntent(
                label = if (telegraphed) "Inganno Cronico" else "Hex burst",
                damage = ((enemy.attack * 0.9f + refreshedBattle.stage) * enrageMultiplier).toInt(),
                energyDrain = 20,
                speedTag = "IMPREVEDIBILE",
                telegraphMs = if (telegraphed) 1600L else 700L,
            )
            EnemyBehavior.BERSERK, EnemyBehavior.BERSERKER_FURY -> EnemyIntent(
                label = if (refreshedBattle.enemyEnraged) "🔥 BERSERK TOTALE" else if (telegraphed) "Assalto Berserk" else "Rage crush",
                damage = ((enemy.attack * 1.6f + refreshedBattle.stage * 2.5f) * enrageMultiplier).toInt(),
                speedTag = if (refreshedBattle.enemyEnraged) "DEVASTANTE" else "PESANTE",
                telegraphMs = if (telegraphed) if (refreshedBattle.enemyEnraged) 1000L else 2000L else 650L,
            )
            EnemyBehavior.BOSS -> EnemyIntent(
                label = if (refreshedBattle.enemyEnraged) "💀 ATTACCO FINALE DEL BOSS" else if (telegraphed) "Attacco Boss" else "Boss pressure",
                damage = ((enemy.attack * 1.5f + refreshedBattle.stage * 3f) * enrageMultiplier).toInt(),
                energyDrain = if (refreshedBattle.enemyEnraged) 25 else 10,
                speedTag = if (refreshedBattle.enemyEnraged) "DEVASTANTE" else "POTENTE",
                telegraphMs = if (telegraphed) if (refreshedBattle.enemyEnraged) 1200L else 2000L else 800L,
            )
        }

        uiState = uiState.copy(
            battle = refreshedBattle.copy(
                enemyIntent = intent,
                enemyIntentStartedAt = System.currentTimeMillis(),
                dodgeAttemptsLeft = dodgeChargesForEnemy(enemy),
                timingSlowTurns = max(0, refreshedBattle.timingSlowTurns - if (refreshedBattle.timingSlowTurns > 0) 1 else 0),
                overlayMessage = if (telegraphed) refreshedBattle.overlayMessage else "⚠ ASSALTO!",
            ),
        )
    }

    fun resolveEnemyAttack() {
        val battle = uiState.battle
        val intent = battle.enemyIntent ?: return
        val progress = uiState.progress
        playEnemyHit()

        var incoming = intent.damage - progress.defense
        incoming = max(4, incoming)
        val shieldAbsorb = min(battle.playerShield, incoming)
        incoming -= shieldAbsorb
        val newShield = battle.playerShield - shieldAbsorb
        val newPlayerHp = battle.playerHp - incoming
        val newEnergy = max(0, battle.playerEnergy - intent.energyDrain)

        val hitLog = "⚠ ${battle.enemy?.name}: ${intent.label} — $incoming danni${if (intent.energyDrain > 0) " -${intent.energyDrain} EN" else ""}${if (shieldAbsorb > 0) " [scudo assorbe $shieldAbsorb]" else ""}."
        val updatedBattle = battle.copy(
            playerHp = newPlayerHp,
            playerEnergy = newEnergy,
            playerShield = newShield,
            enemyIntent = null,
            battleLog = (battle.battleLog + hitLog).takeLast(10),
            overlayMessage = "-${incoming} 💢",
            overlayIsPositive = false,
            lastTimingLabel = intent.label,
            comboCount = 0,
            comboMultiplier = 1f,
            perfectStreak = 0,
            animationTick = battle.animationTick + 1,
            animationEvent = AnimationEvent.PLAYER_HIT,
        )

        if (newPlayerHp <= 0) {
            uiState = uiState.copy(
                battle = updatedBattle.copy(
                    battleResolved = true,
                    overlayMessage = "💀 SCONFITTO",
                    overlayIsPositive = false,
                    battleLog = (updatedBattle.battleLog + "Sei caduto. Rewarded revive disponibile.").takeLast(10),
                    killStreak = 0,
                ),
                globalMessage = "Usa rewarded revive o riparti più forte.",
            )
        } else {
            uiState = uiState.copy(battle = updatedBattle)
        }
    }

    fun dodge() {
        val battle = uiState.battle
        val intent = battle.enemyIntent ?: return
        if (battle.dodgeAttemptsLeft <= 0) return
        val timing = evaluateTiming(battle.timingCursor)
        val fullEvade = timing == "PERFECT" || timing == "GOOD"
        val counterDamage = when (timing) {
            "PERFECT" -> (uiState.progress.attack * 0.7f).toInt()
            "GOOD" -> (uiState.progress.attack * 0.4f).toInt()
            else -> 0
        }
        val newEnemyHp = max(0, battle.enemyHp - counterDamage)
        val energyGain = when (timing) {
            "PERFECT" -> 18
            "GOOD" -> 12
            "OK" -> 6
            else -> 0
        }
        val incomingMultiplier = when (timing) {
            "OK" -> 0.45f
            "MISS" -> 0.85f
            else -> 0f
        }
        playEnemyHit()

        if (fullEvade) {
            val dodgeMsg = if (timing == "PERFECT") "⚡ PERFECT DODGE! Contrattacco +$counterDamage!" else "✓ GOOD DODGE! Counter +$counterDamage!"
            val newCombo = battle.comboCount + if (timing == "PERFECT") 2 else 1
            val newUltCharge = min(uiState.progress.maxUltimateCharge, battle.ultimateCharge + if (timing == "PERFECT") 12 else 8)
            val updatedBattle = battle.copy(
                enemyIntent = null,
                dodgeAttemptsLeft = battle.dodgeAttemptsLeft - 1,
                enemyHp = newEnemyHp,
                playerEnergy = min(uiState.progress.maxEnergy, battle.playerEnergy + energyGain),
                battleLog = (battle.battleLog + dodgeMsg).takeLast(10),
                overlayMessage = dodgeMsg.take(28),
                overlayIsPositive = true,
                comboCount = newCombo,
                comboMultiplier = 1f + (newCombo * 0.08f).coerceAtMost(0.80f),
                perfectStreak = if (timing == "PERFECT") battle.perfectStreak + 1 else battle.perfectStreak,
                ultimateCharge = newUltCharge,
                animationTick = battle.animationTick + 1,
                animationEvent = AnimationEvent.ENEMY_DODGE,
            )

            if (newEnemyHp <= 0) {
                winBattle(
                    battle = updatedBattle,
                    progress = uiState.progress,
                    newPlayerHp = updatedBattle.playerHp,
                    newEnergy = updatedBattle.playerEnergy,
                    newShield = updatedBattle.playerShield,
                    updatedCooldowns = updatedBattle.abilityCooldowns,
                    enemy = battle.enemy!!,
                    log = updatedBattle.battleLog,
                    newCombo = newCombo,
                    newUltCharge = newUltCharge,
                    perfectStreak = updatedBattle.perfectStreak,
                )
            } else {
                uiState = uiState.copy(battle = updatedBattle)
            }
            return
        }

        val reducedIntentDamage = max(2, (intent.damage * incomingMultiplier).toInt())
        var incoming = max(2, reducedIntentDamage - uiState.progress.defense)
        val shieldAbsorb = min(battle.playerShield, incoming)
        incoming -= shieldAbsorb
        val newShield = battle.playerShield - shieldAbsorb
        val newPlayerHp = battle.playerHp - incoming
        val dodgeMsg = if (timing == "OK") "↘ Graze dodge: subisci solo $incoming danni." else "✖ Dodge mancata: subisci $incoming danni."
        val updatedBattle = battle.copy(
            enemyIntent = null,
            dodgeAttemptsLeft = battle.dodgeAttemptsLeft - 1,
            playerHp = newPlayerHp,
            playerEnergy = min(uiState.progress.maxEnergy, battle.playerEnergy + energyGain),
            playerShield = newShield,
            battleLog = (battle.battleLog + dodgeMsg).takeLast(10),
            overlayMessage = if (timing == "OK") "↘ GRAZE" else "✖ FAIL",
            overlayIsPositive = timing == "OK",
            comboCount = 0,
            comboMultiplier = 1f,
            perfectStreak = 0,
            animationTick = battle.animationTick + 1,
            animationEvent = AnimationEvent.PLAYER_HIT,
        )
        if (newPlayerHp <= 0) {
            uiState = uiState.copy(
                battle = updatedBattle.copy(
                    battleResolved = true,
                    battleLog = (updatedBattle.battleLog + "Sei caduto. Rewarded revive disponibile.").takeLast(10),
                    killStreak = 0,
                ),
                globalMessage = "Usa rewarded revive o riparti più forte.",
            )
        } else {
            uiState = uiState.copy(battle = updatedBattle)
        }
    }

    fun advanceAfterBattle(activity: Activity?) {
        val battle = uiState.battle
        if (!battle.battleResolved) return
        val nextCounter = battle.interstitialCounter + 1
        if (activity != null && battle.playerHp > 0 && !uiState.progress.premium && uiState.progress.adsEnabled && nextCounter >= 3) {
            adsManager.showInterstitial(activity) { openNextStageOrMenu(0) }
            uiState = uiState.copy(battle = battle.copy(interstitialCounter = 0))
        } else {
            uiState = uiState.copy(battle = battle.copy(interstitialCounter = nextCounter))
            openNextStageOrMenu(nextCounter)
        }
    }

    private fun openNextStageOrMenu(counter: Int) {
        val battle = uiState.battle
        if (battle.playerHp <= 0) {
            navigate(Screen.MENU)
            return
        }
        val refreshed = battle.copy(
            stage = battle.stage + 1,
            battleResolved = false,
            overlayMessage = "Next Stage",
            pendingRewardCoins = 0,
            pendingRewardExp = 0,
            interstitialCounter = counter,
        )
        uiState = uiState.copy(screen = Screen.BATTLE, battle = refreshed)
        setupStage(refreshed.stage)
    }

    fun watchRewardedForRevive(activity: Activity) {
        if (uiState.progress.premium) {
            grantRevive()
            return
        }
        adsManager.showRewarded(activity, onReward = { _ -> grantRevive() }, onDismissed = { })
    }

    fun watchRewardedForCoins(activity: Activity) {
        if (uiState.progress.premium) {
            grantBonusCoins(100)
            return
        }
        adsManager.showRewarded(activity, onReward = { _ -> grantRewardedCoins() }, onDismissed = { })
    }

    private fun grantRevive() {
        val battle = uiState.battle
        if (!battle.reviveAvailable) return
        playPlayerHit(true)
        val updatedProgress = uiState.progress.copy(ultimateCharge = battle.ultimateCharge)
        repository.saveProgress(updatedProgress)
        uiState = uiState.copy(
            progress = updatedProgress,
            battle = battle.copy(
                playerHp = max(40, uiState.progress.maxHp / 2),
                playerEnergy = max(25, uiState.progress.maxEnergy / 3),
                reviveAvailable = false,
                battleResolved = false,
                overlayMessage = "💊 REVIVE!",
                overlayIsPositive = true,
                battleLog = (battle.battleLog + "💊 Rewarded Revive! Torni in battaglia.").takeLast(10),
            ),
        )
    }

    private fun grantRewardedCoins() = grantBonusCoins(100)

    private fun grantBonusCoins(amount: Int) {
        val progress = uiState.progress.copy(coins = uiState.progress.coins + amount, ultimateCharge = uiState.battle.ultimateCharge)
        repository.saveProgress(progress)
        playPlayerHit(false)
        uiState = uiState.copy(progress = progress, globalMessage = "+$amount coin dal rewarded ad.")
    }

    fun buySkin(skinId: String) {
        val progress = uiState.progress
        val skin = GameCatalog.skins.firstOrNull { it.id == skinId } ?: return
        if (skin.premiumOnly && !progress.premium) {
            uiState = uiState.copy(shopMessage = "Skin premium: richiede upgrade Premium.")
            return
        }
        if (progress.ownedSkinIds.contains(skinId)) {
            equipSkin(skinId)
            return
        }
        if (progress.coins < skin.price) {
            uiState = uiState.copy(shopMessage = "❌ Coin insufficienti per ${skin.name}.")
            return
        }
        val updated = progress.copy(
            coins = progress.coins - skin.price,
            ownedSkinIds = progress.ownedSkinIds + skinId,
            equippedSkinId = skinId,
        )
        repository.saveProgress(updated)
        uiState = uiState.copy(progress = updated, shopMessage = "✓ Acquistata ${skin.name}. Bonus attivo!")
    }

    fun equipSkin(skinId: String) {
        if (!uiState.progress.ownedSkinIds.contains(skinId)) return
        val updated = uiState.progress.copy(equippedSkinId = skinId)
        repository.saveProgress(updated)
        uiState = uiState.copy(progress = updated, shopMessage = "✓ Equipaggiata: ${currentSkin().name}")
    }

    fun spendUpgrade(stat: String) {
        val progress = uiState.progress
        if (progress.upgradePoints <= 0) return
        val updated = when (stat) {
            "attack"  -> progress.copy(attack = progress.attack + 3, upgradePoints = progress.upgradePoints - 1)
            "defense" -> progress.copy(defense = progress.defense + 2, upgradePoints = progress.upgradePoints - 1)
            "hp"      -> progress.copy(maxHp = progress.maxHp + 14, upgradePoints = progress.upgradePoints - 1)
            "crit"    -> progress.copy(critChance = minOf(progress.critChance + 0.02f, 0.60f), upgradePoints = progress.upgradePoints - 1)
            else      -> progress.copy(maxEnergy = progress.maxEnergy + 10, upgradePoints = progress.upgradePoints - 1)
        }
        repository.saveProgress(updated)
        playPlayerHit(false)
        uiState = uiState.copy(progress = updated, globalMessage = "⬆ Upgrade applicato: $stat potenziato!")
    }

    /** Spawn floating damage number; la UI lo rimuove dopo l'animazione via removeFloatingDamage(). */
    fun spawnFloatingDamage(
        text: String,
        isPerfect: Boolean = false,
        isCrit: Boolean = false,
        isHeal: Boolean = false,
        isMiss: Boolean = false,
    ) {
        val fd = FloatingDamage(
            id = System.currentTimeMillis() + rng.nextLong(0, 9999),
            text = text, isPerfect = isPerfect, isCrit = isCrit,
            isHeal = isHeal, isMiss = isMiss,
        )
        uiState = uiState.copy(battle = uiState.battle.copy(
            floatingDamages = (uiState.battle.floatingDamages + fd).takeLast(8)
        ))
    }

    fun removeFloatingDamage(id: Long) {
        uiState = uiState.copy(battle = uiState.battle.copy(
            floatingDamages = uiState.battle.floatingDamages.filter { it.id != id }
        ))
    }

    fun toggleAudio(enabled: Boolean) = updateSettings(audio = enabled)
    fun toggleHaptics(enabled: Boolean) = updateSettings(haptics = enabled)
    fun toggleAds(enabled: Boolean) = updateSettings(ads = enabled)

    private fun updateSettings(audio: Boolean? = null, haptics: Boolean? = null, ads: Boolean? = null) {
        val updated = normalizeProgress(
            uiState.progress.copy(
                audioEnabled = audio ?: uiState.progress.audioEnabled,
                hapticsEnabled = haptics ?: uiState.progress.hapticsEnabled,
                adsEnabled = ads ?: uiState.progress.adsEnabled,
            ),
        )
        repository.saveProgress(updated)
        uiState = uiState.copy(progress = updated)
    }

    fun activatePremiumLocally() {
        val updated = normalizeProgress(
            uiState.progress.copy(
                premium = true,
                adsEnabled = false,
                ownedSkinIds = uiState.progress.ownedSkinIds + "premium_oracle",
                equippedSkinId = "premium_oracle",
            ),
        )
        repository.saveProgress(updated)
        uiState = uiState.copy(progress = updated, shopMessage = "✨ PREMIUM ATTIVO! Ads rimossi, Oracle sbloccata.")
    }

    // ─── Daily Challenges ─────────────────────────────────────────────────────

    private fun checkAndResetDailyChallenges() {
        val todayStart = getTodayStartMs()
        val progress = uiState.progress
        val resetProgress = if (progress.lastDailyReset < todayStart) {
            val reset = progress.copy(
                lastDailyReset = todayStart,
                dailyKills = 0, dailyPerfectHits = 0, dailyStages = 0,
                dailyMaxCombo = 0, dailySkillUses = 0, dailyUltimatesUsed = 0,
                dailyClaimedIds = emptySet(),
            )
            repository.saveProgress(reset)
            reset
        } else progress
        uiState = uiState.copy(progress = resetProgress, todaysChallenges = getTodaysChallenges())
    }

    private fun getTodayStartMs(): Long {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun getTodaysChallenges(): List<DailyChallenge> {
        val dayIndex = (System.currentTimeMillis() / 86_400_000L).toInt()
        val pool = GameCatalog.dailyChallenges
        return (0..2).map { pool[(dayIndex * 3 + it) % pool.size] }
    }

    fun getDailyProgress(challenge: DailyChallenge): Int = with(uiState.progress) {
        when (challenge.type) {
            DailyChallengeType.KILLS -> dailyKills
            DailyChallengeType.PERFECT_HITS -> dailyPerfectHits
            DailyChallengeType.STAGES -> dailyStages
            DailyChallengeType.MAX_COMBO -> dailyMaxCombo
            DailyChallengeType.SKILL_USES -> dailySkillUses
            DailyChallengeType.ULTIMATE_FIRED -> dailyUltimatesUsed
        }
    }

    fun claimDailyChallenge(challengeId: String) {
        checkAndResetDailyChallenges()
        val challenge = uiState.todaysChallenges.firstOrNull { it.id == challengeId } ?: return
        val progress = uiState.progress
        if (progress.dailyClaimedIds.contains(challengeId)) return
        if (getDailyProgress(challenge) < challenge.target) return
        val updated = normalizeProgress(
            progress.copy(
                coins = progress.coins + challenge.coinReward,
                dailyClaimedIds = progress.dailyClaimedIds + challengeId,
            ),
        )
        repository.saveProgress(updated)
        uiState = uiState.copy(progress = updated, globalMessage = "✅ ${challenge.title}: +${challenge.coinReward} coin!")
    }

    // ──────────────────────────────────────────────────────────────────────────

    fun notifyPremiumStoreUnavailable() {
        uiState = uiState.copy(
            shopMessage = "⚠ Premium non disponibile: collega il prodotto premium_upgrade in Play Console o prova da una build distribuita da Google Play.",
            globalMessage = "Billing non pronto su questo build: premium non attivato automaticamente.",
        )
    }

    private fun trackDailyComboRecord(combo: Int) {
        val progress = uiState.progress
        if (combo <= progress.dailyMaxCombo) return
        val updated = progress.copy(dailyMaxCombo = combo)
        repository.saveProgress(updated)
        uiState = uiState.copy(progress = updated)
    }

    private fun normalizeProgress(progress: PlayerProgress): PlayerProgress {
        var updated = progress
        if (updated.level >= 2) updated = updated.copy(unlockedSkillIds = updated.unlockedSkillIds + "fracture_drive")
        if (updated.level >= 3) updated = updated.copy(unlockedSkillIds = updated.unlockedSkillIds + "afterimage_dash")
        if (updated.level >= 4) updated = updated.copy(unlockedSkillIds = updated.unlockedSkillIds + "hemorrhage_arc")
        if (updated.level >= 5) updated = updated.copy(unlockedSkillIds = updated.unlockedSkillIds + "time_warp")
        if (updated.level >= 6) updated = updated.copy(unlockedSkillIds = updated.unlockedSkillIds + "stasis_pulse")
        if (updated.level >= 7) updated = updated.copy(unlockedSkillIds = updated.unlockedSkillIds + "void_lance")
        if (updated.level >= 8) updated = updated.copy(unlockedSkillIds = updated.unlockedSkillIds + "chrono_burst")
        if (updated.premium) {
            updated = updated.copy(
                adsEnabled = false,
                ownedSkinIds = updated.ownedSkinIds + "premium_oracle",
            )
        }
        if (!updated.ownedSkinIds.contains(updated.equippedSkinId)) {
            updated = updated.copy(equippedSkinId = "chrono_default")
        }
        return updated
    }

    private fun currentSkin() = GameCatalog.skins.firstOrNull { it.id == uiState.progress.equippedSkinId }
        ?: GameCatalog.skins.first { it.id == "chrono_default" }

    private fun playPlayerHit(critical: Boolean) {
        feedbackManager.playHit(
            critical = critical,
            audioEnabled = uiState.progress.audioEnabled,
            hapticsEnabled = uiState.progress.hapticsEnabled,
        )
    }

    private fun playEnemyHit() {
        feedbackManager.playDamage(
            audioEnabled = uiState.progress.audioEnabled,
            hapticsEnabled = uiState.progress.hapticsEnabled,
        )
    }

    private fun evaluateTiming(cursor: Float): String = when {
        cursor in 0.455f..0.545f -> "PERFECT"
        cursor in 0.33f..0.67f -> "GOOD"
        cursor in 0.15f..0.85f -> "OK"
        else -> "MISS"
    }

    private fun selectEnemy(stage: Int): EnemyDefinition {
        val pool = when {
            stage <= 2 -> GameCatalog.enemies.take(4)
            stage <= 5 -> GameCatalog.enemies.take(7)
            stage <= 8 -> GameCatalog.enemies.take(10)
            stage <= 11 -> GameCatalog.enemies.take(12)
            else -> GameCatalog.enemies
        }
        return when {
            stage % 7 == 0 -> GameCatalog.enemies.last()
            stage % 5 == 0 -> pool.takeLast(3).random(rng)
            else -> pool.random(rng)
        }
    }

    private fun dodgeChargesForEnemy(enemy: EnemyDefinition): Int = when (enemy.behavior) {
        EnemyBehavior.FAST, EnemyBehavior.PHANTOM -> 2
        else -> 1
    }

    private fun scaledEnemyHp(enemy: EnemyDefinition, stage: Int, buffLabel: String?): Int {
        val modifier = 1f + (stage - 1) * 0.14f
        val bonus = when (buffLabel) {
            "Sabotage", "Future Sight" -> -15
            "Tyrant Intel" -> -24
            "Rebel Mark" -> -10
            "Greed Surge", "Cursed Power" -> 12
            else -> 0
        }
        return max(30, (enemy.maxHp * modifier).toInt() + bonus)
    }
}

class GameViewModelFactory(
    private val repository: GameRepository,
    private val feedbackManager: FeedbackManager,
    private val adsManager: AdsManager,
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GameViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return GameViewModel(repository, feedbackManager, adsManager) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
