package com.genspark.chronosshatter.ads

import android.app.Activity
import android.content.Context
import com.genspark.chronosshatter.BuildConfig
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class AdsManager(private val context: Context) {
    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null

    private val rewardedUnitId = BuildConfig.REWARDED_AD_UNIT_ID
    private val interstitialUnitId = BuildConfig.INTERSTITIAL_AD_UNIT_ID

    fun initialize() {
        MobileAds.initialize(context)
        loadRewarded()
        loadInterstitial()
    }

    fun isRewardedReady(): Boolean = rewardedAd != null

    fun loadRewarded() {
        if (rewardedUnitId.isBlank() || rewardedUnitId.contains("REPLACE_WITH_")) {
            rewardedAd = null
            return
        }
        RewardedAd.load(
            context,
            rewardedUnitId,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            },
        )
    }

    fun loadInterstitial() {
        if (interstitialUnitId.isBlank() || interstitialUnitId.contains("REPLACE_WITH_")) {
            interstitialAd = null
            return
        }
        InterstitialAd.load(
            context,
            interstitialUnitId,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            },
        )
    }

    fun showRewarded(activity: Activity, onReward: (RewardItem) -> Unit, onDismissed: () -> Unit) {
        val ad = rewardedAd
        if (ad == null) {
            onDismissed()
            loadRewarded()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                rewardedAd = null
                loadRewarded()
                onDismissed()
            }

            override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                rewardedAd = null
                loadRewarded()
                onDismissed()
            }
        }
        ad.show(activity, onReward)
    }

    fun showRewarded(activity: Activity, onReward: () -> Unit, onDismissed: () -> Unit) {
        showRewarded(activity, onReward = { onReward() }, onDismissed = onDismissed)
    }

    fun showInterstitial(activity: Activity, onDismissed: () -> Unit) {
        val ad = interstitialAd
        if (ad == null) {
            loadInterstitial()
            onDismissed()
            return
        }
        ad.fullScreenContentCallback = object : FullScreenContentCallback() {
            override fun onAdDismissedFullScreenContent() {
                interstitialAd = null
                loadInterstitial()
                onDismissed()
            }

            override fun onAdFailedToShowFullScreenContent(adError: com.google.android.gms.ads.AdError) {
                interstitialAd = null
                loadInterstitial()
                onDismissed()
            }
        }
        ad.show(activity)
    }
}
