package com.genspark.chronosshatter.audio

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class FeedbackManager(context: Context) {
    private val toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 60)
    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager)?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    fun playHit(critical: Boolean, audioEnabled: Boolean = true, hapticsEnabled: Boolean = true) {
        if (critical) playCritical(audioEnabled, hapticsEnabled)
        else playSuccess(audioEnabled, hapticsEnabled)
    }

    fun playSuccess(audioEnabled: Boolean, hapticsEnabled: Boolean) {
        if (audioEnabled) toneGenerator.startTone(ToneGenerator.TONE_PROP_ACK, 80)
        vibrate(hapticsEnabled, 40)
    }

    fun playCritical(audioEnabled: Boolean, hapticsEnabled: Boolean) {
        if (audioEnabled) toneGenerator.startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 130)
        vibrate(hapticsEnabled, 70)
    }

    fun playDamage(audioEnabled: Boolean, hapticsEnabled: Boolean) {
        if (audioEnabled) toneGenerator.startTone(ToneGenerator.TONE_PROP_NACK, 70)
        vibrate(hapticsEnabled, 30)
    }

    private fun vibrate(enabled: Boolean, durationMs: Long) {
        if (!enabled) return
        vibrator?.let {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                it.vibrate(VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                it.vibrate(durationMs)
            }
        }
    }
}
