package com.genspark.chronosshatter

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.genspark.chronosshatter.ads.AdsManager
import com.genspark.chronosshatter.audio.FeedbackManager
import com.genspark.chronosshatter.billing.BillingManager
import com.genspark.chronosshatter.data.GameRepository
import com.genspark.chronosshatter.ui.GameApp
import com.genspark.chronosshatter.viewmodel.GameViewModel
import com.genspark.chronosshatter.viewmodel.GameViewModelFactory

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels {
        GameViewModelFactory(
            repository = GameRepository(applicationContext),
            feedbackManager = FeedbackManager(applicationContext),
            adsManager = AdsManager(applicationContext),
        )
    }

    private lateinit var billingManager: BillingManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        billingManager = BillingManager(this) {
            viewModel.activatePremiumLocally()
        }
        setContent {
            GameApp(
                viewModel = viewModel,
                activity = this,
                onPremiumClick = {
                    val launched = billingManager.launchPremiumPurchase(this)
                    if (!launched) {
                        if (BuildConfig.DEBUG) {
                            viewModel.activatePremiumLocally()
                        } else {
                            viewModel.notifyPremiumStoreUnavailable()
                        }
                    }
                },
            )
        }
    }

    override fun onResume() {
        super.onResume()
        billingManager.restorePurchases()
    }
}
