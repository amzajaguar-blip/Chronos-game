package com.genspark.chronosshatter.data

import android.content.Context
import android.content.SharedPreferences
import com.genspark.chronosshatter.model.PlayerProgress

class GameRepository(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("chronos_shatter_prefs", Context.MODE_PRIVATE)

    fun loadProgress(): PlayerProgress {
        val owned = prefs.getString("owned_skins", "chrono_default")
            ?.split(",")
            ?.filter { it.isNotBlank() }
            ?.toSet()
            ?.ifEmpty { setOf("chrono_default") }
            ?: setOf("chrono_default")

        val skills = prefs.getString("skills", "temporal_slash,rewind_guard")
            ?.split(",")
            ?.filter { it.isNotBlank() }
            ?.toSet()
            ?.ifEmpty { setOf("temporal_slash", "rewind_guard") }
            ?: setOf("temporal_slash", "rewind_guard")

        return PlayerProgress(
            level = prefs.getInt("level", 1),
            exp = prefs.getInt("exp", 0),
            expToNext = prefs.getInt("exp_to_next", 100),
            coins = prefs.getInt("coins", 250),
            maxHp = prefs.getInt("max_hp", 120),
            attack = prefs.getInt("attack", 18),
            defense = prefs.getInt("defense", 6),
            maxEnergy = prefs.getInt("max_energy", 100),
            stageReached = prefs.getInt("stage_reached", 1),
            upgradePoints = prefs.getInt("upgrade_points", 0),
            ownedSkinIds = owned,
            equippedSkinId = prefs.getString("equipped_skin", "chrono_default") ?: "chrono_default",
            unlockedSkillIds = skills,
            premium = prefs.getBoolean("premium", false),
            audioEnabled = prefs.getBoolean("audio_enabled", true),
            hapticsEnabled = prefs.getBoolean("haptics_enabled", true),
            adsEnabled = prefs.getBoolean("ads_enabled", true),
            runsPlayed = prefs.getInt("runs_played", 0),
            totalEnemiesDefeated = prefs.getInt("kills", 0),
            bestStage = prefs.getInt("best_stage", prefs.getInt("stage_reached", 1)),
            ultimateCharge = prefs.getInt("ultimate_charge", 0),
            onboardingDone = prefs.getBoolean("onboarding_done", false),
            critChance = prefs.getFloat("crit_chance", 0.08f),
            lastDailyReset = prefs.getLong("last_daily_reset", 0L),
            dailyKills = prefs.getInt("daily_kills", 0),
            dailyPerfectHits = prefs.getInt("daily_perfect_hits", 0),
            dailyStages = prefs.getInt("daily_stages", 0),
            dailyMaxCombo = prefs.getInt("daily_max_combo", 0),
            dailySkillUses = prefs.getInt("daily_skill_uses", 0),
            dailyUltimatesUsed = prefs.getInt("daily_ultimates", 0),
            dailyClaimedIds = prefs.getString("daily_claimed_ids", "")
                ?.split(",")?.filter { it.isNotBlank() }?.toSet() ?: emptySet(),
        )
    }

    fun saveProgress(progress: PlayerProgress) {
        prefs.edit()
            .putInt("level", progress.level)
            .putInt("exp", progress.exp)
            .putInt("exp_to_next", progress.expToNext)
            .putInt("coins", progress.coins)
            .putInt("max_hp", progress.maxHp)
            .putInt("attack", progress.attack)
            .putInt("defense", progress.defense)
            .putInt("max_energy", progress.maxEnergy)
            .putInt("stage_reached", progress.stageReached)
            .putInt("best_stage", progress.bestStage)
            .putInt("upgrade_points", progress.upgradePoints)
            .putInt("ultimate_charge", progress.ultimateCharge)
            .putLong("last_daily_reset", progress.lastDailyReset)
            .putInt("daily_kills", progress.dailyKills)
            .putInt("daily_perfect_hits", progress.dailyPerfectHits)
            .putInt("daily_stages", progress.dailyStages)
            .putInt("daily_max_combo", progress.dailyMaxCombo)
            .putInt("daily_skill_uses", progress.dailySkillUses)
            .putInt("daily_ultimates", progress.dailyUltimatesUsed)
            .putString("daily_claimed_ids", progress.dailyClaimedIds.joinToString(","))
            .putString("owned_skins", progress.ownedSkinIds.joinToString(","))
            .putString("equipped_skin", progress.equippedSkinId)
            .putString("skills", progress.unlockedSkillIds.joinToString(","))
            .putBoolean("premium", progress.premium)
            .putBoolean("audio_enabled", progress.audioEnabled)
            .putBoolean("haptics_enabled", progress.hapticsEnabled)
            .putBoolean("ads_enabled", progress.adsEnabled)
            .putInt("runs_played", progress.runsPlayed)
            .putInt("kills", progress.totalEnemiesDefeated)
            .putBoolean("onboarding_done", progress.onboardingDone)
            .putFloat("crit_chance", progress.critChance)
            .apply()
    }
}
