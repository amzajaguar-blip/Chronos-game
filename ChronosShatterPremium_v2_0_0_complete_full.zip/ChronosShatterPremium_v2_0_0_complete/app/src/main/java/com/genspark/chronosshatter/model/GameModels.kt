package com.genspark.chronosshatter.model

import kotlin.math.max

enum class Screen {
    ONBOARDING, MENU, BATTLE, SHOP, UPGRADE, CREDITS, SETTINGS
}

enum class EnemyBehavior {
    AGGRESSIVE, DEFENSIVE, FAST, TRICKSTER, BERSERK, BOSS, PHANTOM, BERSERKER_FURY
}

enum class SkillType {
    ATTACK, HEAL, BREAK, BUFF, ULTIMATE
}

data class Skill(
    val id: String,
    val name: String,
    val description: String,
    val energyCost: Int,
    val cooldownTurns: Int,
    val type: SkillType,
    val powerMultiplier: Float = 1f,
    val flatDamage: Int = 0,
    val healAmount: Int = 0,
    val energyGain: Int = 0,
    val grantsShield: Int = 0,
    val bleedDamage: Int = 0,
    val bleedTurns: Int = 0,
    val stunTurns: Int = 0,
    val slowTurns: Int = 0,
    val isUltimate: Boolean = false,
)

data class Skin(
    val id: String,
    val name: String,
    val description: String,
    val price: Int,
    val accentHex: String,
    val npcAccentHex: String,
    val bonusCrit: Float = 0f,
    val bonusCoinsPercent: Int = 0,
    val premiumOnly: Boolean = false,
    val defaultOwned: Boolean = false,
    val rarityLabel: String = "COMMON",
)

data class EnemyDefinition(
    val id: String,
    val name: String,
    val title: String,
    val maxHp: Int,
    val attack: Int,
    val defense: Int,
    val speed: Int,
    val behavior: EnemyBehavior,
    val rewardCoins: Int,
    val rewardExp: Int,
    val colorHex: String,
    val introLine: String,
    val deathLine: String = "...",
    val enrageThreshold: Float = 0.3f,
    val enrageLine: String = "Non ancora...",
)

data class DialogueChoice(
    val text: String,
    val response: String,
    val coinsDelta: Int = 0,
    val healDelta: Int = 0,
    val enemyHpDelta: Int = 0,
    val grantSkillId: String? = null,
    val unlockSkinId: String? = null,
    val nextBattleBuff: String? = null,
    val forcedEvent: String? = null,
    val ultimateChargeBonus: Int = 0,
)

data class DialogueEvent(
    val id: String,
    val speaker: String,
    val line: String,
    val choices: List<DialogueChoice>,
)

data class RandomEvent(
    val id: String,
    val title: String,
    val description: String,
    val coinsDelta: Int = 0,
    val hpDelta: Int = 0,
    val energyDelta: Int = 0,
    val shieldDelta: Int = 0,
    val battleModifier: String? = null,
)

data class EnemyIntent(
    val label: String,
    val damage: Int,
    val energyDrain: Int = 0,
    val speedTag: String,
    val telegraphMs: Long,
)

data class PlayerProgress(
    val level: Int = 1,
    val exp: Int = 0,
    val expToNext: Int = 100,
    val coins: Int = 250,
    val maxHp: Int = 120,
    val attack: Int = 18,
    val defense: Int = 6,
    val maxEnergy: Int = 100,
    val stageReached: Int = 1,
    val upgradePoints: Int = 0,
    val ownedSkinIds: Set<String> = setOf("chrono_default"),
    val equippedSkinId: String = "chrono_default",
    val unlockedSkillIds: Set<String> = setOf("temporal_slash", "rewind_guard"),
    val premium: Boolean = false,
    val audioEnabled: Boolean = true,
    val hapticsEnabled: Boolean = true,
    val adsEnabled: Boolean = true,
    val critChance: Float = 0.08f,
    val runsPlayed: Int = 0,
    val totalEnemiesDefeated: Int = 0,
    val bestStage: Int = 0,
    val ultimateCharge: Int = 0,
    val maxUltimateCharge: Int = 100,
    val onboardingDone: Boolean = false,
    // Daily challenge tracking
    val lastDailyReset: Long = 0L,
    val dailyKills: Int = 0,
    val dailyPerfectHits: Int = 0,
    val dailyStages: Int = 0,
    val dailyMaxCombo: Int = 0,
    val dailySkillUses: Int = 0,
    val dailyUltimatesUsed: Int = 0,
    val dailyClaimedIds: Set<String> = emptySet(),
)

data class BattleRuntime(
    val stage: Int = 1,
    val playerHp: Int = 120,
    val playerEnergy: Int = 50,
    val playerShield: Int = 0,
    val enemy: EnemyDefinition? = null,
    val enemyHp: Int = 0,
    val enemyMaxHp: Int = 0,
    val enemyEnraged: Boolean = false,
    val enemyBleedTurns: Int = 0,
    val enemyBleedDamage: Int = 0,
    val enemyStunTurns: Int = 0,
    val timingSlowTurns: Int = 0,
    val timingCursor: Float = 0.5f,
    val timingForward: Boolean = true,
    val timingSpeed: Float = 0.022f,
    val abilityCooldowns: Map<String, Int> = emptyMap(),
    val battleLog: List<String> = listOf("Il frammento temporale si apre."),
    val overlayMessage: String = "",
    val overlayIsPositive: Boolean = true,
    val lastTimingLabel: String = "",
    val enemyIntent: EnemyIntent? = null,
    val enemyIntentStartedAt: Long = 0L,
    val dodgeAttemptsLeft: Int = 1,
    val reviveAvailable: Boolean = true,
    val battleResolved: Boolean = false,
    val pendingRewardCoins: Int = 0,
    val pendingRewardExp: Int = 0,
    val pendingDialogue: DialogueEvent? = null,
    val pendingRandomEvent: RandomEvent? = null,
    val activeBuffLabel: String? = null,
    val encounterLabel: String = "Frattura standard",
    val interstitialCounter: Int = 0,
    val comboCount: Int = 0,
    val comboMultiplier: Float = 1f,
    val killStreak: Int = 0,
    val perfectStreak: Int = 0,
    val ultimateCharge: Int = 0,
    val showBossIntro: Boolean = false,
    val totalDamageDealt: Int = 0,
    val animationTick: Int = 0,
    val animationEvent: AnimationEvent = AnimationEvent.NONE,
    val floatingDamages: List<FloatingDamage> = emptyList(),
)

enum class AnimationEvent {
    NONE,
    PLAYER_HIT,
    PLAYER_CRIT,
    PLAYER_PERFECT,
    PLAYER_ULTIMATE,
    ENEMY_DODGE,
}

/** Represents a single floating damage number spawned during battle. */
data class FloatingDamage(
    val id: Long,
    val text: String,
    val isPerfect: Boolean = false,
    val isCrit: Boolean = false,
    val isHeal: Boolean = false,
    val isMiss: Boolean = false,
)

enum class UpgradeStat(val label: String, val icon: String, val delta: String) {
    ATTACK("Attacco", "⚔", "+3 ATK"),
    DEFENSE("Difesa", "🛡", "+2 DEF"),
    HP("Salute", "❤", "+14 HP"),
    ENERGY("Energia", "⚡", "+10 EN"),
    CRIT("Critico", "💥", "+2% CRIT"),
}

enum class DailyChallengeType { KILLS, PERFECT_HITS, STAGES, MAX_COMBO, SKILL_USES, ULTIMATE_FIRED }

data class DailyChallenge(
    val id: String,
    val title: String,
    val description: String,
    val type: DailyChallengeType,
    val target: Int,
    val coinReward: Int,
)

data class GameUiState(
    val screen: Screen = Screen.MENU,
    val progress: PlayerProgress = PlayerProgress(),
    val battle: BattleRuntime = BattleRuntime(),
    val shopMessage: String = "Sblocca skin con bonus leggeri e stile unico.",
    val globalMessage: String = "Chronos Shatter: loop rapido, leggibile e monetizzabile.",
    val todaysChallenges: List<DailyChallenge> = emptyList(),
)

fun PlayerProgress.applyLevelProgress(expGain: Int): PlayerProgress {
    var updated = copy(exp = exp + expGain)
    var currentExp = updated.exp
    var currentLevel = updated.level
    var needed = updated.expToNext
    var upgradePoints = updated.upgradePoints
    var maxHp = updated.maxHp
    var attack = updated.attack
    var defense = updated.defense
    var maxEnergy = updated.maxEnergy

    while (currentExp >= needed) {
        currentExp -= needed
        currentLevel += 1
        upgradePoints += 1
        maxHp += 8
        attack += 2
        defense += 1
        maxEnergy += 4
        needed = max(100, (needed * 1.18f).toInt())
    }

    return updated.copy(
        exp = currentExp,
        level = currentLevel,
        expToNext = needed,
        upgradePoints = upgradePoints,
        maxHp = maxHp,
        attack = attack,
        defense = defense,
        maxEnergy = maxEnergy,
    )
}
