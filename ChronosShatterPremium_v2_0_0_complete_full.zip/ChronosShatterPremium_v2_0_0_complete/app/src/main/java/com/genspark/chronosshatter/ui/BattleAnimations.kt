package com.genspark.chronosshatter.ui

/*
 * ═══════════════════════════════════════════════════════════════════════════
 *  STATO INTEGRAZIONE: COMPLETA
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *  ✅ Model:     aggiunto `animationTick: Int` e `animationEvent: AnimationEvent`
 *                in BattleRuntime (GameModels.kt).
 *  ✅ ViewModel: basicAttack / useSkill / resolveEnemyAttack / dodge
 *                incrementano il tick e settano l'evento corretto.
 *  ✅ Helper:    questo file definisce rememberScreenShake, PerfectFlashOverlay,
 *                rememberEnemyHitPulse. Sono pronti all'uso.
 *
 *  ✅ UI wiring: GameApp.kt usa shake, flash e pulse durante il combattimento.
 *                Le animazioni ora sono effettivamente visibili in battle scene.
 *
 *  Senza il wiring il progetto compila lo stesso: i campi sono presenti nel
 *  modello (con default 0 / NONE) e non rompono nulla di esistente.
 * ═══════════════════════════════════════════════════════════════════════════
 */

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import com.genspark.chronosshatter.model.AnimationEvent
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Screen-shake decaying sinusoidal offset driven by an external tick.
 * Returns a pair (offsetX, offsetY) in density-independent pixels.
 *
 * `intensity` in dp at peak. Decays over `durationMs` to zero.
 * Change `tickKey` to re-trigger the animation (e.g. battle.animationTick).
 */
@Composable
fun rememberScreenShake(
    tickKey: Int,
    event: AnimationEvent,
): Pair<Float, Float> {
    val offsetX = remember { Animatable(0f) }
    val offsetY = remember { Animatable(0f) }

    LaunchedEffect(tickKey) {
        val (peak, durationMs) = when (event) {
            AnimationEvent.PLAYER_ULTIMATE -> 18f to 420
            AnimationEvent.PLAYER_PERFECT -> 10f to 260
            AnimationEvent.PLAYER_CRIT -> 12f to 300
            AnimationEvent.PLAYER_HIT -> 7f to 220
            AnimationEvent.ENEMY_DODGE -> 4f to 180
            AnimationEvent.NONE -> return@LaunchedEffect
        }
        val steps = 8
        val stepDur = durationMs / steps
        val seed = Random(tickKey.toLong())
        // Damped oscillation: each step picks a random angle and shrinking magnitude.
        repeat(steps) { i ->
            val decay = 1f - (i / steps.toFloat())
            val angle = seed.nextFloat() * 2f * Math.PI.toFloat()
            val dx = (cos(angle) * peak * decay)
            val dy = (sin(angle) * peak * decay)
            offsetX.animateTo(dx, tween(stepDur, easing = FastOutLinearInEasing))
            offsetY.animateTo(dy, tween(stepDur, easing = FastOutLinearInEasing))
        }
        offsetX.animateTo(0f, tween(90, easing = LinearOutSlowInEasing))
        offsetY.animateTo(0f, tween(90, easing = LinearOutSlowInEasing))
    }

    return offsetX.value to offsetY.value
}

/**
 * Full-screen flash overlay that fades out quickly. Colour depends on event.
 * Place inside a Box with fillMaxSize to cover the battle scene.
 */
@Composable
fun PerfectFlashOverlay(tickKey: Int, event: AnimationEvent) {
    val alpha = remember { Animatable(0f) }

    LaunchedEffect(tickKey) {
        val (peakAlpha, durationMs) = when (event) {
            AnimationEvent.PLAYER_ULTIMATE -> 0.55f to 450
            AnimationEvent.PLAYER_PERFECT -> 0.35f to 260
            AnimationEvent.PLAYER_CRIT -> 0.22f to 200
            AnimationEvent.ENEMY_DODGE -> 0.28f to 240
            else -> return@LaunchedEffect
        }
        alpha.snapTo(peakAlpha)
        alpha.animateTo(0f, tween(durationMs, easing = LinearOutSlowInEasing))
    }

    val flashColor = when (event) {
        AnimationEvent.PLAYER_ULTIMATE -> Color(0xFFFDE68A)   // oro caldo
        AnimationEvent.PLAYER_PERFECT -> Color.White
        AnimationEvent.PLAYER_CRIT -> Color(0xFFFCA5A5)       // rosso chiaro
        AnimationEvent.ENEMY_DODGE -> Color(0xFF93C5FD)       // azzurro
        else -> Color.Transparent
    }

    if (alpha.value > 0.001f) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { this.alpha = alpha.value }
                .background(flashColor),
        )
    }
}

/**
 * Scale pulse driven by tick. Returns a scale factor (float, around 1f).
 * Use via Modifier.graphicsLayer { scaleX = value; scaleY = value }.
 * Only pulses for PLAYER_CRIT / PERFECT / ULTIMATE - i.e. when the enemy is being hit hard.
 */
@Composable
fun rememberEnemyHitPulse(tickKey: Int, event: AnimationEvent): Float {
    val scale = remember { Animatable(1f) }

    LaunchedEffect(tickKey) {
        val peak = when (event) {
            AnimationEvent.PLAYER_ULTIMATE -> 1.18f
            AnimationEvent.PLAYER_PERFECT -> 1.12f
            AnimationEvent.PLAYER_CRIT -> 1.10f
            AnimationEvent.PLAYER_HIT -> 1.04f
            else -> return@LaunchedEffect
        }
        scale.animateTo(peak, tween(110, easing = FastOutLinearInEasing))
        scale.animateTo(1f, tween(180, easing = LinearOutSlowInEasing))
    }

    return scale.value
}
