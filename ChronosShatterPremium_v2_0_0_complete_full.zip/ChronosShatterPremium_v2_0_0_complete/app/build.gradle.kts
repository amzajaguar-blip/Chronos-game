plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val testAdmobAppId = "ca-app-pub-3940256099942544~3347511713"
val testRewardedId = "ca-app-pub-3940256099942544/5224354917"
val testInterstitialId = "ca-app-pub-3940256099942544/1033173712"

val releaseAdmobAppId = providers.gradleProperty("ADMOB_APP_ID_RELEASE").orElse("REPLACE_WITH_PRODUCTION_ADMOB_APP_ID")
val releaseRewardedId = providers.gradleProperty("ADMOB_REWARDED_ID_RELEASE").orElse("REPLACE_WITH_PRODUCTION_REWARDED_ID")
val releaseInterstitialId = providers.gradleProperty("ADMOB_INTERSTITIAL_ID_RELEASE").orElse("REPLACE_WITH_PRODUCTION_INTERSTITIAL_ID")

android {
    namespace = "com.genspark.chronosshatter"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.genspark.chronosshatter"
        minSdk = 26
        targetSdk = 34
        versionCode = 5
        versionName = "2.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }

        // defaultConfig: usa sempre TEST IDs per sicurezza. I production IDs vengono
        // applicati solo dalla buildType "release" tramite override esplicito.
        manifestPlaceholders["admob_app_id"] = testAdmobAppId
        buildConfigField("String", "REWARDED_AD_UNIT_ID", "\"$testRewardedId\"")
        buildConfigField("String", "INTERSTITIAL_AD_UNIT_ID", "\"$testInterstitialId\"")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            manifestPlaceholders["admob_app_id"] = releaseAdmobAppId.get()
            buildConfigField("String", "REWARDED_AD_UNIT_ID", "\"${releaseRewardedId.get()}\"")
            buildConfigField("String", "INTERSTITIAL_AD_UNIT_ID", "\"${releaseInterstitialId.get()}\"")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
            manifestPlaceholders["admob_app_id"] = testAdmobAppId
            buildConfigField("String", "REWARDED_AD_UNIT_ID", "\"$testRewardedId\"")
            buildConfigField("String", "INTERSTITIAL_AD_UNIT_ID", "\"$testInterstitialId\"")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

val hasRealReleaseAdIds = listOf(
    releaseAdmobAppId.get(),
    releaseRewardedId.get(),
    releaseInterstitialId.get(),
).none { it.isBlank() || it.contains("REPLACE_WITH_") }

tasks.register("verifyReleaseMonetizationConfig") {
    doLast {
        check(hasRealReleaseAdIds) {
            "Configura ID AdMob reali in gradle.properties prima di buildare release / Play Store."
        }
    }
}

tasks.matching { it.name in setOf("preReleaseBuild", "assembleRelease", "bundleRelease") }.configureEach {
    dependsOn("verifyReleaseMonetizationConfig")
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.06.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.activity:activity-compose:1.9.1")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.4")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.navigation:navigation-compose:2.7.7")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.google.android.gms:play-services-ads:23.2.0")
    implementation("com.android.billingclient:billing-ktx:7.0.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
}
