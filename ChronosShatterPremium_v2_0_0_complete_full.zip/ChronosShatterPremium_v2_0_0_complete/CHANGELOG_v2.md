# Chronos Shatter Premium — v2.0.0 Changelog

## 🐛 Bug Fix Critici

### 1. `build.gradle.kts` — AdMob IDs sbagliati in `defaultConfig`
- **PRIMA**: `defaultConfig` usava `releaseAdmobAppId` (produzione) come fallback,
  quindi ogni build non-release caricava gli ID di produzione — rischio ban AdMob.
- **DOPO**: `defaultConfig` usa esplicitamente `testAdmobAppId` / `testRewardedId` /
  `testInterstitialId`. La build `release` li sovrascrive con quelli di produzione.

---

## ✨ Nuove Feature

### 2. `Screen.ONBOARDING` + `OnboardingScreen`
- 3 slide orizzontali con `HorizontalPager` (Compose Foundation).
- Dot indicator animati con click-to-jump.
- Bottone "Salta" discreto per chi vuole saltare.
- Mostrata **una sola volta** al primo avvio; stato persistito in `SharedPreferences`
  (`onboarding_done`). Può essere resettata cancellando i dati dell'app.
- Background gradiente animato che pulsa con il colore dell'accent slide corrente.

### 3. `Screen.UPGRADE` + `UpgradeScreen` dedicata
- Sostituisce il pannello inline del menu con una schermata completa.
- Mostra 5 stat aggiornabili: ATK, DEF, HP, EN e **CRIT** (nuovo!).
- Card interattive con animazione scale e colori che cambiano in base alla disponibilità
  di punti upgrade.
- Barra XP con preview del progresso verso il prossimo livello.
- Mostra i bonus passivi della skin equipaggiata (+% critico, +% monete).
- Badge rosso sul pulsante del menu principale quando ci sono punti disponibili.

### 4. Floating Damage Numbers
- Sistema di numeri danni animati che appaiono durante il combattimento.
- Colori distinti per tipo: bianco (normale), giallo (PERFECT), rosso (critico),
  verde (cura), grigio (MISS).
- Font più grande per PERFECT e critico.
- Animazione di risalita + fade out in 900ms, spawn multiplo simultaneo (max 8).
- Integrati nativamente nel `ViewModel`: ogni hit, cura e miss spawna automaticamente.
- Rimossi dalla lista via `removeFloatingDamage()` dopo l'animazione.

### 5. Nuova stat `critChance` su `PlayerProgress`
- Valore di default 8%, massimo 60%.
- Persista in `SharedPreferences` come `Float`.
- Aggiornabile dallo `UpgradeScreen` con incrementi di +2%.

### 6. `completeOnboarding()` nel ViewModel
- Persiste `onboardingDone = true` e naviga al menu.
- L'`init` del ViewModel controlla il flag e instrada all'`ONBOARDING` se necessario.

---

## 📁 File Modificati

| File | Tipo modifica |
|------|---------------|
| `app/build.gradle.kts` | Fix defaultConfig AdMob IDs + dep `foundation` |
| `model/GameModels.kt` | Screen enum, `FloatingDamage`, `UpgradeStat`, `critChance`, `onboardingDone`, `floatingDamages` in `BattleRuntime` |
| `data/GameRepository.kt` | Persist/load `onboardingDone`, `critChance` |
| `viewmodel/GameViewModel.kt` | `completeOnboarding()`, `spawnFloatingDamage()`, `removeFloatingDamage()`, `spendUpgrade("crit")`, spawn FD su ogni hit/heal/miss, init con onboarding check |
| `ui/GameApp.kt` | Router +2 schermate, `OnboardingScreen`, `UpgradeScreen`, `UpgradeStatCard`, `FloatingDamageOverlay`, `FloatingDamageNumber`, badge upgrade, opt-in Foundation |

---

## 🔧 Note per il Deploy

- Per la build **debug**: IDs AdMob di test vengono usati automaticamente.
- Per la build **release**: imposta in `gradle.properties`:
  ```
  ADMOB_APP_ID_RELEASE=ca-app-pub-XXXX~YYYY
  ADMOB_REWARDED_ID_RELEASE=ca-app-pub-XXXX/YYYY
  ADMOB_INTERSTITIAL_ID_RELEASE=ca-app-pub-XXXX/YYYY
  ```
- Il task `verifyReleaseMonetizationConfig` blocca la release se gli ID sono placeholder.
