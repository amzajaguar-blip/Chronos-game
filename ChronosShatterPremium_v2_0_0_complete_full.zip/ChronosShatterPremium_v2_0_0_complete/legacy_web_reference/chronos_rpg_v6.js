// ============================================================
//  CHRONO-SHATTER  — v6.0  "RPG Evolution — Incollato Allo Schermo"
//  Engine  : Phaser 3.60+
//
//  NOVITÀ v5.0:
//  • Arrow class          (Object Pooling, fisica reale)
//  • Enemy class v2       (State Machine: idle/move/attack/dead,
//                          animazioni per tipo, barra HP live,
//                          arciere con kiting + frecce pooled,
//                          popup danno flottante)
//  • damagePlayer()       (danno centralizzato con i-frames)
//  • showDamagePopup()    (testo flottante -N rosso)
//  • Animazioni nemici    (idle/walk/attack/death per tipo)
//  • enemy.update()       (state machine, non più updateAI)
//
//  SISTEMI PRECEDENTI INVARIATI:
//  • NarrativeEngine  • TravelManager  • SaveManager
//  • WeaponStats      • HapticFeedback • WeatherSystem
//  • MalakorBoss      • ShopScene      • WeddingScene
//  • CreditsScene     • MainMenuScene
// ============================================================

'use strict';

// ──────────────────────────────────────────────────────────────
//  COSTANTI GLOBALI
// ──────────────────────────────────────────────────────────────
const GAME_W          = 800;
const GAME_H          = 600;
const DAVID_SPEED     = 180;
const DAVID_JUMP      = -340;
const GRAVITY_Y       = 650;
const MAX_KILL_STREAK = 100;
const MAX_AFFINITY    = 100;
const TOTAL_PARTS     = 5;

// ──────────────────────────────────────────────────────────────
//  STATO GLOBALE
// ──────────────────────────────────────────────────────────────
const INITIAL_STATE = {
  currentScene : 'ChronosScene',
  currentZone  : 'Accampamento',
  david: { hp:100, maxHp:100, gold:0, killStreak:0 },
  inventory: { motoPezzi:[], hasChainsaw:true, hasShotgun:true },
  narrative: {
    erikRespect:0, forestTriggered:false, bossDefeated:false,
    nuclearDone:false, malakorAwakened:false, lastFormulaCorrect:true
  },
  upgrades: { shotgun:{ level:0 }, chainsaw:{ level:0 } },
  settings: { removeAds:false }
};

if (!window.gameState) {
  window.gameState = JSON.parse(JSON.stringify(INITIAL_STATE));
}

// ──────────────────────────────────────────────────────────────
//  WEAPON STATS
// ──────────────────────────────────────────────────────────────
const WeaponStats = {
  SHOTGUN: {
    baseDamage:85, range:150, spreadY:45, shakeAmt:0.05,
    upgrades:[
      { label:'Canna Cromata',               bonus:{ damage:20, range:20 } },
      { label:'Proiettili a Frammentazione', bonus:{ damage:35, range:10 } },
      { label:'Slug Temporale',              bonus:{ damage:50, range:30, slow:true } }
    ]
  },
  CHAINSAW: {
    baseDamage:12, range:55, streakBonus:2, vibration:0.002,
    upgrades:[
      { label:'Denti in Diamante',   bonus:{ damage:8,  ignoreArmor:true } },
      { label:'Sovraccarico Plasma', bonus:{ damage:20, aoe:true } },
      { label:'Modalità Salsiccium', bonus:{ damage:50, transform:true } }
    ]
  }
};

// ──────────────────────────────────────────────────────────────
//  ZONE ITEMS
// ──────────────────────────────────────────────────────────────
const ZoneItems = {
  Accampamento: { key:'giacca_hitech',      label:'Giacca Hi-Tech' },
  Campi:        { key:'candela_accensione', label:"Candela d'Accensione" },
  Villaggio:    { key:'lama_plasma',        label:'Lama al Plasma' },
  BoscoNero:    { key:'tomo',               label:"Tomo dell'Eternità" },
  Castelnero:   { key:'nucleo_energetico',  label:'Nucleo Energetico' }
};
const ZONE_ORDER = ['Accampamento','Campi','Villaggio','BoscoNero','Castelnero'];

// ──────────────────────────────────────────────────────────────
//  DIALOGUES
// ──────────────────────────────────────────────────────────────
const DIALOGUES = {
  erikIntro:[
    { name:'ERIK IL ROSSO', text:'Fermo! Non un passo di più, straniero. Le tue vesti brillano come squame di drago e i tuoi occhi hanno visto mondi che non esistono. Sei un demone o un folle?' },
    { name:'DAVID',         text:"Senti, 'Grande Capo', non so come sono finito nel tuo fango, ma se fossi un demone avresti già smesso di respirare. Chiamami David. E ridammi la mia sacca." },
    { name:'ERIK IL ROSSO', text:'Ti offro un patto: aiutaci a spezzare la maledizione del Bosco, e la tua testa resterà sulle tue spalle.' },
    { name:'DAVID',         text:'Patto fatto. Ma se provate a bruciarmi sul rogo, sappi che ho un caratteraccio.' }
  ],
  elaraIntro:[
    { name:'LADY ELARA', text:'Dicono che nel tuo mondo le carrozze volino e che non esistano le tenebre. Perché sei così triste, David?' },
    { name:'DAVID',      text:'Perché da dove vengo abbiamo illuminato tutto ma non sappiamo più guardare le stelle. Tu sei vera.' },
    { name:'LADY ELARA', text:"Torna da me. Il tempo non deve portarti via di nuovo." },
    { name:'DAVID',      text:'Farò di meglio. Ti porterò a fare un giro quando avrò riparato la mia bestia di ferro.' }
  ],
  forest:[
    { name:'ERIK IL ROSSO', text:'Questo posto puzza di carogna e magia vecchia di secoli. Tieni pronto il bastone di fuoco.' },
    { name:'DAVID',         text:"Tranquillo, Erik. Finché la batteria della sega regge non passerà nessuno. Aldous, quanto manca?" },
    { name:'ALDOUS',        text:"Siamo arrivati. Ecco il Tomo. La formula deve essere perfetta!" },
    { name:'DAVID',         text:"Dimmela un'ultima volta. Non sono mai stato bravo in letteratura." },
    { name:'ALDOUS',        text:'Ascolta bene: Veritatis, Aeternum, Silencium. Se sbagli anche solo una sillaba risveglierai ciò che dovrebbe restare sepolto.' },
    { name:'ERIK IL ROSSO', text:'Fallo e basta, fratello. Voglio tornare al castello a bere idromele.' }
  ],
  forestSuccess:[
    { name:'ALDOUS',        text:"Hai pronunciato le parole esatte. Il Tomo è salvo per l'eternità." },
    { name:'DAVID',         text:'Sapevo che la termodinamica alla fine avrebbe vinto.' },
    { name:'ERIK IL ROSSO', text:'Sei il guerriero più strano che abbia mai combattuto al mio fianco. Sei un fratello, David.' }
  ],
  forestFail:[
    { name:'DAVID',   text:'VERITATIS! AETERNUM! SALSICCIUM!' },
    { name:'ALDOUS',  text:'No... DAVID! Hai rotto il sigillo!' },
    { name:'MALAKOR', text:'GRAZIE, VIAGGIATORE. IL TUO ERRORE È LA MIA LIBERAZIONE!' }
  ],
  battle:[
    { name:'MALAKOR',       text:'SORGETE, MIEI GUERRIERI! DISTRUGGETE TUTTO!' },
    { name:'DAVID',         text:"Erik, spero che tu sia pronto. Ho solo metà caricatore." },
    { name:'ERIK IL ROSSO', text:'PER LA CASATA DEL LUPO! PER DAVID!' }
  ],
  bossDeathDialogue:[
    { name:'MALAKOR', text:'Impossibile... un semplice errore di calcolo...' },
    { name:'DAVID',   text:'Non è stato un errore. È stata una scelta.' }
  ],
  nuclear:[
    { name:'DAVID',   text:"Ehi Malakor! Nel futuro abbiamo un detto: 'Porta una bomba a una rissa di coltelli'. ANNIENTAMENTO NUCLEARE IN CORSO!" },
    { name:'MALAKOR', text:'NON È POSSIBILE… QUESTA NON È MAGIA!' },
    { name:'DAVID',   text:'No, amico. Si chiama fisica applicata. Addio.' }
  ],
  finalBike:[
    { name:'DAVID',         text:"Erik! Sali dietro. Ti faccio vedere cosa significa 300 all'ora." },
    { name:'ERIK IL ROSSO', text:'Questa bestia di ferro ruggisce più di un drago! Andiamo, fratello di sangue!' }
  ],
  wedding:[
    { name:'ERIK IL ROSSO', text:'David del Futuro, Elara di Aethelgard… avete versato sangue insieme, ora berrete dallo stesso calice.' },
    { name:'ERIK IL ROSSO', text:'David, vuoi proteggere questo regno come hai protetto quel maledetto libro?' },
    { name:'DAVID',         text:"Solo se la formula per 'Sì' è più facile di quella del Bosco Nero. Lo voglio." },
    { name:'IA DEL CASCO',  text:'Rilevato picco di serotonina. Congratulazioni, David. Il futuro è ufficialmente cancellato.' }
  ],
  weddingHighAffinity: [{ name:'ERIK IL ROSSO', text:'Sono orgoglioso di te, fratello.' }],
  weddingLowAffinity:  [{ name:'ERIK IL ROSSO', text:'Non mi fido ancora completamente di te. Ma hai salvato Castelnero.' }],
  marketingQuotes:[
    "Senti, con quella spada di ferro non arrivi lontano. Ti serve tecnologia.",
    "Rimuovi gli annunci e ti prometto che non sbaglierò più la formula… forse.",
    "Hai dell'oro? Bene, perché la mia motosega non funziona a sorrisi."
  ]
};

// ──────────────────────────────────────────────────────────────
//  HAPTIC FEEDBACK
// ──────────────────────────────────────────────────────────────
class HapticFeedback {
  static chainsawRumble()   { if (navigator.vibrate) navigator.vibrate([50,30,50,30,50]); }
  static nuclearExplosion() { if (navigator.vibrate) navigator.vibrate([500,100,500,100,1000]); }
  static takeDamage()       { if (navigator.vibrate) navigator.vibrate(200); }
  static lightTap()         { if (navigator.vibrate) navigator.vibrate(20); }
}

// ──────────────────────────────────────────────────────────────
//  SAVE MANAGER
// ──────────────────────────────────────────────────────────────
class SaveManager {
  static SLOT = 'ChronoShatter_SaveSlot_1';

  static save(scene) {
    const gs = window.gameState;
    const snap = {
      currentScene : 'ChronosScene',
      currentZone  : scene.currentZone || gs.currentZone,
      david: {
        hp         : (scene.davidHp  !== undefined) ? scene.davidHp  : gs.david.hp,
        maxHp      : gs.david.maxHp,
        gold       : (scene.gold     !== undefined) ? scene.gold     : gs.david.gold,
        killStreak : (scene.killStreak !== undefined) ? scene.killStreak : gs.david.killStreak
      },
      inventory: JSON.parse(JSON.stringify(gs.inventory)),
      narrative: JSON.parse(JSON.stringify(gs.narrative)),
      upgrades:  JSON.parse(JSON.stringify(gs.upgrades)),
      settings:  JSON.parse(JSON.stringify(gs.settings))
    };
    try { localStorage.setItem(SaveManager.SLOT, JSON.stringify(snap)); }
    catch (e) { console.warn('[SaveManager] Errore:', e); }
  }

  static load() {
    try {
      const raw = localStorage.getItem(SaveManager.SLOT);
      if (!raw) return false;
      const data = JSON.parse(raw);
      window.gameState = Object.assign(JSON.parse(JSON.stringify(INITIAL_STATE)), data);
      window.gameState.settings.removeAds =
        localStorage.getItem('remove_ads') === 'true' || window.gameState.settings.removeAds;
      return true;
    } catch (e) { console.warn('[SaveManager] Errore caricamento:', e); return false; }
  }

  static reset() {
    localStorage.removeItem(SaveManager.SLOT);
    window.gameState = JSON.parse(JSON.stringify(INITIAL_STATE));
  }

  static hasSave() { return localStorage.getItem(SaveManager.SLOT) !== null; }
}

// ──────────────────────────────────────────────────────────────
//  WEATHER SYSTEM
// ──────────────────────────────────────────────────────────────
class WeatherSystem {
  constructor(scene) {
    this.scene = scene;
    this.isRaining = false;
    this.rainEmitter = null;
  }
  setNightTime() {
    this.scene.cameras.main.setTint(0x1a2b4c);
    this.scene.showFloatingText('🌙 È calata la notte. I nemici sono più aggressivi.');
    this.scene.enemies.getChildren().forEach(e => {
      if (e.stats) e.stats.speed = Math.floor(e.stats.speed * 1.2);
    });
  }
  clearNight() { this.scene.cameras.main.clearTint(); }
  startRain() {
    if (this.isRaining) return;
    this.isRaining = true;
    try {
      this.rainEmitter = this.scene.add.particles(0, -50, 'assets', {
        frame:'raindrop', x:{ min:0, max:this.scene.mapW || GAME_W },
        speedY:{ min:420, max:620 }, speedX:{ min:-40, max:40 },
        lifespan:1400, scale:{ start:0.4, end:0 }, quantity:8,
        blendMode:'ADD', emitting:true
      });
    } catch (_) { /* frame opzionale */ }
    this.scene.david.setMaxVelocity(140, 600);
  }
  stopRain() {
    if (!this.isRaining) return;
    this.isRaining = false;
    if (this.rainEmitter) { this.rainEmitter.destroy(); this.rainEmitter = null; }
    this.scene.david.setMaxVelocity(DAVID_SPEED + 40, 600);
  }
}

// ──────────────────────────────────────────────────────────────
//  NARRATIVE ENGINE
// ──────────────────────────────────────────────────────────────
class NarrativeEngine {
  constructor(scene) { this.scene = scene; }

  startForestEvent() {
    this.scene.dlg.start(DIALOGUES.forest, () => this._promptFormulaChoice());
  }

  _promptFormulaChoice() {
    this.scene.showChoiceButtons(
      'Veritatis Aeternum Silencium',
      'Veritatis Aeternum Salsiccium',
      (isCorrect) => this._processChoice(isCorrect)
    );
  }

  _processChoice(isCorrect) {
    window.gameState.narrative.lastFormulaCorrect = isCorrect;
    if (isCorrect) {
      window.gameState.narrative.forestTriggered = true;
      window.gameState.narrative.erikRespect =
        Math.min(window.gameState.narrative.erikRespect + 30, MAX_AFFINITY);
      this.scene.dlg.start(DIALOGUES.forestSuccess, () => {
        SaveManager.save(this.scene);
        this.scene._triggerWeddingSequence();
      });
    } else {
      window.gameState.narrative.malakorAwakened = true;
      this.scene.cameras.main.flash(900, 255, 0, 0, false, (_c, p) => {
        if (p === 1) {
          this.scene.dlg.start(DIALOGUES.forestFail, () => {
            this.scene._startBossBattle(() => this._onBossDefeated());
          });
        }
      });
    }
  }

  _onBossDefeated() {
    window.gameState.narrative.bossDefeated = true;
    this.scene.dlg.start(
      [{ name:'DAVID', text:'Troppi scheletri… Erik, coprimi! Attivo il protocollo nucleare!' }],
      () => this.scene._executeNuclearStrike(() => this.scene._triggerWeddingSequence())
    );
  }
}

// ──────────────────────────────────────────────────────────────
//  TRAVEL MANAGER
// ──────────────────────────────────────────────────────────────
class TravelManager {
  constructor(scene) { this.scene = scene; }
  travelTo(targetZone, entryPoint = 'west') {
    SaveManager.save(this.scene);
    const cam = this.scene.cameras.main;
    cam.fadeOut(500, 0, 0, 0);
    cam.once('camerafadeoutcomplete', () => {
      this.scene.currentZone = targetZone;
      window.gameState.currentZone = targetZone;
      this.scene.refreshZone(entryPoint);
      cam.fadeIn(500, 0, 0, 0);
    });
  }
}

// ──────────────────────────────────────────────────────────────
//  DIALOGUE MANAGER
// ──────────────────────────────────────────────────────────────
class DialogueManager {
  constructor(scene) {
    this.scene = scene; this.active = false;
    this.lines = []; this.index = 0;
    this.onEnd = null; this._tw = null;
  }
  start(lines, onEnd = null) {
    this.lines = lines; this.index = 0;
    this.active = true; this.onEnd = onEnd;
    this._showLine();
  }
  _showLine() {
    if (this.index >= this.lines.length) { this.end(); return; }
    const l = this.lines[this.index];
    this.scene.nameText.setText(l.name).setVisible(true);
    this.scene.dialogueBox.setVisible(true);
    this.scene.messageText.setText('').setVisible(true);
    this.scene.promptIndicator.setVisible(false);
    if (this._tw) { this._tw.remove(false); this._tw = null; }
    let i = 0;
    this._tw = this.scene.time.addEvent({
      delay:28, repeat:l.text.length - 1,
      callback:() => {
        this.scene.messageText.text += l.text[i++];
        if (i >= l.text.length) { this._tw = null; this.scene.promptIndicator.setVisible(true); }
      }
    });
  }
  advance() {
    if (!this.active) return;
    if (this._tw) {
      this._tw.remove(false); this._tw = null;
      const l = this.lines[this.index];
      this.scene.messageText.setText(l.text);
      this.scene.promptIndicator.setVisible(true);
      return;
    }
    this.index++;
    this._showLine();
  }
  end() {
    this.active = false;
    this.scene.dialogueBox.setVisible(false);
    this.scene.nameText.setVisible(false);
    this.scene.messageText.setVisible(false);
    this.scene.promptIndicator.setVisible(false);
    if (this.onEnd) { const cb = this.onEnd; this.onEnd = null; cb(); }
  }
}

// ──────────────────────────────────────────────────────────────
//  ARROW  (Object Pooling)
// ──────────────────────────────────────────────────────────────
class Arrow extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y) {
    // Prova il frame 'freccia' dell'atlas; fallback su 'particle_distort'
    super(scene, x, y, 'assets', 'freccia');
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.speed  = 300;
    this.damage = 15;
    this.setActive(false).setVisible(false);
    this.body.allowGravity = false;   // le frecce volano dritto
  }

  // Lancia la freccia da shooter verso target
  fire(shooter, target) {
    this.setPosition(shooter.x, shooter.y);
    this.setActive(true).setVisible(true);
    const angle = Phaser.Math.Angle.Between(shooter.x, shooter.y, target.x, target.y);
    this.setRotation(angle);
    this.scene.physics.moveToObject(this, target, this.speed);
  }

  // Rimetti in pool
  deactivate() {
    this.setActive(false).setVisible(false);
    if (this.body) this.body.stop();
  }

  // Auto-deactivate fuori schermo (chiamato da runChildUpdate)
  preUpdate(time, delta) {
    super.preUpdate(time, delta);
    const cam = this.scene.cameras.main;
    if (
      this.x < cam.scrollX - 60 || this.x > cam.scrollX + GAME_W + 60 ||
      this.y < cam.scrollY - 60 || this.y > cam.scrollY + GAME_H + 60
    ) {
      this.deactivate();
    }
  }
}

// ──────────────────────────────────────────────────────────────
//  ENEMY  v2 — State Machine + HP Bar + Animazioni + Object Pool frecce
// ──────────────────────────────────────────────────────────────
class Enemy extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y, type) {
    // Primo frame idle come texture iniziale; fallback al tipo come frame diretto
    const initFrame = `${type}_idle_1`;
    super(scene, x, y, 'assets', initFrame);
    scene.add.existing(this);
    scene.physics.add.existing(this);

    this.enemyType    = type;   // 'scheletro' | 'arciere' | 'cavaliere'
    this.currentState = 'idle'; // idle | move | attack | dead
    this._attackLock  = false;  // impedisce attacchi sovrapposti
    this._lastAttack  = 0;

    this.stats = Enemy._getStats(type);
    this.hp    = this.stats.hp;
    this.maxHp = this.stats.hp;

    this.setCollideWorldBounds(true);
    this.setGravityY(GRAVITY_Y);
    this.body.setSize(20, 30);

    if (type === 'cavaliere') this.body.setSize(30, 40);

    // Grafica barra HP (world space, aggiornata ogni frame)
    this.hpBar = scene.add.graphics().setDepth(5);
  }

  // ── stats per tipo ──────────────────────────────────────────
  static _getStats(type) {
    return ({
      scheletro: { hp:50,  speed:40,  damage:10, attackRange:30,  attackCd:1000, detectionRange:280 },
      arciere:   { hp:30,  speed:50,  damage:15, attackRange:200, attackCd:1500, detectionRange:350, kitRange:100 },
      cavaliere: { hp:150, speed:25,  damage:30, attackRange:40,  attackCd:2000, detectionRange:300 }
    })[type] || { hp:50, speed:40, damage:10, attackRange:30, attackCd:1000, detectionRange:280 };
  }

  // ── State Machine principale ─────────────────────────────────
  // Chiamato da ChronosScene.update() passando player e gruppo frecce
  update(player, arrowsGroup, time) {
    if (!this.active || !this.body) return;
    if (this.currentState === 'dead') return;
    if (this.hp <= 0) { this._die(); return; }

    const dist = Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y);
    this.setFlipX(player.x < this.x);

    if (dist <= this.stats.attackRange && !this._attackLock) {
      this._enterAttack(player, arrowsGroup, time);
    } else if (dist < this.stats.detectionRange) {
      this._enterMove(player);
    } else {
      this._enterIdle();
    }

    this._drawHpBar();
  }

  // ── STATI ────────────────────────────────────────────────────
  _enterIdle() {
    if (this.currentState === 'idle') return;
    this.currentState = 'idle';
    this.body.setVelocity(0, 0);
    this._safePlay(`${this.enemyType}_idle`);
  }

  _enterMove(player) {
    // Arciere: kiting — si allontana se troppo vicino
    const dist = Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y);
    const dir  = (player.x > this.x) ? 1 : -1;

    if (this.enemyType === 'arciere' && dist < this.stats.kitRange) {
      // scappa all'indietro
      this.setVelocityX(-dir * this.stats.speed * 1.2);
    } else {
      this.setVelocityX(dir * this.stats.speed);
    }

    if (this.currentState !== 'move') {
      this.currentState = 'move';
      this._safePlay(`${this.enemyType}_walk`);
    }
  }

  _enterAttack(player, arrowsGroup, time) {
    // Rate limiting attacchi
    if (time - this._lastAttack < this.stats.attackCd) return;
    this._lastAttack  = time;
    this._attackLock  = true;
    this.currentState = 'attack';
    this.body.setVelocity(0, 0);
    this._safePlay(`${this.enemyType}_attack`);

    // Quando animazione attacco finisce → esegui effetto → torna idle
    this.once('animationcomplete', () => {
      if (!this.active || this.currentState === 'dead') return;
      if (this.enemyType === 'arciere') {
        this._shootArrow(player, arrowsGroup);
      } else {
        this._meleeHit(player);
      }
      // Cooldown post-attacco
      this.scene.time.addEvent({
        delay: 400,
        callback: () => {
          if (this.active && this.currentState !== 'dead') {
            this.currentState = 'idle';
            this._attackLock  = false;
          }
        }
      });
    });
  }

  // ── ATTACCHI ─────────────────────────────────────────────────
  _shootArrow(player, arrowsGroup) {
    if (!arrowsGroup) return;
    // Recupera dal pool (getFirstDead), altrimenti crea nuova
    let arrow = arrowsGroup.getFirstDead(false);
    if (!arrow) {
      arrow = new Arrow(this.scene, this.x, this.y);
      arrowsGroup.add(arrow);
    }
    arrow.fire(this, player);
  }

  _meleeHit(player) {
    const dist = Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y);
    if (dist <= this.stats.attackRange + 12) {
      if (this.scene.damagePlayer) {
        this.scene.damagePlayer(this.stats.damage);
      }
    }
  }

  // ── DANNI RICEVUTI ───────────────────────────────────────────
  takeDamage(amount, ignoreArmor = false) {
    if (this.currentState === 'dead') return 0;
    this.hp -= amount;
    this.setTint(0xff2200);
    this.scene.time.addEvent({
      delay:110, callback:() => { if (this.active) this.clearTint(); }
    });
    // Popup danno flottante
    if (this.scene.showDamagePopup) {
      this.scene.showDamagePopup(this.x, this.y - 20, amount);
    }
    // Particelle sangue dalla scena
    if (this.scene.bloodFx) this.scene.bloodFx.emitParticleAt(this.x, this.y, 4);

    this._drawHpBar();

    if (this.hp <= 0) this._die();
    return amount;
  }

  // ── MORTE ────────────────────────────────────────────────────
  _die() {
    if (this.currentState === 'dead') return;
    this.currentState = 'dead';
    this.body.enable  = false;
    this.hpBar.destroy();

    // Oro + streak alla scena
    if (this.scene.addGold)      this.scene.addGold(5);
    if (this.scene.onEnemyKilled) this.scene.onEnemyKilled();

    this._safePlay(`${this.enemyType}_death`);
    this.once('animationcomplete', () => { if (this.active) this.destroy(); });

    // Fallback distruzione (se animazione death non esiste)
    this.scene.time.addEvent({
      delay:800, callback:() => { if (this.active) this.destroy(); }
    });
  }

  // ── BARRA HP ─────────────────────────────────────────────────
  _drawHpBar() {
    this.hpBar.clear();
    if (this.hp <= 0 || this.hp >= this.maxHp) return;

    const W = 40, H = 5;
    const bx = this.x - W / 2;
    const by = this.y - this.height / 2 - 10;

    // Sfondo
    this.hpBar.fillStyle(0x000000, 0.75);
    this.hpBar.fillRect(bx, by, W, H);

    // Colore in base a %
    const pct   = this.hp / this.maxHp;
    const color = pct > 0.6 ? 0x00ff00 : pct > 0.3 ? 0xffff00 : 0xff0000;
    this.hpBar.fillStyle(color, 1);
    this.hpBar.fillRect(bx, by, W * pct, H);
  }

  // ── HELPER animazione safe (non crasharé se anim non esiste) ──
  _safePlay(key) {
    if (this.anims.exists ? this.anims.exists(key) : true) {
      try { this.play(key, true); } catch (_) { /* anim non definita */ }
    }
  }

  // compatibilità retroattiva con v4 (chiamato da ChronosScene se
  // si passa il solo argomento time senza arrowsGroup)
  updateAI(player, time) {
    this.update(player, this.scene.enemyArrows || null, time);
  }
}

// ──────────────────────────────────────────────────────────────
//  MALAKOR BOSS
// ──────────────────────────────────────────────────────────────
class MalakorBoss extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y) {
    super(scene, x, y, 'assets', 'azgoth_boss');
    scene.add.existing(this);
    scene.physics.add.existing(this);
    this.hp = 5000; this.maxHp = 5000; this.phase = 1;
    this.setScale(2.5).setTint(0x555555);
    this.nextAttack = 0; this.defeatedCb = null;
    this.body.setSize(50,80).setOffset(25,10);
    this._dead = false;
    this._hpBar = scene.add.graphics().setScrollFactor(0).setDepth(60);
    this._updateHpBar();
  }
  _updateHpBar() {
    const g = this._hpBar; g.clear();
    const pct = Math.max(0, this.hp / this.maxHp);
    g.fillStyle(0x330000,0.8); g.fillRect(GAME_W*0.15,20,GAME_W*0.7,14);
    g.fillStyle(this.phase===2 ? 0xff00ff : 0xdd0000,1);
    g.fillRect(GAME_W*0.15,20,GAME_W*0.7*pct,14);
    g.lineStyle(1,0xffffff,0.5); g.strokeRect(GAME_W*0.15,20,GAME_W*0.7,14);
    if (!this._hpLabel) {
      this._hpLabel = this.scene.add.text(GAME_W/2, 22,'MALAKOR',
        { fontFamily:'"Courier New",monospace', fontSize:'11px', fill:'#fff' }
      ).setOrigin(0.5,0).setScrollFactor(0).setDepth(61);
    }
  }
  updateBoss(player, time) {
    if (!this.active || this._dead) return;
    if (this.hp <= 0) { this._deathSequence(); return; }
    if (this.hp < this.maxHp*0.5 && this.phase===1) this._startPhaseTwo();
    if (time > this.nextAttack) {
      const a = Phaser.Math.Between(1,3);
      this.phase===1 ? this._phase1(a,player) : this._phase2(a,player);
      this.nextAttack = time + 2800;
    }
    this._updateHpBar();
  }
  takeDamage(amount) {
    if (this._dead) return;
    this.hp -= amount;
    this.setTint(0xff0000);
    this.scene.cameras.main.shake(80,0.008);
    this.scene.time.addEvent({ delay:100, callback:()=>{ if(this.active) this.setTint(this.phase===2?0xff00ff:0x555555); } });
    this._updateHpBar();
  }
  _startPhaseTwo() {
    this.phase=2; this.setTint(0xff00ff);
    this.scene.cameras.main.flash(900,255,0,255);
    this.scene.showFloatingText('⚡ MALAKOR EVOLUTO — FASE 2!');
    this.nextAttack = this.scene.time.now + 1200;
  }
  _phase1(n,player) {
    if (n===1) this._vortex();
    else if (n===2) this._summon(3);
    else this._melee(player,30);
  }
  _phase2(n,player) {
    if (n===1) this._teleport(player);
    else if (n===2) this._tombRain(player);
    else this._melee(player,10);
  }
  _vortex() {
    const v = this.scene.add.circle(this.x,this.y,40,0x8800ff,0.7);
    this.scene.physics.add.existing(v,true);
    this.scene.tweens.add({ targets:v, alpha:0, scale:0.4, duration:1800, onComplete:()=>v.destroy() });
    this.scene.physics.add.overlap(this.scene.david, v, ()=>{ this.scene.damagePlayer(20); v.destroy(); });
  }
  _summon(n) {
    for(let i=0;i<n;i++){
      const e=new Enemy(this.scene, this.x+Phaser.Math.Between(-80,80), this.y+50,'scheletro');
      this.scene.enemies.add(e);
      this.scene.physics.add.collider(e,this.scene.wallsLayer);
    }
  }
  _melee(player,dmg) {
    if(Phaser.Math.Distance.Between(this.x,this.y,player.x,player.y)<220) this.scene.damagePlayer(dmg);
  }
  _teleport(player) {
    this.setPosition(player.x+110,player.y);
    this.setTint(0x00ffff);
    this.scene.time.addEvent({ delay:200,callback:()=>{ if(this.active) this.clearTint(); } });
    for(let i=0;i<3;i++){
      const c=this.scene.add.circle(player.x+Phaser.Math.Between(-60,60),player.y,20,0x9900ff,0.5);
      this.scene.time.addEvent({ delay:900,callback:()=>c.destroy() });
    }
  }
  _tombRain(player) {
    for(let i=0;i<5;i++){
      const tx=player.x+Phaser.Math.Between(-200,200);
      const tomb=this.scene.physics.add.image(tx,-30,'assets','moto_pezzo');
      tomb.setVelocityY(320); tomb.body.allowGravity=false;
      this.scene.physics.add.overlap(this.scene.david,tomb,()=>{ if(tomb.active){ this.scene.damagePlayer(15); tomb.destroy(); } });
      this.scene.time.addEvent({ delay:3500,callback:()=>{ if(tomb.active) tomb.destroy(); } });
    }
  }
  _deathSequence() {
    if (this._dead) return;
    this._dead = true;
    if (this._hpBar)   this._hpBar.destroy();
    if (this._hpLabel) this._hpLabel.destroy();
    this.scene.cameras.main.flash(1800,255,255,255);
    this.scene.cameras.main.shake(1800,0.05);
    this.scene.tweens.add({
      targets:this, alpha:0, scale:0.2, duration:1600,
      onComplete:()=>{
        this.destroy();
        this.scene.dlg.start(DIALOGUES.bossDeathDialogue, ()=>{
          if(this.defeatedCb){ const cb=this.defeatedCb; this.defeatedCb=null; cb(); }
        });
      }
    });
  }
}

// ──────────────────────────────────────────────────────────────
//  CHRONOS SCENE
// ──────────────────────────────────────────────────────────────
class ChronosScene extends Phaser.Scene {
  constructor() { super({ key:'ChronosScene' }); }
  init(data) { this._initData = data || {}; }

  preload() {
    if (!this.textures.exists('assets'))
      this.load.atlas('assets','assets/all_atlas.png','assets/all_atlas.json');
    if (!this.textures.exists('david'))
      this.load.spritesheet('david','assets/david_sheet.png',{ frameWidth:32, frameHeight:32 });
    if (!this.cache.tilemap.exists('map'))
      this.load.tilemapTiledJSON('map','assets/eldor.json');
  }

  create() {
    const gs = window.gameState;
    if (this._initData.zone) gs.currentZone = this._initData.zone;
    this.currentZone  = gs.currentZone || 'Accampamento';
    if (!this._initData._fromMenu) SaveManager.load();

    this.davidHp    = gs.david.hp;
    this.gold       = gs.david.gold;
    this.killStreak = gs.david.killStreak;
    this.invincible = false;
    this._dying     = false;

    this._buildMap();
    this._buildPlayer();
    this._buildAnimations();   // David + nemici
    this._buildParticles();
    this._buildArrows();       // ← NUOVO: pool frecce nemici
    this._buildEnemies();
    this._buildNPCs();
    this._buildCollectibles();
    this._buildPortal();
    this._buildCheckpoints();
    this._buildInput();
    this._buildCamera();
    this._buildHUD();

    this.dlg       = new DialogueManager(this);
    this.narrative = new NarrativeEngine(this);
    this.travel    = new TravelManager(this);
    this.weather   = new WeatherSystem(this);

    if (this.currentZone === 'BoscoNero') this.weather.setNightTime();
    else if (Phaser.Math.Between(0,1)) this.weather.startRain();

    if (!gs.settings.removeAds) {
      this.time.addEvent({
        delay:120000, loop:true,
        callback:() => {
          const q = Phaser.Utils.Array.GetRandom(DIALOGUES.marketingQuotes);
          this.dlg.start([{ name:'DAVID', text:q }]);
        }
      });
    }
    this._setupMicEasterEgg();
    this.cameras.main.fadeIn(500,0,0,0);
  }

  // ── MAPPA ──────────────────────────────────────────────────
  _buildMap() {
    const map=this.make.tilemap({ key:'map' });
    const ts=map.addTilesetImage('kenney','assets');
    this.groundLayer=map.createLayer('Terra',ts,0,0);
    this.wallsLayer =map.createLayer('Muri', ts,0,0);
    this.wallsLayer.setCollisionByProperty({ collides:true });
    this.mapW=map.widthInPixels; this.mapH=map.heightInPixels;
  }

  // ── PLAYER ─────────────────────────────────────────────────
  _buildPlayer() {
    this.david = this.physics.add.sprite(160,120,'david',0);
    this.david.setCollideWorldBounds(true).setGravityY(GRAVITY_Y).setMaxVelocity(DAVID_SPEED,700);
    this.physics.add.collider(this.david, this.wallsLayer);
    // hp getter/setter su this.davidHp
    Object.defineProperty(this.david,'hp',{
      get:()=>this.davidHp, set:(v)=>{ this.davidHp=v; }
    });
    this.malakorBoss = null;
  }

  // ── ANIMAZIONI ─────────────────────────────────────────────
  _buildAnimations() {
    // ── David ──
    const DA = (k,s,e,fps,r) => {
      if (!this.anims.exists(k))
        this.anims.create({ key:k, frames:this.anims.generateFrameNumbers('david',{start:s,end:e}), frameRate:fps, repeat:r });
    };
    DA('idle',    0, 0,  4,-1); DA('run',    1, 4, 10,-1);
    DA('jump',    5, 5,  4, 0); DA('shotgun',6,11, 12, 0);
    DA('chainsaw',12,14,15,-1);

    // ── Nemici: genera animazioni atlas per ogni tipo ──
    //   Assumes frames atlas: scheletro_idle_1…4, scheletro_walk_1…6, etc.
    ['scheletro','arciere','cavaliere'].forEach(type => {
      const EA = (key, prefix, start, end, fps, repeat) => {
        if (!this.anims.exists(key)) {
          this.anims.create({
            key, frameRate:fps, repeat,
            frames:this.anims.generateFrameNames('assets',{ prefix, start, end })
          });
        }
      };
      EA(`${type}_idle`,   `${type}_idle_`,   1, 4,  5, -1);
      EA(`${type}_walk`,   `${type}_walk_`,   1, 6,  8, -1);
      EA(`${type}_attack`, `${type}_atk_`,    1, 4, 10,  0);
      EA(`${type}_death`,  `${type}_death_`,  1, 4,  8,  0);
    });
  }

  // ── PARTICELLE ─────────────────────────────────────────────
  _buildParticles() {
    const base = { frame:['particle_distort'], lifespan:500,
                   speed:{min:60,max:140}, scale:{start:0.5,end:0}, emitting:false };
    this.sparks  = this.add.particles(0,0,'assets',{ ...base, quantity:1 });
    this.bloodFx = this.add.particles(0,0,'assets',{ ...base, tint:0xff2200, quantity:8 });
  }

  // ── FRECCE (Object Pool) ────────────────────────────────────
  _buildArrows() {
    // Gruppo con pooling: classType Arrow, runChildUpdate per auto out-of-bounds
    this.enemyArrows = this.physics.add.group({
      classType: Arrow,
      runChildUpdate: true,
      maxSize: 20
    });
    // Collisione frecce → David
    this.physics.add.overlap(this.david, this.enemyArrows, (_p, arrow) => {
      if (arrow.active) {
        arrow.deactivate();
        this.damagePlayer(arrow.damage);
      }
    }, null, this);
  }

  // ── NEMICI ─────────────────────────────────────────────────
  _buildEnemies() {
    this.enemies = this.physics.add.group({ classType:Enemy, runChildUpdate:false });
    this._populateEnemies();
    this.physics.add.collider(this.enemies, this.wallsLayer);
    // Overlap David-nemici → damagePlayer (solo corpo a corpo, non arcieri)
    this.physics.add.overlap(this.david, this.enemies, (_p, e) => {
      if (e.enemyType !== 'arciere') this._onContactWithEnemy(e);
    }, null, this);
  }

  _populateEnemies() {
    this.enemies.clear(true,true);
    const cfg = {
      Accampamento: [{ t:'scheletro',n:5,xBase:500,step:50 }],
      Campi:        [{ t:'scheletro',n:8,xBase:400,step:40 }],
      Villaggio:    [{ t:'scheletro',n:6,xBase:450,step:40 },
                     { t:'arciere',  n:3,xBase:700,step:50 }],
      BoscoNero:    [{ t:'scheletro',n:12,xBase:400,step:30 },
                     { t:'arciere',  n:5, xBase:600,step:40 },
                     { t:'cavaliere',n:2, xBase:800,step:60 }],
      Castelnero:   [{ t:'cavaliere',n:5,xBase:500,step:50 },
                     { t:'arciere',  n:6,xBase:650,step:45 }]
    };
    const list = cfg[this.currentZone] || cfg.Accampamento;
    list.forEach(({ t,n,xBase,step }) => {
      for(let i=0;i<n;i++){
        const e=new Enemy(this, xBase+i*step, 200, t);
        this.enemies.add(e);
      }
    });
    this.physics.add.collider(this.enemies, this.wallsLayer);
  }

  // ── NPC ────────────────────────────────────────────────────
  _buildNPCs() {
    this.npcs = this.physics.add.staticGroup();
    this._createNPCs();
  }
  _createNPCs() {
    this.npcs.clear(true,true);
    if (['Accampamento','Villaggio'].includes(this.currentZone)) {
      const e=this.npcs.create(300,200,'assets','erik_rosso').setScale(1.8);
      e.setData('dialogue',DIALOGUES.erikIntro);
      e.setData('affinityGain',10);
    }
    if (['Villaggio','Castelnero'].includes(this.currentZone)) {
      const el=this.npcs.create(500,180,'assets','elara').setScale(1.5);
      el.setData('dialogue',DIALOGUES.elaraIntro);
      el.setData('affinityGain',0);
    }
    if (!this.npcHint) {
      this.npcHint = this.add.text(0,0,'[E]',{
        fontFamily:'"Courier New",monospace', fontSize:'12px',
        fill:'#00ffcc', backgroundColor:'#000000bb', padding:{x:4,y:2}
      }).setVisible(false).setDepth(10);
    }
  }

  // ── COLLEZIONABILI ─────────────────────────────────────────
  _buildCollectibles() {
    this.partsGroup = this.physics.add.staticGroup();
    this._spawnZoneItem();
    this.physics.add.overlap(this.david, this.partsGroup,
      (_p,item)=>this._collectItem(item), null, this);
  }
  _spawnZoneItem() {
    this.partsGroup.clear(true,true);
    const zi=ZoneItems[this.currentZone];
    if(!zi || window.gameState.inventory.motoPezzi.includes(zi.key)) return;
    const item=this.partsGroup.create(
      Phaser.Math.Between(200,650), Phaser.Math.Between(100,280), 'assets', zi.key
    ).setScale(0.9);
    item.setData('itemKey',zi.key).setData('itemLabel',zi.label);
    this.tweens.add({ targets:item, y:'-=7', duration:900, yoyo:true, repeat:-1, ease:'Sine.easeInOut' });
  }
  _collectItem(_p, item) {
    const key=item.getData('itemKey'), label=item.getData('itemLabel');
    if(!window.gameState.inventory.motoPezzi.includes(key))
      window.gameState.inventory.motoPezzi.push(key);
    this.sparks.emitParticleAt(item.x,item.y,12);
    item.destroy();
    SaveManager.save(this);
    this.showFloatingText(`⚙ Trovato: ${label}!`);
    this._updateHUD();
    if(window.gameState.inventory.motoPezzi.length>=TOTAL_PARTS)
      this.showFloatingText('🏍 Moto completa! Z = NUCLEAR!');
  }

  // ── PORTALE ────────────────────────────────────────────────
  _buildPortal() {
    this.portal=this.physics.add.staticSprite(750,200,'assets','portal_blue').setScale(1.5);
    this.tweens.add({ targets:this.portal, scaleX:1.65, scaleY:1.45,
                      duration:1300, yoyo:true, repeat:-1, ease:'Sine.easeInOut' });
    this._portalCooldown=false;
    this.physics.add.overlap(this.david,this.portal,()=>this._onPortalEnter(),null,this);
  }
  _onPortalEnter() {
    if(this._portalCooldown) return;
    this._portalCooldown=true;
    const idx=ZONE_ORDER.indexOf(this.currentZone);
    const next=ZONE_ORDER[(idx+1)%ZONE_ORDER.length];
    this.travel.travelTo(next,'west');
  }

  // ── CHECKPOINT ─────────────────────────────────────────────
  _buildCheckpoints() {
    this.checkpoints=this.physics.add.staticGroup();
    [[200,100],[500,150],[800,200]].forEach(([x,y])=>
      this.checkpoints.create(x,y,'assets','statue_chronos').setScale(0.8));
    this.physics.add.overlap(this.david,this.checkpoints,()=>{
      SaveManager.save(this); this.showFloatingText('💾 CHECKPOINT');
    },null,this);
  }

  // ── INPUT ──────────────────────────────────────────────────
  _buildInput() {
    this.cursors  = this.input.keyboard.createCursorKeys();
    this.keySpace = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    this.keyX     = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.X);
    this.keyZ     = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.Z);
    this.keyE     = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.E);
    this.keyEnter = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.ENTER);
    this.keyM     = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.M);
  }

  // ── CAMERA ─────────────────────────────────────────────────
  _buildCamera() {
    this.cameras.main.startFollow(this.david,true,0.1,0.1);
    this.cameras.main.setBounds(0,0,this.mapW,this.mapH);
  }

  // ── HUD ────────────────────────────────────────────────────
  _buildHUD() {
    const S={ fontFamily:'"Courier New",monospace', scrollFactor:0 };
    this.add.rectangle(10,10,202,16,0x111111).setOrigin(0).setScrollFactor(0).setDepth(50);
    this.streakBar=this.add.rectangle(11,11,0,14,0xff6600).setOrigin(0).setScrollFactor(0).setDepth(51);
    this.streakText=this.add.text(220,9, '',{...S,fontSize:'12px',fill:'#ff6600'}).setDepth(51);
    this.goldText  =this.add.text(10,30, '',{...S,fontSize:'12px',fill:'#ffd700'}).setDepth(51);
    this.hpText    =this.add.text(10,48, '',{...S,fontSize:'12px',fill:'#ff4444'}).setDepth(51);
    this.partsText =this.add.text(10,66, '',{...S,fontSize:'12px',fill:'#ffdd00'}).setDepth(51);
    this.affinityT =this.add.text(10,84, '',{...S,fontSize:'12px',fill:'#aaddff'}).setDepth(51);
    this.zoneText  =this.add.text(10,102,'',{...S,fontSize:'11px',fill:'#888'   }).setDepth(51);
    this.add.text(GAME_W-8,GAME_H-10,
      '← → Muovi  ↑ Salta  SPACE Shotgun  X Motosega  Z Nuclear  E Dialogo  M Shop',
      {...S,fontSize:'9px',fill:'#444'}).setOrigin(1,1).setDepth(51);
    // Minimap
    this.minimapGfx=this.add.graphics().setScrollFactor(0).setDepth(52);
    this.MM={ w:130, h:90, x:GAME_W-140, y:10 };
    // Dialogo
    const BY=GAME_H-150;
    this.dialogueBox=this.add.graphics().setScrollFactor(0).setDepth(60).setVisible(false);
    this.dialogueBox.fillStyle(0x04040f,0.93).fillRoundedRect(8,BY,GAME_W-16,138,10);
    this.dialogueBox.lineStyle(2,0x00ffcc,0.75).strokeRoundedRect(8,BY,GAME_W-16,138,10);
    this.nameText=this.add.text(28,BY+10,'',{...S,fontSize:'15px',fill:'#00ffcc',fontStyle:'bold'}).setDepth(61).setVisible(false);
    this.messageText=this.add.text(28,BY+33,'',{...S,fontSize:'13px',fill:'#fff',wordWrap:{width:GAME_W-60}}).setDepth(61).setVisible(false);
    this.promptIndicator=this.add.text(GAME_W-28,BY+118,'[ INVIO ]',{...S,fontSize:'11px',fill:'#00ffcc'}).setOrigin(1,1).setDepth(61).setVisible(false);
    // Scelte
    this.choiceBtn1=this.add.text(GAME_W/2,GAME_H/2-44,'',{fontFamily:'"Courier New",monospace',fontSize:'18px',fill:'#00ff88',backgroundColor:'#001a0a',padding:{x:14,y:9}}).setOrigin(0.5).setScrollFactor(0).setDepth(65).setInteractive().setVisible(false);
    this.choiceBtn2=this.add.text(GAME_W/2,GAME_H/2+18,'',{fontFamily:'"Courier New",monospace',fontSize:'18px',fill:'#ff4444',backgroundColor:'#1a0000',padding:{x:14,y:9}}).setOrigin(0.5).setScrollFactor(0).setDepth(65).setInteractive().setVisible(false);
    this.choiceBtn1.on('pointerover',()=>this.choiceBtn1.setStyle({fill:'#fff'}));
    this.choiceBtn1.on('pointerout', ()=>this.choiceBtn1.setStyle({fill:'#00ff88'}));
    this.choiceBtn2.on('pointerover',()=>this.choiceBtn2.setStyle({fill:'#fff'}));
    this.choiceBtn2.on('pointerout', ()=>this.choiceBtn2.setStyle({fill:'#ff4444'}));
    // Notifica
    this.notifText=this.add.text(GAME_W/2,88,'',{fontFamily:'"Courier New",monospace',fontSize:'15px',fill:'#ffdd00',backgroundColor:'#000000cc',padding:{x:10,y:5}}).setOrigin(0.5).setScrollFactor(0).setDepth(70).setAlpha(0);
    this._updateHUD();
  }

  _updateHUD() {
    const gs=window.gameState, parts=gs.inventory.motoPezzi.length;
    const barW=Math.floor(200*(this.killStreak/MAX_KILL_STREAK));
    this.streakBar.width=barW;
    this.streakBar.fillColor=this.killStreak>=MAX_KILL_STREAK?0xff0000:0xff6600;
    this.streakText.setText(`STREAK: ${Math.floor(this.killStreak)}/${MAX_KILL_STREAK}`);
    this.goldText.setText(`💰 Oro: ${this.gold}`);
    this.hpText.setText(`♥ HP: ${Math.max(0,Math.floor(this.davidHp))}/${gs.david.maxHp}`);
    this.partsText.setText(`⚙ Moto: ${parts}/${TOTAL_PARTS}`);
    this.affinityT.setText(`🤝 Erik: ${gs.narrative.erikRespect}%`);
    this.zoneText.setText(`📍 ${this.currentZone}`);
    this._drawMinimap();
  }

  _drawMinimap() {
    const g=this.minimapGfx, {w,h,x,y}=this.MM;
    g.clear();
    g.fillStyle(0x000000,0.7); g.fillRect(x,y,w,h);
    g.lineStyle(1,this.killStreak>=MAX_KILL_STREAK?0xffaa00:0x00ffcc,0.7);
    g.strokeRect(x,y,w,h);
    const tx=wx=>x+(wx/this.mapW)*w, ty=wy=>y+(wy/this.mapH)*h;
    g.fillStyle(0xffffff,1); g.fillCircle(tx(this.david.x),ty(this.david.y),4);
    g.fillStyle(0xff3300,0.85);
    this.enemies.getChildren().forEach(e=>{ if(e.active) g.fillCircle(tx(e.x),ty(e.y),2); });
    g.fillStyle(0x44aaff,0.85);
    this.npcs.getChildren().forEach(n=>g.fillCircle(tx(n.x),ty(n.y),3));
    g.fillStyle(0xffdd00,0.9);
    this.partsGroup.getChildren().forEach(p=>{ if(p.active) g.fillCircle(tx(p.x),ty(p.y),3); });
  }

  // ── UPDATE ─────────────────────────────────────────────────
  update(time, _delta) {
    if (this.dlg.active) {
      this.david.setVelocityX(0);
      if (Phaser.Input.Keyboard.JustDown(this.keyEnter)) this.dlg.advance();
      this._updateHUD();
      return;
    }
    if (this.malakorBoss?.active) this.malakorBoss.updateBoss(this.david, time);
    if (this.davidHp <= 0) { this._onPlayerDeath(); return; }

    this._handleMovement();
    this._handleChainsaw(time);
    this._handleShotgun();
    this._handleNuclear();
    this._checkNPCInteraction();
    this._checkForestTrigger();

    // ← AGGIORNAMENTO NEMICI con state machine (passa frecce e time)
    this.enemies.getChildren().forEach(e => {
      if (e.active && e.update) e.update(this.david, this.enemyArrows, time);
    });

    if (Phaser.Input.Keyboard.JustDown(this.keyM)) this._openShop();
    this._updateHUD();
  }

  // ── MOVIMENTO ──────────────────────────────────────────────
  _handleMovement() {
    const isShooting=this.david.anims.isPlaying && this.david.anims.currentAnim?.key==='shotgun';
    const isSawing=this.keyX.isDown;
    if (isShooting||isSawing) { this.david.setVelocityX(0); return; }
    const {left,right,up}=this.cursors, onGround=this.david.body.blocked.down;
    if (left.isDown)       { this.david.setVelocityX(-DAVID_SPEED); this.david.setFlipX(true);  if(onGround) this.david.play('run',true); }
    else if (right.isDown) { this.david.setVelocityX(DAVID_SPEED);  this.david.setFlipX(false); if(onGround) this.david.play('run',true); }
    else { this.david.setVelocityX(0); if(onGround) this.david.play('idle',true); }
    if (Phaser.Input.Keyboard.JustDown(up) && onGround) {
      this.david.setVelocityY(DAVID_JUMP); this.david.play('jump',true);
    }
  }

  // ── MOTOSEGA ───────────────────────────────────────────────
  _handleChainsaw(time) {
    if (!this.keyX.isDown) {
      if (this.david.anims.currentAnim?.key==='chainsaw') this.david.play('idle',true);
      return;
    }
    this.david.play('chainsaw',true);
    this.cameras.main.shake(50,WeaponStats.CHAINSAW.vibration);
    HapticFeedback.chainsawRumble();
    const ox=this.david.flipX?-18:18;
    this.sparks.emitParticleAt(this.david.x+ox,this.david.y);
    const up=window.gameState.upgrades.chainsaw.level;
    const dmg=WeaponStats.CHAINSAW.baseDamage+(up>0?WeaponStats.CHAINSAW.upgrades[up-1].bonus.damage:0);
    const range=WeaponStats.CHAINSAW.range;
    const ignoreArmor=up>=1, aoe=up>=2;
    this.enemies.getChildren().forEach(e=>{
      if(!e.active||e.currentState==='dead') return;
      const dist=Phaser.Math.Distance.Between(this.david.x,this.david.y,e.x,e.y);
      if (dist<(aoe?range*1.5:range)) {
        e.takeDamage(dmg,ignoreArmor);
        this.killStreak=Math.min(this.killStreak+WeaponStats.CHAINSAW.streakBonus,MAX_KILL_STREAK);
      }
    });
  }

  // ── SHOTGUN ────────────────────────────────────────────────
  _handleShotgun() {
    if (!Phaser.Input.Keyboard.JustDown(this.keySpace)) return;
    if (this.david.anims.currentAnim?.key==='shotgun') return;
    this.david.play('shotgun',true);
    this.cameras.main.shake(100,WeaponStats.SHOTGUN.shakeAmt);
    const dir=this.david.flipX?-1:1;
    this.sparks.emitParticleAt(this.david.x+dir*20,this.david.y,16);
    const up=window.gameState.upgrades.shotgun.level;
    const bonus=up>0?WeaponStats.SHOTGUN.upgrades[up-1].bonus:{ damage:0,range:0 };
    const dmg=WeaponStats.SHOTGUN.baseDamage+(bonus.damage||0);
    const range=WeaponStats.SHOTGUN.range+(bonus.range||0);
    const hasSlow=up>=3&&bonus.slow;
    this.enemies.getChildren().forEach(e=>{
      if(!e.active||e.currentState==='dead') return;
      const dx=(e.x-this.david.x)*dir, dy=Math.abs(e.y-this.david.y);
      if (dx>0&&dx<range&&dy<WeaponStats.SHOTGUN.spreadY) {
        e.takeDamage(dmg);
        this.killStreak=Math.min(this.killStreak+3,MAX_KILL_STREAK);
        if (hasSlow&&e.body) e.setVelocityX(e.body.velocity.x*0.3);
      }
    });
  }

  // ── NUCLEAR ────────────────────────────────────────────────
  _handleNuclear() {
    if (this.killStreak<MAX_KILL_STREAK) return;
    if (!Phaser.Input.Keyboard.JustDown(this.keyZ)) return;
    this._executeNuclearStrike(()=>this._triggerWeddingSequence());
  }

  // ── NPC ────────────────────────────────────────────────────
  _checkNPCInteraction() {
    let near=null;
    this.npcs.getChildren().forEach(npc=>{
      if(Phaser.Math.Distance.Between(this.david.x,this.david.y,npc.x,npc.y)<80) near=npc;
    });
    if(near){
      this.npcHint.setPosition(near.x-10,near.y-near.displayHeight/2-22).setVisible(true);
      if(Phaser.Input.Keyboard.JustDown(this.keyE)){
        const gain=near.getData('affinityGain')||0;
        if(gain>0) window.gameState.narrative.erikRespect=Math.min(window.gameState.narrative.erikRespect+gain,MAX_AFFINITY);
        this.dlg.start(near.getData('dialogue'));
      }
    } else { this.npcHint.setVisible(false); }
  }

  // ── FOREST TRIGGER ─────────────────────────────────────────
  _checkForestTrigger() {
    const gs=window.gameState;
    if(gs.narrative.forestTriggered||this.currentZone!=='BoscoNero'||this.david.x<=500) return;
    gs.narrative.forestTriggered=true;
    this.narrative.startForestEvent();
  }

  // ── DANNO AL PLAYER (centralizzato) ────────────────────────
  //   Chiamato da: Enemy._meleeHit, Arrow overlap, MalakorBoss, _onContactWithEnemy
  damagePlayer(amount) {
    if (this.invincible) return;
    this.invincible = true;
    this.davidHp = Math.max(0, this.davidHp - amount);
    HapticFeedback.takeDamage();
    this.cameras.main.shake(130, 0.005);
    // i-frames lampeggio
    this.tweens.add({
      targets:this.david, alpha:0, duration:70, yoyo:true, repeat:5,
      onComplete:()=>{ this.david.setAlpha(1); this.invincible=false; }
    });
    // Popup danno su David
    this.showDamagePopup(this.david.x, this.david.y - 30, amount, '#ff4444');
    if (this.davidHp <= 0) {
      if (!window.gameState.settings.removeAds) this._showAdThenRestart();
      else this._onPlayerDeath();
    }
  }

  // ── POPUP DANNO FLOTTANTE ───────────────────────────────────
  showDamagePopup(x, y, amount, color = '#ff0000') {
    const t = this.add.text(x, y, `-${amount}`, {
      fontFamily:'"Courier New",monospace',
      fontSize:'bold 18px', fill:color,
      stroke:'#000000', strokeThickness:2
    }).setOrigin(0.5).setDepth(20);
    this.tweens.add({
      targets:t, y:y-50, alpha:0, duration:800,
      ease:'Power1', onComplete:()=>t.destroy()
    });
  }

  // Callback da Enemy._die() — incrementa streak
  onEnemyKilled() {
    this.killStreak = Math.min(this.killStreak + 1, MAX_KILL_STREAK);
  }

  // Contatto fisico David-nemico (non arcieri, gestiti da frecce)
  _onContactWithEnemy(enemy) {
    if (this.invincible || enemy.currentState === 'dead') return;
    this.damagePlayer(enemy.stats?.damage || 10);
  }

  // ── MORTE PLAYER ───────────────────────────────────────────
  _onPlayerDeath() {
    if (this._dying) return;
    this._dying=true;
    this.davidHp=window.gameState.david.maxHp;
    this.cameras.main.fade(400,255,0,0,false,
      (_c,p)=>{ if(p===1){ this._dying=false; this.scene.restart(); } });
  }
  _showAdThenRestart() {
    this.dlg.start(
      [{ name:'ALDOUS', text:'Aspetta, David! Guarda questa pergamena magica per tornare in vita! (Pubblicità)' }],
      ()=>this._onPlayerDeath()
    );
  }

  // ── BOSS ───────────────────────────────────────────────────
  _startBossBattle(onBossDefeated) {
    this.malakorBoss=new MalakorBoss(this,this.david.x+220,100);
    this.malakorBoss.defeatedCb=onBossDefeated;
    this.physics.add.collider(this.malakorBoss,this.wallsLayer);
    this.physics.add.overlap(this.david,this.malakorBoss,()=>{
      this.damagePlayer(20);
    },null,this);
  }

  // ── NUCLEAR STRIKE ─────────────────────────────────────────
  _executeNuclearStrike(onComplete) {
    this.killStreak=0;
    window.gameState.narrative.nuclearDone=true;
    HapticFeedback.nuclearExplosion();
    this.cameras.main.shake(1400,0.07);
    this.cameras.main.flash(800,255,255,255,false,(_c,p)=>{
      if(p!==1) return;
      this.enemies.clear(true,true);
      // Deactivate tutte le frecce in volo
      this.enemyArrows.getChildren().forEach(a=>a.deactivate());
      if(this.malakorBoss?.active){ this.malakorBoss._dead=true; this.malakorBoss.destroy(); }
      this.dlg.start(DIALOGUES.nuclear,()=>{
        let moto;
        try{ moto=this.add.sprite(this.david.x-100,this.david.y,'assets','cyber_bike').setAlpha(0).setDepth(4); }
        catch(_){ moto=this.add.rectangle(this.david.x-100,this.david.y,60,30,0x00ffcc,0).setDepth(4); }
        this.tweens.add({
          targets:moto,alpha:1,y:moto.y-12,duration:900,
          onComplete:()=>{ this.dlg.start(DIALOGUES.finalBike,()=>{ if(onComplete) onComplete(); }); }
        });
      });
    });
  }

  // ── WEDDING ────────────────────────────────────────────────
  _triggerWeddingSequence() {
    SaveManager.save(this);
    const cam=this.cameras.main;
    cam.fadeOut(900,0,0,0);
    cam.once('camerafadeoutcomplete',()=>this.scene.start('WeddingScene',{ erikAffinity:window.gameState.narrative.erikRespect }));
  }

  // ── SHOP ───────────────────────────────────────────────────
  _openShop() {
    this.scene.pause();
    this.scene.launch('ShopScene',{ gold:this.gold, isAdFree:window.gameState.settings.removeAds });
  }

  // ── REFRESH ZONA (TravelManager) ───────────────────────────
  refreshZone(entryPoint) {
    this._populateEnemies();
    this._createNPCs();
    this._spawnZoneItem();
    // Deactivate frecce in volo
    if (this.enemyArrows)
      this.enemyArrows.getChildren().forEach(a=>a.deactivate());
    this.david.setPosition(entryPoint==='east' ? this.mapW-80 : 100, 120);
    if(this.currentZone==='BoscoNero') this.weather.setNightTime();
    else this.weather.clearNight();
    this._portalCooldown=false;
  }

  // ── HELPERS ────────────────────────────────────────────────
  addGold(amount) { this.gold+=amount; window.gameState.david.gold=this.gold; }

  showFloatingText(text) {
    const t=this.add.text(this.david.x,this.david.y-55,text,{
      fontFamily:'"Courier New",monospace',fontSize:'15px',
      fill:'#ffdd00',stroke:'#000',strokeThickness:2
    }).setOrigin(0.5).setDepth(30);
    this.tweens.add({ targets:t,y:t.y-45,alpha:0,duration:1400,onComplete:()=>t.destroy() });
  }

  showChoiceButtons(label1,label2,cb) {
    this.choiceBtn1.setText(`①  ${label1}`).setVisible(true);
    this.choiceBtn2.setText(`②  ${label2}`).setVisible(true);
    this.choiceBtn1.once('pointerdown',()=>{ this.choiceBtn1.setVisible(false); this.choiceBtn2.setVisible(false); cb(true); });
    this.choiceBtn2.once('pointerdown',()=>{ this.choiceBtn1.setVisible(false); this.choiceBtn2.setVisible(false); cb(false); });
  }

  _setupMicEasterEgg() {
    if (!navigator.mediaDevices?.getUserMedia) return;
    navigator.mediaDevices.getUserMedia({ audio:true }).then(stream=>{
      const ctx=new(window.AudioContext||window.webkitAudioContext)();
      const src=ctx.createMediaStreamSource(stream);
      const analyser=ctx.createAnalyser(); analyser.fftSize=256;
      src.connect(analyser);
      const data=new Uint8Array(analyser.frequencyBinCount);
      const check=()=>{
        if(!this.sys.isActive()) return;
        analyser.getByteFrequencyData(data);
        const avg=data.reduce((a,b)=>a+b,0)/data.length;
        if(avg>200){ this.showFloatingText('🎤 SALSICCIUM! +999 oro!'); this.cameras.main.flash(500,200,0,255); this.addGold(999); }
        requestAnimationFrame(check);
      };
      check();
    }).catch(()=>{});
  }
}

// ──────────────────────────────────────────────────────────────
//  SHOP SCENE
// ──────────────────────────────────────────────────────────────
class ShopScene extends Phaser.Scene {
  constructor() { super({ key:'ShopScene' }); }
  create(data) {
    this.mainScene=this.scene.get('ChronosScene');
    this.localGold=data.gold||0;
    this.add.rectangle(GAME_W/2,GAME_H/2,GAME_W,GAME_H,0x000000,0.84);
    this.add.text(GAME_W/2,36,'⚒ MERCATO DI ELYDOR',{ fontFamily:'"Courier New",monospace',fontSize:'26px',fill:'#00ffcc',stroke:'#003333',strokeThickness:4 }).setOrigin(0.5);
    this.goldDisplay=this.add.text(GAME_W/2,70,`💰 Oro disponibile: ${this.localGold}`,{ fontFamily:'"Courier New",monospace',fontSize:'15px',fill:'#ffd700' }).setOrigin(0.5);
    const items=[
      { id:'shotgun_lv1',label:'Canna Cromata',              desc:'Danno +20, Raggio +20', price:300, type:'gold',weapon:'shotgun', lv:1 },
      { id:'shotgun_lv2',label:'Proiettili Frammentazione',  desc:'Danno +35, Raggio +10', price:600, type:'gold',weapon:'shotgun', lv:2 },
      { id:'shotgun_lv3',label:'Slug Temporale',             desc:'Danno +50, rallenta',   price:1000,type:'gold',weapon:'shotgun', lv:3 },
      { id:'chainsaw_lv1',label:'Denti in Diamante',         desc:'Ignora armatura',        price:400, type:'gold',weapon:'chainsaw',lv:1 },
      { id:'chainsaw_lv2',label:'Sovraccarico Plasma',       desc:'Danno +20, AoE x1.5',   price:800, type:'gold',weapon:'chainsaw',lv:2 },
      { id:'chainsaw_lv3',label:'Modalità Salsiccium',       desc:'Danno massimo +50',      price:1500,type:'gold',weapon:'chainsaw',lv:3 },
      { id:'fuel',         label:'Carburante Moto',          desc:'Per sfrecciare.',         price:500, type:'gold' },
      { id:'shield',       label:'Scudo Cinetico',           desc:'Invincibilità 10s.',       price:1200,type:'gold' },
      { id:'no_ads',       label:'Rimuovi Annunci',          desc:'Nessuna pubblicità.',      price:4.99,type:'real' },
      { id:'skin_neon',    label:'Skin Neon David',          desc:'Tinta cyan brillante.',    price:1.99,type:'real' }
    ];
    let yy=108;
    items.forEach(item=>{ this._createRow(item,yy); yy+=48; });
    this.add.text(GAME_W/2,GAME_H-26,'[ CHIUDI ]',{ fontFamily:'"Courier New",monospace',fontSize:'16px',fill:'#ff4444',backgroundColor:'#1a0000',padding:{x:12,y:6} }).setOrigin(0.5).setInteractive()
      .on('pointerdown',()=>{ this.scene.stop(); this.scene.resume('ChronosScene'); })
      .on('pointerover',function(){ this.setStyle({fill:'#fff'}); })
      .on('pointerout', function(){ this.setStyle({fill:'#ff4444'}); });
  }
  _createRow(item,y){
    const alreadyMax=item.weapon && window.gameState.upgrades[item.weapon].level>=item.lv;
    const col=alreadyMax?'#555':(item.type==='real'?'#ffaa00':'#fff');
    this.add.text(80,y,item.label,{ fontFamily:'"Courier New",monospace',fontSize:'14px',fill:col });
    this.add.text(80,y+16,item.desc,{ fontFamily:'"Courier New",monospace',fontSize:'10px',fill:'#777' });
    const btnC=alreadyMax?'#333':(item.type==='real'?'#ffaa00':'#00ffcc');
    const btnT=alreadyMax?'MAX':(item.type==='gold'?`${item.price} Oro`:`€ ${item.price.toFixed(2)}`);
    const btn=this.add.text(GAME_W-90,y+8,btnT,{ fontFamily:'"Courier New",monospace',fontSize:'13px',fill:'#000',backgroundColor:btnC,padding:{x:8,y:4} }).setOrigin(0.5).setInteractive();
    if(!alreadyMax){ btn.on('pointerover',()=>btn.setScale(1.08)); btn.on('pointerout',()=>btn.setScale(1)); btn.on('pointerdown',()=>this._buy(item,btn)); }
  }
  _buy(item,btn){
    if(item.type==='real'){
      if(item.id==='no_ads'){ localStorage.setItem('remove_ads','true'); window.gameState.settings.removeAds=true; this._flash('✔ Annunci rimossi!'); }
      else if(item.id==='skin_neon'){ const ms=this.scene.get('ChronosScene'); if(ms?.david) ms.david.setTint(0x00ffff); this._flash('✔ Skin Neon!'); }
      btn.setText('✔').setStyle({ backgroundColor:'#004400' });
    } else {
      if(item.weapon && window.gameState.upgrades[item.weapon].level<item.lv-1){ this._flash('Sblocca prima il livello precedente!'); return; }
      if(this.localGold<item.price){ this._flash('Non hai abbastanza oro!'); return; }
      this.localGold-=item.price;
      window.gameState.david.gold=this.localGold;
      this.goldDisplay.setText(`💰 Oro disponibile: ${this.localGold}`);
      const ms=this.scene.get('ChronosScene'); if(ms) ms.gold=this.localGold;
      if(item.weapon) window.gameState.upgrades[item.weapon].level=item.lv;
      btn.setText('✔').setStyle({ backgroundColor:'#004400' });
      this._flash(`✔ ${item.label} acquistato!`);
    }
  }
  _flash(msg){
    const t=this.add.text(GAME_W/2,GAME_H/2,msg,{ fontFamily:'"Courier New",monospace',fontSize:'26px',fill:'#ffdd00',stroke:'#000',strokeThickness:3 }).setOrigin(0.5).setDepth(10);
    this.tweens.add({ targets:t,alpha:0,duration:1800,onComplete:()=>t.destroy() });
  }
}

// ──────────────────────────────────────────────────────────────
//  WEDDING SCENE
// ──────────────────────────────────────────────────────────────
class WeddingScene extends Phaser.Scene {
  constructor() { super({ key:'WeddingScene' }); }
  init(data) { this._data=data||{}; }
  create() {
    const erikAff=this._data.erikAffinity??window.gameState.narrative.erikRespect;
    const highAff=erikAff>=50;
    this.add.rectangle(GAME_W/2,GAME_H/2,GAME_W,GAME_H,0x1a4020);
    this.add.sprite(GAME_W/2,    180,'assets','elara_bride').setScale(2).setDepth(2);
    this.add.sprite(GAME_W/2-90, 190,'david',0).setScale(2).setDepth(2);
    this.add.sprite(GAME_W/2+95, 195,'assets','erik_rosso').setScale(1.6).setDepth(2);
    const lines=[...DIALOGUES.wedding];
    lines.splice(2,0,...(highAff?DIALOGUES.weddingHighAffinity:DIALOGUES.weddingLowAffinity));
    // Dialogo box locale
    const BY=GAME_H-150;
    this.dialogueBox=this.add.graphics().setDepth(60).setVisible(false);
    this.dialogueBox.fillStyle(0x04040f,0.93).fillRoundedRect(8,BY,GAME_W-16,138,10);
    this.dialogueBox.lineStyle(2,0x00ffcc,0.75).strokeRoundedRect(8,BY,GAME_W-16,138,10);
    this.nameText=this.add.text(28,BY+10,'',{ fontFamily:'"Courier New",monospace',fontSize:'15px',fill:'#00ffcc',fontStyle:'bold' }).setDepth(61).setVisible(false);
    this.messageText=this.add.text(28,BY+33,'',{ fontFamily:'"Courier New",monospace',fontSize:'13px',fill:'#fff',wordWrap:{width:GAME_W-60} }).setDepth(61).setVisible(false);
    this.promptIndicator=this.add.text(GAME_W-28,BY+118,'[ INVIO ]',{ fontFamily:'"Courier New",monospace',fontSize:'11px',fill:'#00ffcc' }).setOrigin(1,1).setDepth(61).setVisible(false);
    this.dlg=new DialogueManager(this);
    this.dlg.start(lines,()=>this._showEnding(highAff));
    this.input.keyboard.on('keydown-ENTER',()=>{ if(this.dlg.active) this.dlg.advance(); });
    this.input.on('pointerdown',()=>{ if(this.dlg.active) this.dlg.advance(); });
    this.cameras.main.fadeIn(800,0,0,0);
  }
  _showEnding(highAff){
    const S={ fontFamily:'"Courier New",monospace',align:'center',wordWrap:{width:520} };
    this.add.text(GAME_W/2,310,"David ed Elara si sposano sotto l'antico albero di Aethelgard.",{...S,fontSize:'16px',fill:'#fff'}).setOrigin(0.5).setDepth(3);
    this.add.text(GAME_W/2,360,'Erik il Rosso, testimone, alza la coppa:',{...S,fontSize:'13px',fill:'#ffaa00'}).setOrigin(0.5).setDepth(3);
    this.add.text(GAME_W/2,395,'"Alla coppia del millennio!\nPossa la vostra motosega non restare mai senza carburante!"',{...S,fontSize:'12px',fill:'#fff'}).setOrigin(0.5).setDepth(3);
    if(highAff) this.add.text(GAME_W/2,448,'★ Legame Eterno con Erik il Rosso sbloccato ★',{...S,fontSize:'13px',fill:'#aaddff'}).setOrigin(0.5).setDepth(3);
    let moto;
    try{ moto=this.add.sprite(80,400,'assets','cyber_bike').setScale(1.5).setDepth(4).setAlpha(0); }
    catch(_){ moto=this.add.rectangle(80,400,80,36,0x00ffcc,0).setDepth(4); }
    this.tweens.add({ targets:moto,alpha:1,duration:500,onComplete:()=>{
      this.tweens.add({ targets:moto,x:GAME_W+120,duration:2600,ease:'Sine.easeIn',
        onComplete:()=>{ this.cameras.main.fadeOut(800,0,0,0); this.cameras.main.once('camerafadeoutcomplete',()=>this.scene.start('CreditsScene')); }
      });
    }});
  }
}

// ──────────────────────────────────────────────────────────────
//  CREDITS SCENE
// ──────────────────────────────────────────────────────────────
class CreditsScene extends Phaser.Scene {
  constructor() { super({ key:'CreditsScene' }); }
  create() {
    this.add.rectangle(GAME_W/2,GAME_H/2,GAME_W,GAME_H,0x000000);
    const lines=[
      { text:'— C H R O N O - S H A T T E R —',size:'30px',fill:'#00ffcc',y:90 },
      { text:'CREDITI',                          size:'22px',fill:'#fff',   y:140 },
      { text:'Game Design: Erik il Rosso',        size:'16px',fill:'#aaa',  y:190 },
      { text:'Programmazione: David (2084)',       size:'16px',fill:'#aaa',  y:218 },
      { text:'Musiche: Menestrelli di Aethelgard', size:'16px',fill:'#aaa', y:246 },
      { text:'Test: Lady Elara',                  size:'16px',fill:'#aaa',  y:274 },
      { text:"Ispirazione: 'Salsiccium'",          size:'14px',fill:'#555', y:302 },
      { text:`Affinità Erik: ${window.gameState.narrative.erikRespect}%`, size:'14px',fill:'#aaddff',y:340 },
      { text:`Pezzi moto: ${window.gameState.inventory.motoPezzi.length}/${TOTAL_PARTS}`, size:'14px',fill:'#ffdd00',y:362 },
      { text:'Grazie per aver giocato!',           size:'20px',fill:'#fff', y:406 }
    ];
    lines.forEach(({text,size,fill,y},i)=>{
      const t=this.add.text(GAME_W/2,y+30,text,{ fontFamily:'"Courier New",monospace',fontSize:size,fill }).setOrigin(0.5).setAlpha(0);
      this.tweens.add({ targets:t,alpha:1,y,duration:500,delay:i*120 });
    });
    const btn=this.add.text(GAME_W/2,480,'[ TORNA AL MENU ]',{ fontFamily:'"Courier New",monospace',fontSize:'18px',fill:'#ff4444',backgroundColor:'#1a0000',padding:{x:14,y:7} }).setOrigin(0.5).setInteractive().setAlpha(0);
    this.tweens.add({ targets:btn,alpha:1,duration:600,delay:lines.length*120+400 });
    btn.on('pointerdown',()=>{ this.cameras.main.fadeOut(600,0,0,0); this.cameras.main.once('camerafadeoutcomplete',()=>this.scene.start('MainMenuScene')); });
    btn.on('pointerover',()=>btn.setStyle({fill:'#fff'})); btn.on('pointerout',()=>btn.setStyle({fill:'#ff4444'}));
    const reset=this.add.text(GAME_W/2,528,'[ RESET SALVATAGGIO ]',{ fontFamily:'"Courier New",monospace',fontSize:'12px',fill:'#333',backgroundColor:'#0a0000',padding:{x:8,y:4} }).setOrigin(0.5).setInteractive();
    reset.on('pointerdown',()=>{ SaveManager.reset(); this.scene.start('MainMenuScene'); });
    reset.on('pointerover',()=>reset.setStyle({fill:'#ff4444'})); reset.on('pointerout',()=>reset.setStyle({fill:'#333'}));
    this.cameras.main.fadeIn(600,0,0,0);
  }
}

// ──────────────────────────────────────────────────────────────
//  MAIN MENU SCENE
// ──────────────────────────────────────────────────────────────
class MainMenuScene extends Phaser.Scene {
  constructor() { super({ key:'MainMenuScene' }); }
  create() {
    this.cameras.main.setBackgroundColor('#080810');
    const title=this.add.text(GAME_W/2,130,'CHRONO-SHATTER',{ fontFamily:'"Courier New",monospace',fontSize:'52px',fill:'#00ffcc',stroke:'#000',strokeThickness:7,shadow:{ offsetX:3,offsetY:3,color:'#ff00ff',blur:0,stroke:true,fill:true } }).setOrigin(0.5);
    this.add.text(GAME_W/2,192,'Il Futuro è in Fiamme',{ fontFamily:'"Courier New",monospace',fontSize:'18px',fill:'#888' }).setOrigin(0.5);
    this.time.addEvent({ delay:3000,loop:true,callback:()=>{
      title.setX(GAME_W/2+Phaser.Math.Between(-4,4));
      this.cameras.main.shake(80,0.004);
      this.time.addEvent({ delay:90,callback:()=>title.setX(GAME_W/2) });
    }});
    const hasSave=SaveManager.hasSave();
    this._btn(GAME_W/2,270,'NUOVA PARTITA',()=>this._startNew());
    if(hasSave) this._btn(GAME_W/2,340,'CONTINUA',()=>this._load());
    else this.add.text(GAME_W/2,340,'CONTINUA  (nessun dato)',{ fontFamily:'"Courier New",monospace',fontSize:'20px',fill:'#444' }).setOrigin(0.5);
    this._btn(GAME_W/2,410,'⚒ NEGOZIO',()=>this.scene.start('ShopScene',{ gold:0 }));
    const dlc=this.add.text(GAME_W/2,GAME_H-36,'🎮 PRE-ORDER DLC 2027 — "Il Futuro è in Fiamme"  →',{ fontFamily:'"Courier New",monospace',fontSize:'13px',fill:'#ffaa00',backgroundColor:'#1a0d00',padding:{x:12,y:5} }).setOrigin(0.5).setInteractive();
    dlc.on('pointerdown',()=>window.open('https://www.example.com/chronos-dlc','_blank'));
    dlc.on('pointerover',()=>dlc.setStyle({fill:'#fff'})); dlc.on('pointerout',()=>dlc.setStyle({fill:'#ffaa00'}));
    this.add.text(10,GAME_H-14,'v5.0 Build 2026',{ fontFamily:'"Courier New",monospace',fontSize:'11px',fill:'#333' });
    this.cameras.main.fadeIn(600,0,0,0);
  }
  _btn(x,y,label,cb){
    const btn=this.add.text(x,y,label,{ fontFamily:'"Courier New",monospace',fontSize:'24px',fill:'#fff',backgroundColor:'#1a1a2e',padding:{x:22,y:10} }).setOrigin(0.5).setInteractive();
    btn.on('pointerover', ()=>{ btn.setStyle({fill:'#000',backgroundColor:'#00ffcc'}); HapticFeedback.lightTap(); });
    btn.on('pointerout',  ()=>  btn.setStyle({fill:'#fff',backgroundColor:'#1a1a2e'}));
    btn.on('pointerdown', ()=>{ HapticFeedback.lightTap(); cb(); });
    return btn;
  }
  _startNew(){
    SaveManager.reset();
    this.cameras.main.fadeOut(800,0,0,0);
    this.cameras.main.once('camerafadeoutcomplete',()=>this.scene.start('ChronosScene',{ _fromMenu:true }));
  }
  _load(){
    SaveManager.load();
    this.cameras.main.fadeOut(800,0,0,0);
    this.cameras.main.once('camerafadeoutcomplete',()=>this.scene.start('ChronosScene',{ zone:window.gameState.currentZone, _fromMenu:true }));
  }
}

// ──────────────────────────────────────────────────────────────
//  COIN  (loot fisico con rimbalzo)
// ──────────────────────────────────────────────────────────────
class Coin extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y, value = 5) {
    super(scene, x, y, 'assets', 'moneta');
    scene.add.existing(this); scene.physics.add.existing(this);
    this.setCollideWorldBounds(true).setBounce(0.72).setGravityY(400);
    this.setVelocity(Phaser.Math.Between(-130,130), Phaser.Math.Between(-260,-310));
    this.body.setSize(12,12);
    this.value = value;
    scene.tweens.add({ targets:this, alpha:0.45, duration:320, yoyo:true, repeat:-1 });
    scene.time.addEvent({ delay:12000, callback:()=>{ if(this.active) this.destroy(); } });
  }
  collect() {
    this.scene.addGold(this.value);
    if(this.scene.sparks) this.scene.sparks.emitParticleAt(this.x, this.y, 6);
    this.destroy();
  }
}

// ──────────────────────────────────────────────────────────────
//  BREAKABLE  (oggetti distruttibili → monete)
// ──────────────────────────────────────────────────────────────
class Breakable extends Phaser.Physics.Arcade.Sprite {
  constructor(scene, x, y, type='crate') {
    super(scene, x, y, 'assets', type);
    scene.add.existing(this); scene.physics.add.existing(this, true);
    this.bType = type;
    this.setImmovable(true); this.body.setSize(30,30);
  }
  break() {
    if(!this.active) return;
    if(this.scene.breakableFx) this.scene.breakableFx.emitParticleAt(this.x, this.y, 14);
    const count = Phaser.Math.Between(1,3);
    for(let i=0;i<count;i++){
      const c = new Coin(this.scene, this.x+Phaser.Math.Between(-10,10), this.y);
      this.scene.coins.add(c);
      this.scene.physics.add.collider(c, this.scene.wallsLayer);
      this.scene.physics.add.overlap(this.scene.david, c, (_p,coin)=>coin.collect(), null, this.scene);
    }
    this.destroy();
  }
}

// ──────────────────────────────────────────────────────────────
//  NEGROMANTE  (tipo Enemy specializzato)
//  Viene creato come Enemy(scene, x, y, 'negromante')
//  Logica inclusa nella classe Enemy v3 tramite switch
// ──────────────────────────────────────────────────────────────

// ──────────────────────────────────────────────────────────────
//  XP TABLE
// ──────────────────────────────────────────────────────────────
const XP_TABLE = [0,100,250,450,700,1000,1400,1900,2500,3200];
function xpToNext(plv){ return XP_TABLE[Math.min(plv, XP_TABLE.length-1)] || 9999; }
const MAX_LEVEL = 5;
const DASH_SPEED = 620;
const DASH_DURATION = 190;
const DASH_COOLDOWN = 1100;

// ──────────────────────────────────────────────────────────────
//  TITLE SCENE  (Main Menu v6)
// ──────────────────────────────────────────────────────────────
class TitleScene extends Phaser.Scene {
  constructor(){ super({ key:'TitleScene' }); }

  preload(){
    if(!this.textures.exists('assets'))
      this.load.atlas('assets','assets/all_atlas.png','assets/all_atlas.json');
  }

  create(){
    this.cameras.main.setBackgroundColor('#080810');

    // Stelle animate in background
    const stars = this.add.graphics();
    for(let i=0;i<80;i++){
      const sx=Phaser.Math.Between(0,GAME_W), sy=Phaser.Math.Between(0,GAME_H);
      const sr=Phaser.Math.FloatBetween(0.5,2);
      stars.fillStyle(0xffffff, Phaser.Math.FloatBetween(0.2,0.8));
      stars.fillCircle(sx,sy,sr);
    }

    // Titolo con glitch
    const title = this.add.text(GAME_W/2, 130, 'CHRONO-SHATTER', {
      fontFamily:'"Courier New",monospace', fontSize:'52px', fill:'#00ffcc',
      stroke:'#000', strokeThickness:7,
      shadow:{ offsetX:3, offsetY:3, color:'#ff00ff', blur:0, stroke:true, fill:true }
    }).setOrigin(0.5);

    this.add.text(GAME_W/2, 194, 'Il Futuro è in Fiamme', {
      fontFamily:'"Courier New",monospace', fontSize:'17px', fill:'#557766'
    }).setOrigin(0.5);

    this.add.text(GAME_W/2, 218, 'v6.0 — RPG Evolution', {
      fontFamily:'"Courier New",monospace', fontSize:'12px', fill:'#334'
    }).setOrigin(0.5);

    // Glitch periodico
    this.time.addEvent({ delay:2800, loop:true, callback:()=>{
      title.setX(GAME_W/2 + Phaser.Math.Between(-5,5));
      this.cameras.main.shake(70,0.004);
      this.time.addEvent({ delay:100, callback:()=>title.setX(GAME_W/2) });
    }});

    const hasSave = SaveManager.hasSave();
    this._btn(GAME_W/2, 290, '▶  NUOVA PARTITA', ()=>this._startNew());
    if(hasSave){
      this._btn(GAME_W/2, 365, '↺  CONTINUA', ()=>this._load());
    } else {
      this.add.text(GAME_W/2, 365, 'CONTINUA  (nessun dato)', {
        fontFamily:'"Courier New",monospace', fontSize:'20px', fill:'#333'
      }).setOrigin(0.5);
    }
    this._btn(GAME_W/2, 440, '⚒  NEGOZIO', ()=>this.scene.start('ShopScene',{ gold:0 }));

    // DLC banner
    const dlc = this.add.text(GAME_W/2, GAME_H-36, '🎮 PRE-ORDER DLC 2027 — "Il Futuro è in Fiamme"  →', {
      fontFamily:'"Courier New",monospace', fontSize:'12px', fill:'#ffaa00',
      backgroundColor:'#1a0d00', padding:{x:12,y:5}
    }).setOrigin(0.5).setInteractive();
    dlc.on('pointerdown',()=>window.open('https://www.example.com/chronos-dlc','_blank'));
    dlc.on('pointerover',()=>dlc.setStyle({fill:'#fff'}));
    dlc.on('pointerout', ()=>dlc.setStyle({fill:'#ffaa00'}));

    this.add.text(10, GAME_H-14, 'v6.0 Build 2026', {
      fontFamily:'"Courier New",monospace', fontSize:'10px', fill:'#222'
    });

    this.cameras.main.fadeIn(700,0,0,0);
  }

  _btn(x,y,label,cb){
    const btn = this.add.text(x, y, label, {
      fontFamily:'"Courier New",monospace', fontSize:'24px',
      fill:'#fff', backgroundColor:'#1a1a2e', padding:{x:22,y:10}
    }).setOrigin(0.5).setInteractive();
    btn.on('pointerover', ()=>{ btn.setStyle({fill:'#000',backgroundColor:'#00ffcc'}); HapticFeedback.lightTap(); });
    btn.on('pointerout',  ()=>  btn.setStyle({fill:'#fff',backgroundColor:'#1a1a2e'}));
    btn.on('pointerdown', ()=>{ HapticFeedback.lightTap(); cb(); });
    return btn;
  }
  _startNew(){
    SaveManager.reset();
    this.cameras.main.fadeOut(700,0,0,0);
    this.cameras.main.once('camerafadeoutcomplete',()=>
      this.scene.start('ChronosScene',{ level:1, zone:'Accampamento', _fromMenu:true }));
  }
  _load(){
    SaveManager.load();
    this.cameras.main.fadeOut(700,0,0,0);
    this.cameras.main.once('camerafadeoutcomplete',()=>
      this.scene.start('ChronosScene',{ level:window.gameState.level, zone:window.gameState.currentZone, _fromMenu:true }));
  }
}

// ──────────────────────────────────────────────────────────────
//  CONFIG PHASER  v6.0
// ──────────────────────────────────────────────────────────────
const config = {
  type           : Phaser.AUTO,
  width          : GAME_W,
  height         : GAME_H,
  backgroundColor: '#080810',
  physics: { default:'arcade', arcade:{ gravity:{ y:0 }, debug:false } },
  scene: [TitleScene, MainMenuScene, ChronosScene, ShopScene, WeddingScene, CreditsScene]
};

const game = new Phaser.Game(config);
