# ⚔️ CHRONOS PROTOCOL: OMEGA
## GAME BUILDER PROMPT — VERSIONE MOBILE COMPLETA
### "Violento. Dinamico. Bellissimo."

---

## 🎯 BRIEF ESECUTIVO PER IL DEVELOPER

Stai costruendo un **Action RPG Platformer 2.5D per mobile** (Android/iOS). Il gioco deve sembrare un titolo console AAA ridotto alla sua essenza più brutale e viscerale. Ogni frame deve gridare qualcosa. Niente tutorial noioso, niente transizioni lente: il giocatore viene buttato nell'azione in meno di 3 secondi dall'apertura.

**La regola d'oro:** se non fa venire voglia di urlare "ANCORA!" dopo una kill, va rifatto.

---

## 📱 SPECIFICHE MOBILE OBBLIGATORIE

```
Engine:       Phaser 3.60+ WebGL 2.0
Risoluzione:  800×600 (scalata automaticamente al device)
FPS target:   60 fissi (mai sotto 50)
RAM budget:   < 200 MB
APK size:     < 80 MB (asset compressi AVIF/WEBP)
Touch input:  latenza < 16ms
Orientazione: Landscape obbligatoria (lockOrientation)
Android min:  API 26 (Android 8.0)
iOS min:      14.0
Haptic:       navigator.vibrate() su ogni azione violenta
```

### Layout Schermo Mobile (Landscape)
```
┌─────────────────────────────────────────────────────┐
│ [HP KEN] [HP DAVID] [CLOCK●]        [STREAK▮▮▮▮] │  ← HUD top (Camera 2, no PostFX)
│─────────────────────────────────────────────────────│
│                                                     │
│                  MONDO DI GIOCO                     │  ← Camera 1 (PostFX attivi)
│              (tilemap + nemici + FX)                │
│                                                     │
│─────────────────────────────────────────────────────│
│ [◉ JOYSTICK]    [↑SALTO]   [Z] [X] [C] [TAB]      │  ← Touch controls (Camera 2)
└─────────────────────────────────────────────────────┘

JOYSTICK: dinamico, appare dove tocchi (area sinistra 40% schermo)
SALTO:    tap area centrale-sinistra, swipe su
ATTACCHI: area destra 40% schermo
TAB:      switch Ken/David (angolo in basso a destra)
```

---

## 🎮 DUE PROTAGONISTI — DETTAGLIO IMPLEMENTAZIONE

### PROTAGONISTA 1: KEN "The Last Successor"

```
ASPETTO SPRITE (32×48px, spritesheet 8 colonne × 6 righe):
Row 0: idle (4 frame) — in guardia Hokuto, lieve oscillazione
Row 1: run  (6 frame) — corsa aggressiva, capelli che volano
Row 2: jump (3 frame) — salto, picco, caduta
Row 3: seiken (4 frame) — jab destro rapido con flash cyan
Row 4: ganzan (5 frame) — montante dal basso con bloom dorato
Row 5: finisher (6 frame) — posa carica + esplosione + freeze frame
```

**STATISTICHE KEN**
```
HP:          120 (barra viola HUD)
Ki:          0–100 (barra cyan che pulsa)
Velocità:    180 px/s
Salto:       -340 impulso
Dash:        620 px/s | 190ms | CD 1100ms | i-frames durante
Forza:       Alta (danno fisico)
```

**SISTEMA COMBO KEN — ComboManager (finestra 500ms)**
```javascript
// Input buffer: array di {id, timestamp}
// Rimuovi input > 500ms automaticamente

Z-Z-Z-Z  →  HYAKURETSU KEN
            4 pugni in 0.4s
            HitStop 60ms ogni colpo
            Vibrazione haptic [20,10,20,10,20,10,20]
            +10 Ki per pugni andati a segno

Z-X-Z    →  TENRYU KYOUSHOU  
            Jab + uppercut + jab finale
            HitStop 120ms sull'uppercut
            BloomPipeline.uIntensity = 1.2 per 200ms
            +20 Ki

Z-Z-X-C  →  HOKUTO PRESSURE STRIKE
            Punti pressione: nemico si blocca (frozen 1.5s)
            Dopo 1.5s: ESPLOSIONE (danno AOE 120px, -80 HP)
            ChromaticPipeline attiva durante il freeze
            Dialogo auto: "Sei già morto."
            +35 Ki

C @Ki=100% →  HOKUTO SHINKEN (FINISHER)
             timeScale = 0.1 per 800ms (bullet time)
             Schermo inverte colori 1 frame
             Esplosione radiale che investe tutto lo schermo
             Tutti i nemici normali → morte istantanea
             Boss → -300 HP fisso
             +HapticFeedback.nuclearExplosion()
             Ki → 0 dopo uso
```

**AURA KEN — AuraPipeline GLSL (uTime driven)**
```glsl
Ki 0–30%:   Aura azzurra sottile, pulse 0.5 Hz, alpha 0.3
Ki 31–60%:  Aura ciano media, pulse 1.0 Hz, alpha 0.5
Ki 61–99%:  Aura oro fiammeggiante, noise ad alta freq, alpha 0.8
Ki = 100%:  AURA BIANCA ESPLOSIVA — tutte le stelle pettorali ON
            uIntensity = 1.0 → shader massimo
            Schermo bordato da glow dorato
```

---

### PROTAGONISTA 2: DAVID "The Chainsaw Man from the Future"

```
ASPETTO SPRITE (32×48px, spritesheet 8 colonne × 6 righe):
Row 0: idle  (4 frame) — in piedi, motosega che vibra sottilmente
Row 1: run   (6 frame) — corsa pesante, motosega che oscilla
Row 2: jump  (3 frame) — salto, picco, caduta
Row 3: shotgun (4 frame) — sparo, rinculo, bossolo espulso
Row 4: chainsaw (6 frame) — animazione continua, denti rotanti
Row 5: nuclear (5 frame) — David alza il pugno → flash bianco totale

BRACCIO SINISTRO: motosega pixel art, denti grigi seghettati,
                  gocce di olio viola che cadono continuamente
                  (particle emitter, 2 gocce/secondo)
BRACCIO DESTRO:   doppia canna nera, dettagli arancio neon sul calcio
TUTA:             nera/antracite con dettagli arancio, casco alla cintura
```

**STATISTICHE DAVID**
```
HP:         100 (barra arancione HUD)
Carburante: 0–100 (consuma usando motosega, ricarica con casse)
Velocità:   160 px/s
Salto:      -300 impulso
Dash:       500 px/s | 250ms | CD 1400ms
Forza:      Massima (danno più alto del gioco)
```

**ARMI DAVID — DETTAGLIO**

```
SHOTGUN (tasto SPACE / tap area dx singolo):
  Danno:        85 per sparo
  Cadenza:      1 sparo ogni 0.8s (non automatico)
  Range:        150 px, spread Y: 45px
  Camera shake: intensità 0.05 per 100ms
  Flash:        bianco direzionale 1 frame
  Haptic:       vibrate([80])
  Ricarica:     automatica (illimitata)
  
  UPGRADE SHOTGUN:
  Lv1 — Canna Cromata:           danno +20, range +20
  Lv2 — Proiettili Frammentazione: danno +35, 3 pallettoni spread
  Lv3 — Slug Temporale:           danno +50, rallenta nemici 50% per 2s

MOTOSEGA (tieni premuto X / long press area dx):
  Danno:        12 HP/tick (ogni 100ms = 120 dmg/s continuo)
  Range:        55 px (solo ravvicinato)
  Consumo:      -3 carburante/tick
  Streak bonus: +2 kill streak per tick su nemico vivo
  Camera shake: costante 0.002 (leggero rombo)
  Haptic:       vibrate([30,20,30,20]) loop mentre attivo
  Particelle:   scintille arancioni (sparks emitter, 15 ptcl/s)
  Scia:         olio viola che brucia sul pavimento (damage zone -5/s)
  
  UPGRADE MOTOSEGA:
  Lv1 — Denti in Diamante:   danno +8, ignora armatura completamente
  Lv2 — Sovraccarico Plasma: danno +20, AoE laterale 80px
  Lv3 — Modalità Salsiccium: danno +50, velocità rotazione ×3

KILL STREAK → NUCLEAR (tasto Z / tap centro @streak=100):
  Attivazione:   streak barra piena (100 kill streak points)
  Effetto:       camera shake 1400ms intensità 0.07
                 flash bianco totale 800ms
                 TUTTI i nemici eliminati (boss: -500 HP fisso)
                 olio motosega esplode in area 400px
  Dialogo auto:  "Nel futuro abbiamo un detto: addio."
  Haptic:        vibrate([500,100,500,100,1000])
  Reset streak:  → 0 dopo uso
```

**KILL STREAK SYSTEM**
```
+2 streak:  ogni tick motosega su nemico
+3 streak:  ogni shotgun hit
+1 streak:  ogni kill di Clock
Reset a 0:  quando David subisce danno

Visual:
  0–49:    barra arancione normale
  50–99:   barra lampeggia, bordo rosso schermo
  100:     barra rossa pulsante + "NUCLEAR READY!" HUD
           + HapticFeedback.lightTap() ogni 2s
```

---

### COMPAGNO: CLOCK "Il Cane Steampunk"

```
ASPETTO: pastore tedesco cyborg. Pelliccia marrone-grigia,
placche metalliche brunite, occhi LED rossi, ingranaggi visibili
sui giunti, coda meccanica con punta luminosa.
Sprite: 24×20px, animazioni: idle/run/attack/alert/happy
```

```javascript
class ClockAI {
  // Segue sempre il protagonista attivo
  followDistance = 80;       // px di distanza dal player
  attackRange    = 150;      // px → attacca automaticamente
  detectRange    = 200;      // px → rileva Ombra Errante
  barkRange      = 300;      // px → abbaia per alert nemici

  update(player, enemies, time) {
    const nearest = this.findNearest(enemies);
    
    if (nearest && dist(this, nearest) < this.attackRange) {
      this.bite(nearest);          // -18 HP + HapticFeedback.lightTap()
    }
    
    if (player.hp / player.maxHp < 0.3) {
      this.alertBark();            // SFX abbaiata urgente × 3
      this.moveToPlayer();
    }
    
    if (this.detectsHiddenEnemy()) {
      this.eyes.setTint(0xff0000); // LED rossi lampeggiano
      this.growl();
    }
    
    this.collectNearbyCoins();    // raccoglie monete automaticamente
  }
}
```

---

## 💀 SISTEMA NEMICI — IMPLEMENTAZIONE COMPLETA

### TABELLA NEMICI CON STAT COMPLETE

| Nemico | HP | Danno | Velocità | Range | CD Attacco | Drop |
|--------|----|-------|----------|-------|------------|------|
| Scheletro Predone | 50 | 10 | 40 | 30px | 1000ms | 5 oro |
| Cyber-Servitore | 45 | 20 | 60 volo | 200px | 1500ms | 8 oro |
| Guardiano Cancello | 400 | 40 | 25 | 40px | 2000ms | 50 oro |
| Collezionista Tasse | 80 | 15+ruba | 70 volo | 60px | 800ms | oro variabile |
| Cittadino Sorridente | 35 | 8 proiettile | 90 | 150px | 600ms | 3 oro |
| Prisma Baby | 25 | 12 | 70 volo | 100px | 1200ms | 4 oro + cristallo |
| Ombra Errante | 40 | 25 balzo | 100 | 80px | 2000ms | 6 oro |
| Esecutore Silenzioso | 250 | 20 catena | 45 | 200px | 1000ms | 30 oro |
| Rospide Mutante | 800 | 45-60 | 0/200 | variabile | 1500ms | 150 oro |
| Alchimista Caduto | 60 | 25 acido | 30 | 150px | 2000ms | 12 oro |
| Verme Colossale | 2000 | 80-100 | 0/200 | 350px | 2500ms | 300 oro |
| **Scheletro Coscienza** | **150** | **25+40 Ki** | **60 levita** | **300px** | **1800ms** | **15 oro+Ki** |
| **Prigioniero delle Ossa** | **80** | **30 afferr** | **0** | **120px** | **3000ms** | **8 oro+chiave** |

### STATE MACHINE NEMICA (valida per tutti)
```javascript
class Enemy {
  states = ['idle', 'move', 'attack', 'stun', 'dead'];
  
  update(player, arrows, time) {
    if (this.state === 'dead') return;
    if (this.hp <= 0)  { this._die(); return; }
    
    const dist = Phaser.Math.Distance.Between(this.x, this.y, player.x, player.y);
    
    if (dist <= this.stats.attackRange && !this._attackLock) {
      this._enterAttack(player, arrows, time);
    } else if (dist < this.stats.detectionRange) {
      this._enterMove(player);
    } else {
      this._enterIdle();
    }
    
    this._drawHpBar();   // barra HP live sopra il nemico
    this._updateShader(time); // aggiorna uniform shader
  }
}
```

### POPUP DANNO — Animazione Flottante
```javascript
showDamagePopup(x, y, amount, isCrit = false) {
  const size   = isCrit ? '26px' : '18px';
  const color  = isCrit ? '#FF003C' : '#ffffff';
  const prefix = isCrit ? '💀 ' : '-';
  
  const t = this.add.text(x, y, `${prefix}${amount}`, {
    fontFamily: '"Courier New", monospace',
    fontSize: size, fill: color,
    stroke: '#000000', strokeThickness: 3
  }).setOrigin(0.5).setDepth(30);
  
  this.tweens.add({
    targets: t,
    y: y - 60,               // sale verso l'alto
    alpha: 0,
    scaleX: isCrit ? 1.4 : 1,
    scaleY: isCrit ? 1.4 : 1,
    duration: isCrit ? 1000 : 700,
    ease: 'Power2',
    onComplete: () => t.destroy()
  });
}
```

---

## 💥 VISUAL FX — OGNI AZIONE HA UN EFFETTO

### Gerarchia degli Effetti Visivi
```
LIVELLO 1 — Ogni colpo normale:
  • Spark emitter (6 particelle arancioni/bianche)
  • Tint rosso sul nemico colpito (110ms)
  • Popup danno flottante
  • HitStop 60ms

LIVELLO 2 — Colpo critico (5% base):
  • Spark emitter × 3 (18 particelle)
  • Flash bianco 1 frame sul nemico
  • Popup danno ROSSO grande + 💀
  • HitStop 120ms
  • Camera shake leggero 80ms
  • Haptic vibrate([40])

LIVELLO 3 — Combo finisher:
  • Bloom massimo 200ms
  • ChromaticAberration ai bordi
  • HitStop 200ms
  • Particelle Ki (30 particelle) dal punto d'impatto
  • Camera shake 150ms intensità 0.008
  • Haptic vibrate([60, 20, 60])

LIVELLO 4 — Morte nemico:
  • Animazione death sprite (4 frame, 8fps)
  • Blood splash particle (8 particelle rosse)
  • Drop moneta con rimbalzo fisico
  • Oro +N popup (giallo, sale verso l'alto)
  • Streak counter +N (angolo HUD)

LIVELLO 5 — Morte boss:
  • Flash bianco totale schermo 1800ms
  • Camera shake 1800ms intensità 0.05
  • Tween alpha 0 + scale 0.2 sul boss (1600ms)
  • Pioggia di monete (20–50 monete fisiche)
  • STREAK EXPLOSION: streak bar si svuota in effetto esplosivo
  • Dialogo post-boss (Ken o David)
  • Haptic vibrate([500,100,500,100,500,100,1000])
```

### Effetti Ambientali per Zona
```
VILLAGGIO IN ROVINE:
  • Polvere che cade dal soffitto (particle, alpha 0.3)
  • Torce che tremano (light flicker 2Hz)
  • Fog di guerra sui bordi (vignette shader)

FORTEZZA DEL TEMPO:
  • Ingranaggi che ruotano in background
  • Scintille elettriche dai muri (particle viola)
  • Riflessi sul pavimento metallico (fake reflection shader)

DESERTO DI CRISTALLO:
  • Sabbia che turbina (particle system)
  • Rifrazioni prismatiche sul pavimento (rainbow shader)
  • Calore che distorce l'orizzonte (heat distortion GLSL)

TORRE DEL TEMPO:
  • Lancette di orologi che girano erraticamente
  • Chromatic aberration che aumenta verso il boss
  • Nebbia viola spessa (fog density aumenta ogni piano)

NUCLEO TEMPORALE (boss finale):
  • Lo schermo pulsa lentamente al ritmo di God Chronos
  • Crepe nello spazio (crack lines animate, cyan)
  • Stelle cadenti di frammenti temporali (background)
  • Gravity distortion: le particelle cadono verso Chronos
```

---

## 🏗️ ARCHITETTURA SCENE E TRANSIZIONI

### Scene Graph
```
TitleScene
  │── LogoAnimation (2.5s, skip tap)
  │── MainMenuScene
  │     ├── NUOVA PARTITA → CharSelectScene → ARC 0
  │     ├── CONTINUA → ChronosScene (zona salvata)
  │     └── NEGOZIO → ShopScene (overlay)
  │
ChronosScene (scene principale, sempre attiva)
  │── update() ogni frame: nemici, player, clock, HUD
  │── ShopScene (overlay, pausa gioco)
  │── BossIntroScene (cinematic 3s prima del boss)
  │── DeathScene (overlay: 0.5s fade, "GAME OVER" → retry/menu)
  │
WeddingScene (epilogo ARC finale)
CreditsScene → MainMenuScene
```

### Transizioni tra Zone
```javascript
// TravelManager — fade + ricarica zona
travelTo(targetZone) {
  SaveManager.save(this);
  
  this.cameras.main.fadeOut(500, 0, 0, 0);
  
  this.cameras.main.once('camerafadeoutcomplete', () => {
    this.currentZone = targetZone;
    this.refreshZone('west');
    
    // Deactivate tutte le frecce in volo
    this.enemyArrows.getChildren().forEach(a => a.deactivate());
    
    this.cameras.main.fadeIn(500, 0, 0, 0);
    
    // SFX whoosh + haptic leggero
    this.sound.play('zone_transition');
    navigator.vibrate([30]);
  });
}
```

---

## 🎨 SHADER PIPELINE — SPECIFICHE COMPLETE

### AuraPipeline — Ken Ki Aura
```glsl
#version 300 es
precision mediump float;

uniform float uTime;
uniform float uIntensity;    // 0.0–1.0 dal Ki di Ken
uniform sampler2D uMainSampler;
in vec2 outTexCoord;
out vec4 fragColor;

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}
float noise(vec2 p) {
  vec2 i = floor(p); vec2 f = fract(p);
  vec2 u = f*f*(3.0-2.0*f);
  return mix(mix(hash(i), hash(i+vec2(1,0)), u.x),
             mix(hash(i+vec2(0,1)), hash(i+vec2(1,1)), u.x), u.y);
}

void main() {
  vec4 color = texture(uMainSampler, outTexCoord);
  vec2 uv    = outTexCoord - 0.5;
  float dist = length(uv);

  // Pulsazione sinusoidale basata sul Ki
  float pulse = (sin(uTime * 3.0 * (1.0 + uIntensity)) * 0.5 + 0.5) * uIntensity;
  float n     = noise(uv * 8.0 + uTime * 2.0);

  // Azzurro → Oro → Bianco esplosivo con l'aumentare del Ki
  vec3 colorA = vec3(0.0, 0.5, 1.0);   // cyan base
  vec3 colorB = vec3(1.0, 0.843, 0.0); // oro
  vec3 colorC = vec3(1.0, 1.0, 1.0);   // bianco esplosivo

  vec3 aura = mix(colorA, colorB, clamp(uIntensity * 2.0, 0.0, 1.0));
  aura       = mix(aura,  colorC, clamp((uIntensity - 0.5) * 2.0, 0.0, 1.0));

  float alpha = smoothstep(0.4 + pulse * 0.1, 0.15, dist) * uIntensity;
  alpha = clamp(alpha * (0.8 + n * 0.4), 0.0, 1.0);

  if (color.a < 0.8) {
    fragColor = vec4(aura * alpha * 1.5, alpha);
  } else {
    fragColor = color;
  }
}
```

### NoirModePipeline — Desperation State
```glsl
void main() {
  vec4 color = texture(uMainSampler, outTexCoord);
  // Converti in scala di grigi
  float gray = dot(color.rgb, vec3(0.299, 0.587, 0.114));
  // Tieni solo il rosso (dettagli Hokuto di Ken)
  float redMask = step(0.5, color.r - color.g - color.b);
  vec3 final = mix(vec3(gray * 0.7), color.rgb, redMask);
  fragColor = vec4(final, color.a);
}
```

### SkeletonKiPipeline — Scheletro Coscienza
```glsl
void main() {
  vec4 color = texture(uMainSampler, outTexCoord);
  vec2 uv = outTexCoord - 0.5;
  float dist = length(uv);

  // Aura blu spiralata
  float angle = atan(uv.y, uv.x) + uTime * 3.0;
  float spiral = sin(dist * 25.0 - angle * 2.0 - uTime * 8.0) * 0.5 + 0.5;
  float auraIntensity = smoothstep(0.5, 0.2, dist) * spiral;

  vec3 blue = vec3(0.0, 0.4, 1.0);
  vec3 white = vec3(0.6, 0.8, 1.0);
  vec3 auraColor = mix(blue, white, spiral);

  if (color.a < 0.1) {
    fragColor = vec4(auraColor, auraIntensity * 0.9);
  } else {
    // Tint blu sullo scheletro stesso
    fragColor = vec4(color.rgb + vec3(0.0, 0.1, 0.3) * auraIntensity, color.a);
  }
}
```

---

## 🏪 SISTEMA PROGRESSIONE & SHOP

### ShopScene — Mercato Old-School
```
FABBRO CIECO (upgrade armi):
  Motosega Lv1:  5 Scrap   → denti in diamante
  Motosega Lv2:  12 Scrap  → sovraccarico plasma
  Motosega Lv3:  20 Scrap  → modalità salsiccium
  Shotgun Lv1:   5 Scrap   → canna cromata
  Shotgun Lv2:   12 Scrap  → frammentazione
  Shotgun Lv3:   20 Scrap  → slug temporale
  Ken Seiken Lv2: 8 Scrap  → +8 dmg + velocità +15%
  Ken Ganzan Lv2: 8 Scrap  → stun 0.5s al contatto
  Ken Ki Blast L2: 10 Scrap → 3 proiettili spread
  Clock Denti:   8 Scrap   → morso +10 dmg
  Clock Radar:   12 Scrap  → rileva nascosti 350px
  Clock Turbo:   10 Scrap  → velocità +40 px/s

ALCHIMISTA ERRANTE (shop pozioni, oro):
  Pozione HP S:   20 oro   → ripristina 30 HP
  Pozione HP M:   50 oro   → ripristina 80 HP
  Pozione Ki:     35 oro   → Ki → 100% istantaneo
  Pozione Streak: 40 oro   → streak +50 istantaneo
  Antidoto:       25 oro   → rimuove veleno/rallentamento
  Pozione Critico: 60 oro  → crit chance +15% per 60s

LIBRAIO PAZZO (info boss, oro):
  Scheda Nemico:  30 oro   → mostra pattern, punti deboli, drop
  Mappa Segreti:  50 oro   → rivela stanze nascoste nell'arco attuale
  Profezia Boss:  40 oro   → mostra prima fase boss prima del fight
```

### Economia Drop Rate
```
Scheletro Predone:    5 oro (100%), scrap (15%)
Cyber-Servitore:      8 oro (100%), scrap (25%)
Scheletro Coscienza:  15 oro (100%), Ki Essence (40%)
Guardiano Cancello:   50 oro (100%), scrap ×3 (100%), item storia (100%)
Boss Maggiori:        100–300 oro, scrap ×5, Ki Essence ×2, frammento temporale
```

---

## 📊 HUD MOBILE — SPECIFICHE PIXEL-PERFECT

```javascript
_buildHUD() {
  // ── CAMERA 2 (UI) — nessun PostFX ──
  this.uiCamera = this.cameras.add(0, 0, GAME_W, GAME_H);
  this.uiCamera.setPostPipeline(null);  // UI sempre nitida

  // Barra HP Ken (viola) — top left
  this.kenHpBar = this._createHpBar(10, 10, 0x8b00ff, 'KEN');

  // Barra HP David (arancione) — top left sotto Ken
  this.davidHpBar = this._createHpBar(10, 30, 0xff6b00, 'DAVID');

  // Indicatore Clock — cerchio LED rosso
  this.clockIndicator = this.add.circle(180, 20, 8, 0xff0000)
    .setScrollFactor(0).setDepth(51);

  // Barra Kill Streak (arancione) — top right
  this.streakBar = this._createStreakBar(GAME_W - 150, 10);

  // Ki bar Ken (cyan) — sotto barra HP Ken
  this.kiBar = this._createKiBar(10, 52);

  // Carburante David (arancione più scuro) — sotto HP David
  this.fuelBar = this._createFuelBar(10, 72);

  // Oro — top center
  this.goldText = this.add.text(GAME_W/2, 8, '💰 0', {
    fontFamily: '"Courier New", monospace',
    fontSize: '11px', fill: '#FFD700'
  }).setOrigin(0.5, 0).setScrollFactor(0).setDepth(51);

  // Zona corrente — top right piccolo
  this.zoneText = this.add.text(GAME_W - 8, 8, '', {
    fontFamily: '"Courier New", monospace',
    fontSize: '9px', fill: '#666'
  }).setOrigin(1, 0).setScrollFactor(0).setDepth(51);

  // NUCLEAR READY! alert — lampeggiante
  this.nuclearAlert = this.add.text(GAME_W/2, GAME_H - 60,
    '⚡ NUCLEAR READY! ⚡', {
      fontFamily: '"Courier New", monospace',
      fontSize: '16px', fill: '#FF003C',
      backgroundColor: '#000000cc',
      padding: { x: 10, y: 5 }
    }).setOrigin(0.5).setScrollFactor(0).setDepth(55).setAlpha(0);
}
```

---

## 💾 SAVE SYSTEM — Quantum Moral Memory

```javascript
class SaveManager {
  static SLOT = 'ChronosProtocol_v2_Save';

  static save(scene) {
    const gs = window.gameState;
    const snap = {
      version:      '2.0',
      timestamp:    Date.now(),
      zone:         scene.currentZone,
      activeHero:   scene.activeHero,  // 'ken' | 'david'
      ken: {
        hp:         scene.kenHp,
        ki:         scene.kenKi,
        level:      gs.ken.level,
        xp:         gs.ken.xp,
        combosUnlocked: gs.ken.combosUnlocked
      },
      david: {
        hp:         scene.davidHp,
        fuel:       scene.davidFuel,
        killStreak: scene.killStreak
      },
      clock: {
        hp:         scene.clockHp,
        upgrades:   gs.clock.upgrades
      },
      inventory:    JSON.parse(JSON.stringify(gs.inventory)),
      upgrades:     JSON.parse(JSON.stringify(gs.upgrades)),
      narrative:    JSON.parse(JSON.stringify(gs.narrative)),
      karma:        gs.karma,               // vettore {x, y}
      fragmentsFound: gs.fragmentsFound,   // array ID frammenti
      bossDefeated: gs.bossDefeated,        // array ID boss
      settings:     JSON.parse(JSON.stringify(gs.settings))
    };

    // XOR cipher con timestamp installazione
    const installTs = localStorage.getItem('install_ts') || Date.now();
    const encrypted = btoa(JSON.stringify(snap))
      .split('').map((c, i) =>
        String.fromCharCode(c.charCodeAt(0) ^ (installTs >> (i % 8) & 0xFF))
      ).join('');

    localStorage.setItem(SaveManager.SLOT, encrypted);
  }
}
```

---

## 🔊 AUDIO — Neuro-Audio Synthesis

```javascript
class AudioManager {
  constructor(scene) {
    this.scene = scene;
    this.ctx   = new (window.AudioContext || window.webkitAudioContext)();
    this.bpm   = 120;
    this.currentTrack = null;
  }

  // BPM adattivo: aumenta con la kill streak
  updateBPM(killStreak) {
    const targetBPM = Math.min(180, 120 + killStreak * 2.5);
    if (Math.abs(this.bpm - targetBPM) > 5) {
      this.crossFadeTo(this._getTrackForBPM(targetBPM), 1500);
      this.bpm = targetBPM;
    }
  }

  // QTE Seven Stars: scala minore armonica di La
  playQTENote(starIndex) {
    const NOTES = [440, 493.88, 523.25, 587.33, 659.25, 698.46, 830.61];
    const osc   = this.ctx.createOscillator();
    const gain  = this.ctx.createGain();
    osc.frequency.value = NOTES[starIndex];
    osc.type    = 'sine';
    gain.gain.setValueAtTime(0.4, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.8);
    osc.connect(gain).connect(this.ctx.destination);
    osc.start(); osc.stop(this.ctx.currentTime + 0.8);
  }

  // Suoni ambientali per zona
  playZoneAmbience(zone) {
    const ambient = {
      'Villaggio':      'ambience_ruins',
      'Fortezza':       'ambience_fortress',
      'Mercato':        'ambience_market',
      'Deserto':        'ambience_desert',
      'Torre':          'ambience_tower',
      'Nucleo':         'ambience_void'
    };
    this.scene.sound.play(ambient[zone], { loop: true, volume: 0.3 });
  }
}
```

---

## ✅ CHECKLIST PRODUZIONE MOBILE COMPLETA

### Setup Engine
- [ ] Phaser 3.60+ WebGL 2.0 config
- [ ] Dual Camera System (world + UI)
- [ ] Dynamic Resolution Scaling
- [ ] Touch input low-latency setup
- [ ] Landscape lock
- [ ] Object Pooling pre-allocato (tutto)
- [ ] ZERO `new` durante gameplay loop

### Protagonisti
- [ ] Ken: spritesheet + animazioni (6 row × 8 col)
- [ ] David: spritesheet + animazioni (6 row × 8 col)
- [ ] Clock: spritesheet (5 animazioni)
- [ ] Switch system (TAB / doppio tap) smooth
- [ ] ComboManager Ken (Z/X/C/V, 500ms window)
- [ ] KillStreak + Nuclear David
- [ ] ClockAI (follow + detect + collect + alert)
- [ ] Co-op local (split input)
- [ ] Chronos Dual Strike detection

### Combat Feel
- [ ] HitStop (60/120/200ms per livello)
- [ ] Damage popup flottante (normale + critico)
- [ ] Spark emitter per ogni hit
- [ ] Blood splash particle per kill
- [ ] Camera shake calibrato per arma
- [ ] HapticFeedback per ogni azione violenta
- [ ] Drop monete con fisica rimbalzo

### Shader Pipeline
- [ ] AuraPipeline (Ken, Ki-driven)
- [ ] ChainSawPipeline (David, olio che brucia)
- [ ] SkeletonKiPipeline (Scheletro Coscienza)
- [ ] PrismaticPipeline (Prisma Baby/Golem)
- [ ] NoirModePipeline (Desperation)
- [ ] ScreenCrackPipeline (QTE fail)
- [ ] BloomPipeline (selettivo >0.8)
- [ ] ChromaticPipeline (aberrazione bordi)
- [ ] Bioma shader × 5 (Villaggio/Fortezza/Mercato/Deserto/Torre)

### UI Mobile
- [ ] HUD top: HP Ken + HP David + Clock indicator + Streak bar + Gold
- [ ] Ki bar Ken + Fuel bar David
- [ ] Touch joystick dinamico (area sinistra)
- [ ] Pulsanti attacco (area destra)
- [ ] TAB switch hero (angolo basso destra)
- [ ] NUCLEAR READY! alert lampeggiante
- [ ] Minimap (angolo top right, toggle)
- [ ] Dialogo box (bottom, typewriter 28ms/char)

### Nemici (12 tipi)
- [ ] State machine per ogni tipo (idle/move/attack/stun/dead)
- [ ] HP bar live sopra ogni nemico
- [ ] Comportamenti unici (kiting, levitare, invisible, etc.)
- [ ] Shader specifici dove indicato
- [ ] Drop fisico (monete con rimbalzo)

### Boss (8 + God Chronos × 3)
- [ ] Intro cinematica (3s, camera zoom + music change)
- [ ] HP bar boss full-width (top screen)
- [ ] Fase 2 trigger con flash
- [ ] Morte boss: cascade effect + pioggia monete

### Desperation + QTE
- [ ] Trigger a HP = 1 (Ken o David)
- [ ] NoirMode istantaneo
- [ ] timeScale = 0.3
- [ ] 7 stelle spawn Big Dipper pattern
- [ ] Timer 2.2 secondi (visual ring)
- [ ] Tap detection (hitbox 110px)
- [ ] Note musicali per ogni tap (scala La minore arm.)
- [ ] SUCCESS → WhiteHoleBloom + invincibilità 6s
- [ ] FAIL → ScreenCrack + morte cinematica

### Audio
- [ ] BPM adattivo (120 → 180 con killstreak)
- [ ] CrossFade tra tracce (1.5s)
- [ ] SFX per ogni azione (shotgun, chainsaw, combo, etc.)
- [ ] QTE notes (7 note scala minore La)
- [ ] Reverse reverb su critici
- [ ] Ambience per zona
- [ ] Clock SFX (abbaiata, ugolata, ringhi, felice)

### Save & Progression
- [ ] SaveManager XOR cipher
- [ ] Karma vettore (x,y) aggiornato dai dialoghi
- [ ] Checkpoint ogni zona (statua Chronos)
- [ ] Upgrade tree (Fabbro + Alchimista + Eremita)
- [ ] Frammenti Omega × 3 per True Ending
- [ ] True/Good/Bad Ending basato su karma distanza

---

```
╔═══════════════════════════════════════════════════════╗
║                                                       ║
║  "Il tuo Ki è codice.                                 ║
║   Il mio Ki è destino.                                ║
║   La mia motosega? È un upgrade."                     ║
║                                                       ║
║    — KEN e DAVID, prima dell'ultima battaglia         ║
║                                                       ║
║  "Bau."     — CLOCK                                   ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
```
