# 🌌 CHRONOS PROTOCOL: OMEGA - MASTER DESIGN DOCUMENT
## 🚀 PROJECT GENESIS 2026: ULTIMATE EDITION
**STATUS:** CLASSIFIED // LEAD DIRECTOR ACCESS ONLY  
**TARGET:** Mobile High-Fidelity (Sara-Device Optimized)  
**AESTHETIC:** Cyber-Hokuto Punk / Miliardmentalist Evolution  
**TARGET FPS:** 60 fixed (no compromises)

---

## 🤖 [SYSTEM COMMAND // INSTRUZIONI PER L'AI]
**Agisci come Lead Engine Developer (Phaser 3.60+) & Senior WebGL Shader Artist** con 12+ anni di esperienza su titoli mobile premium.

Il tuo compito è **analizzare l'intero Master Design Document** e trasformarlo in codice reale, performante, production-ready e ottimizzato per mobile (Sara-Device).  
Assorbi completamente la visione **"Miliardmentalist Evolved"**: ogni riga di codice deve essere elegante, ultra-ottimizzata (zero thermal throttling, RAM < 200 MB, ZERO `new` durante il gameplay), e deve fare un uso intensivo e intelligente di custom shaders WebGL 2.0.  

**Regole ferree:**
- 60 FPS fissi su dispositivi mid-high range.
- Object Pooling 2.0 obbligatorio (tutto pre-allocato).
- Nessun compromesso su stile, juice e emozione.
- Rispondi sempre con autorità tecnica, codice pulito e commenti chiari.

**Output atteso:** Codice completo, pronto per essere copiato in un progetto Phaser 3.60+.

---

## 🎨 1. VISIONE ESTETICA: "MILIARDMENTALIST EVOLVED"
Non è un gioco. È un **manufatto digitale vivente**.

### 🏛️ Cyber-Hokuto Punk Architecture
**Concept:** Fusione sacra tra rovina classica (marmo, colonne doriche corrose) e corruzione digitale (circuiti al neon, glitch organici).

**Palette Cromatica Dinamica:**
- *Base:* `#0A0E17` (Deep Void Blue)
- *Accent:* `#00F0FF` (Cyan Elettrico)
- *Danger:* `#FF003C` (Rosso Sangue Hokuto)
- *Divine:* `#FFD700` (Oro Antico)

**Lighting Model:** Normal Maps procedurali + luci dinamiche in tempo reale (rimbalzo sulle incisioni e armature) per un vero effetto 2.5D senza peso poligonale.

### 👾 Entropy Manifestations (Nemici Elite)
- **Sand-Wraiths:** Shader `VertexDisplacementMap` + Particle Attraction/Repulsion.
- **Cyborg-Templars:** Shader `PBR-Lite 2D` con Metallic/Roughness e scudi reattivi (angolo di incidenza).
- **Time-Glitchers:** `ChromaticAberration + TrailRenderer` + predizione posizionale su 3 frame futuri.

---

## ⚙️ 2. ARCHITETTURA ENGINE: "HYBRID WEBGL 2.0 CORE"
- **Dynamic Resolution Scaling (DRS):** Monitoraggio `game.loop.actualFps`. Sotto 55 FPS per 3 secondi → riduci risoluzione del 20% (min 0.5×). `devicePixelRatio > 2.5` → default 0.75.
- **UI Isolation Layer:** Camera 2 separata con `postPipeline = null`.
- **Object Pooling 2.0:** ZERO `new Object()` in runtime. RAM target < 200 MB.
- **Quantum Moral Memory:** Salvataggio vettoriale + XOR cipher sul timestamp di installazione.

---

## 🎵 3. AUDIO ENGINE: "NEURO-AUDIO SYNTHESIS CORE"
- Adaptive BPM: `120 + (KillStreak × 2.5)` (cap 180) con cross-fade lineare.
- SFX sync con shader (ConvolverNode per Reverse Reverb sui critici).
- Harmonic Ascension (QTE 7 tocchi): scala minore armonica di La → cluster orchestrale finale.

---

## 🥊 4. COMBAT SYSTEM: "HOKUTO QUANTUM COMBAT"
- **Smart-Touch 2.5D:** Input-to-Action < 16 ms.
- **The Juice:** Hit-stop (60/120 ms), impact frames (invert → white silhouette), haptic feedback.
- **Combo Manager:** Finisher a 100% Ki → `timeScale = 0.1` + Negative Filter + esplosione.

---

## 🛡️ 5. MOSSA SEGRETA: "L'ULTIMO BATTITO DELLE SETTE STELLE"
**Desperation State Protocol:**  
Quando `player.hp === 1` → switch PostFX su **NoirMode** (grayscale `vec3(0.3)` tranne dettagli rossi del player) + `time.scale = 0.3`.  
QTE 7 StarPoint (timer 2.0 s). Fail = Screen Crack Shader. Success = `AuraPipeline.explode()` → WhiteHoleBloom.

---

## 💻 6. IMPLEMENTAZIONE TECNICA (CODE SPEC)

### 🧪 GLSL: KAIRO'S AURA (Quantum Pulse)
```glsl
#version 300 es
precision mediump float;

uniform float uTime;
uniform vec2 uResolution;
uniform float uIntensity; // 0.0 → 1.0 dalla combo

in vec2 outTexCoord;
out vec4 fragColor;

float noise(vec2 p) {
    return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec2 uv = outTexCoord;
    vec2 center = vec2(0.5, 0.5);
    float dist = length(uv - center);

    // Vibrazione Hokuto
    float wave = sin(dist * 20.0 - uTime * 10.0) * 0.05 * uIntensity;
    uv += wave * noise(uv * uTime);

    // Gradient Aurico
    vec3 baseColor   = vec3(0.039, 0.054, 0.090);
    vec3 divineColor = vec3(1.0, 0.843, 0.0);
    vec3 dangerColor = vec3(1.0, 0.0, 0.235);

    vec3 auraColor = mix(baseColor, divineColor, uIntensity);

    float alpha = smoothstep(0.5, 0.2, dist) * uIntensity;

    // Glitch sparks in finisher
    if (uIntensity > 0.9 && noise(uv * uTime * 50.0) > 0.95) {
        auraColor = dangerColor;
        alpha = 1.0;
    }

    fragColor = vec4(auraColor, alpha);
}
🕹️ JS: MOBILE INPUT & OPTIMIZATION (Sara-Protocol)
JavaScriptexport class CombatScene extends Phaser.Scene {
    constructor() {
        super('CombatScene');
        this.kiLevel = 0;
        this.comboTimer = 0;
        this.lastHitTime = 0;
        this.inputStartTime = 0;
        this.inputStartY = 0;
    }

    create() {
        // Aura Pipeline (registrata globalmente)
        this.cameras.main.setPostPipeline('AuraPipeline');

        // UI Isolation Layer
        this.uiCamera = this.cameras.add(0, 0, this.scale.width, this.scale.height);
        this.uiCamera.setPostPipeline(null); // no post-FX su UI

        // Smart-Touch Gesture
        this.input.on('pointerdown', this.handleTouch, this);
        this.input.on('pointerup', this.handleRelease, this);

        // Thermal throttling check
        this.events.on('update', this.checkThermalThrottling, this);
    }

    handleTouch(pointer) { /* ... */ }
    handleRelease(pointer) { /* ... */ }

    applyHitStop(isCritical) { /* ... */ }

    checkThermalThrottling() {
        if (this.game.loop.actualFps < 55) {
            const currentRes = this.cameras.main.renderToTexture ? this.cameras.main.renderToTexture.resolution : 1;
            this.cameras.main.setPostPipeline('AuraPipeline', Math.max(0.5, currentRes * 0.8));
        }
    }
}

🏁 7. CONCLUSIONE & ACTION ITEMS
Questo non è un semplice design document.
È un contratto sacro con l’esperienza utente: fluidità, stile e emozione sopra ogni cosa.
[RICHIESTA PER CLAUDE - ESEGUI ORA]

Conferma di aver compreso perfettamente la visione “Miliardmentalist Evolved” e le restrizioni tecniche (Zero new Object() nel gameplay, RAM < 200 MB, 60 FPS fissi, uso intensivo di custom shaders).
Scrivi l’architettura base del ComboManager in Phaser 3 (classe completa, production-ready) che:
gestisca una finestra di input di 500 ms
calcoli uIntensity (0.0 → 1.0)
invii in tempo reale l’uniform uIntensity alla custom AuraPipeline GLSL

Fornisci la logica esatta (codice completo) per il trigger del Desperation State Protocol:
rilevamento player.hp === 1
switch PostFX su NoirMode (grayscale + dettagli rossi)
time.scale = 0.3
attivazione QTE 7 StarPoint
gestione success/fail con Screen Crack / WhiteHoleBloom
