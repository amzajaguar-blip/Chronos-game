# Kronos Fight - Documento di Gameplay

**Titolo completo:** Kronos Fight  
**Genere:** Action-Platformer 2D Metroidvania con elementi Rogue-lite  
**Prospettiva:** Side-view 2D  
**Stile artistico:** Pixel Art 16-bit retro-dark

## 1. Informazioni Generali
- **Dimensione schermo:** 16:9 (1920x1080 target)  
- **Frame rate:** 60 FPS  
- **Stile:** Pixel Art 16-bit dark moody (ispirato a Castlevania + Blasphemous + cronologia del titolo originale)

## 2. Controlli Principali
*(tabella invariata – vedi versione precedente)*

## 3. Sistema di Combattimento Dettagliato
*(sezione invariata – vedi versione precedente)*

## 4. Lista Completa delle Skin con Effetti
*(tabella invariata – vedi versione precedente)*

## 5. Diagramma di Flusso del Dual Hero Sync
*(mermaid invariato – vedi versione precedente)*

## 6. Specifiche Tecniche per il Builder  
**Cursor + Rosebud (Guida Completa)**

### 6.1 Strumenti Principali

| Strumento     | Uso Principale                              | Vantaggi per Kronos Fight                          |
|---------------|---------------------------------------------|----------------------------------------------------|
| **Cursor**    | AI Code Editor (basato su Claude 3.5)      | Scrittura rapida di codice GDScript / Godot 4     |
| **Rosebud**   | AI Game Builder (generazione codice + asset)| Creazione automatica di sprite, animazioni, livelli |

### 6.2 Workflow Consigliato (Cursor + Rosebud)

**Fase 1 – Setup Progetto (Rosebud)**
- Crea un nuovo progetto Godot 4.3 in Rosebud con prompt:  
  `"2D side-scroller pixel art dark moody action platformer with dual character system, gravity flip, time mechanics, 16-bit style"`
- Rosebud genererà automaticamente:
  - Struttura cartelle base
  - Sistema di input
  - Player template (David + Ken)
  - Camera 2D con follow

**Fase 2 – Codice Core con Cursor**
- Apri il progetto in **Cursor**
- Usa i seguenti prompt (esempi pronti):

```text
Crea un sistema Dual Hero Sync in GDScript:
- Due personaggi (David e Ken) sempre a schermo
- Cambio istantaneo con 0.12s invulnerabilità
- AI controlla il personaggio non selezionato
- Synergy Meter che riempie con azioni coordinate
- Echo Strike quando la barra è piena
