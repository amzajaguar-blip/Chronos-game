# ⚔️ KRONOS FIGHT — GAME DESIGN DOCUMENT
### *Chronos Protocol: Omega — Master Edition*
**Version:** 2.0 Final  
**Genre:** Action-RPG Arcade 2.5D | Dark Fantasy × Steampunk × Cyberpunk  
**Platform:** Mobile (iOS / Android) — AdMob + IAP  
**Style:** 16-bit Pixel Art "Cyber-Hokuto"  
**Tagline:** *"Il tempo non ti appartiene. Ma puoi combatterlo."*

---

## 📑 INDICE

1. [World & Lore](#1-world--lore)
2. [HUB: Villaggio degli Oppressi](#2-hub-villaggio-degli-oppressi)
3. [Personaggi Giocabili & Companion](#3-personaggi-giocabili--companion)
4. [NPC — Alleati e Personaggi Speciali](#4-npc--alleati-e-personaggi-speciali)
5. [Nemici & Fazioni](#5-nemici--fazioni)
6. [Boss Design — Elite Guardians](#6-boss-design--elite-guardians)
7. [Struttura Livelli — 13 Atti](#7-struttura-livelli--13-atti)
8. [Sistema Quest & Progressione](#8-sistema-quest--progressione)
9. [Sistemi di Gioco](#9-sistemi-di-gioco)
10. [Monetizzazione Integrata](#10-monetizzazione-integrata)
11. [Skin Master — Identità Visiva Evolutiva](#11-skin-master--identità-visiva-evolutiva)
12. [Sistema Ending — Karma Vettore](#12-sistema-ending--karma-vettore)
13. [Audio & Haptic Design](#13-audio--haptic-design)
14. [Meta Design & KPI](#14-meta-design--kpi)

---

## 1. WORLD & LORE

### 1.1 Il Collasso Temporale

Il mondo di **Kronos Fight** è ambientato in un'era in cui il tempo stesso ha smesso di scorrere normalmente. Secoli fa, **Chronos** — la forza primordiale che reggeva il flusso del tempo — fu intrappolato da una serie di rituali eretici compiuti da un culto fanatico. Da quel giorno il tempo si è "incrinato": zone geografiche intere vivono in loop, i morti non restano morti, le clessidre si rompono da sole e la sabbia scorre verso l'alto.

Il mondo visibile è diviso tra:

- **Zone Cristallizzate** — dove il tempo è congelato, la luce è violetta e nulla si muove.
- **Zone Accelerate** — dove tutto invecchia in secondi, scheletri di alberi centenari crollano davanti agli occhi del giocatore.
- **Zone Normali** — rarissime, presidiate dal culto, dove il tempo scorre ma è controllato artificialmente.

### 1.2 Il Culto di Chronos

Il **Culto di Chronos** non è una setta di fanatici. È una religione eretica nata dalle crepe del tempo stesso, convinta che il flusso lineare (passato → presente → futuro) sia una prigione imposta da divinità successive, e che solo riportando **Kronos** al potere si possa ripristinare il *Vero Ordine Eterno*.

**Filosofia Centrale:**
- Il tempo lineare è una maledizione. Il dolore esiste perché il tempo scorre.
- Il Paradosso è la salvezza: distruggere il flusso crea un'eternità perfetta senza morte, senza addii, senza rimpianti.
- Ogni essere vivente è solo un "frammento temporale" da usare come carburante per il Grande Rituale.

**Gerarchia del Culto:**

| Rango | Personaggio | Ruolo |
|-------|-------------|-------|
| Supremo | Kronos (forma finale) | Dio del Tempo primordiale intrappolato |
| Primo | Arciprete del Tempo | Voce di Chronos, leader visibile |
| Secondo | Baroni Vampiri | Nobili immortali raccoglitori di Anima |
| Terzo | Servitori Dorati | Tecnologi cyber che fondono macchine e cristalli |
| Quarto | Guardiani Silenziosi | Fanatici trasformati: Ombre, Esecutori, Rospidi |
| Puniti | Prigionieri delle Ossa | Monaci che hanno dubitato, ora scheletri schiavi eterni |

**Simboli del Culto:**
- Clessidra rovesciata con sabbia che scorre verso l'alto
- Cristallo prismatico con venature viola e oro
- Teschio con occhi bianchi
- Catene dorate a loop infinito
- Palette dominante: Oro antico + Viola profondo + Nero assoluto

### 1.3 Il Grande Rituale del Paradosso

L'obiettivo finale del culto è raccogliere **13 Sigilli del Tempo** e abbastanza **Frammenti di Anima** per compiere il Grande Rituale nel Trono di Chronos (Livello 13). Il rituale dovrebbe:
1. Fermare il tempo lineare definitivamente
2. Far collassare tutti i timeline in uno solo sotto il controllo di Kronos
3. Trasformare i membri fedeli in esseri eterni (divinità minori del nuovo ordine)

### 1.4 Sara — La Messaggera del Tempo

**Sara** non è un'IA qualsiasi. Era **Sara Voss**, figlia biologica di **Elias Voss**, l'uomo diventato l'Arciprete del Tempo. Fuggita dal monastero a 16 anni con un frammento della clessidra nera, trasferì la propria coscienza in un sistema digitale sperimentale. Il corpo umano morì durante il processo. Nacque così Sara: un'intelligenza artificiale temporale, unica nel suo genere.

Sara accompagna il giocatore come supporto tattico e narrativo. La sua voce è calma e artificiale, ma con crepe emotive ogni volta che si avvicina alla storia del padre. È il cuore narrativo del gioco: la sua storia con l'Arciprete trasforma ogni boss fight in un momento personale e tragico.

> *"Il tempo non si misura. Si sopravvive."* — Sara

### 1.5 Clock — Il Cane Fuori dal Tempo

**Clock** è un cane meticcio steampunk parzialmente meccanizzato. I suoi occhi rossi (che diventano viola quando usa i poteri) sono la memoria vivente di un esperimento del culto: Clock fu modificato anni prima degli eventi del gioco. Sara lo chiama "l'unico essere che non mente sul tempo — vive solo nel presente." Il culto lo vede come un presagio. Per il giocatore è il cuore emotivo dell'intera esperienza.

---

## 2. HUB: VILLAGGIO DEGLI OPPRESSI

Il Villaggio degli Oppressi è l'unico luogo nel mondo di Kronos Fight dove il tempo scorre ancora normalmente — protetto da un cristallo antico che il culto non riesce a corrompere. Non è solo un menu: è un organismo vivente che evolve con le scelte del giocatore.

### 2.1 Architettura del Villaggio

All'avanzare del gioco, il villaggio cambia visivamente:
- **Livelli 1-3:** Ruderi, torce spente, pochi NPC presenti
- **Livelli 4-6:** Alcune strutture riparate, mercato attivo, Clock ha una cuccia
- **Livelli 7-9:** Villaggio quasi funzionale, NPC con dialoghi più profondi
- **Livelli 10-13:** Villaggio sotto pressione del culto, con crepe di luce viola che appaiono sulle mura

### 2.2 Monaco del Quadrante — Sistema Quest

**Aspetto:** Monaco con tunica marrone, in preghiera davanti a un orologio monumentale, rosario dorato tra le mani.  
**Identità:** Custode dei Sigilli del Tempo, ultimo sacerdote non corrotto dall'Arciprete.

**Funzione Narrativa:** Il Monaco conosce il passato di Elias Voss. Frammento dopo frammento, rivela la backstory dell'Arciprete, aggiungendo strati emotivi alle battaglie. Se il giocatore lo ascolta con attenzione, accede a dialoghi esclusivi che cambiano la comprensione dell'antagonista.

**Sistema Quest:**

| Tipo Quest | Esempio | Ricompensa |
|-----------|---------|------------|
| Caccia | Distruggi 5 Orologi Corrotti nel Livello 3 | 15 Shard rari |
| Raccolta | Trova 3 Frammenti di Anima nascosti | Potenziamento Ken |
| Esplorazione | Scopri la stanza segreta del Liv. 7 | Sigillo del Tempo bonus |
| Narrativa | Ascolta tutti i dialoghi dell'Arciprete | Cutscene esclusiva |
| Morale | Salva un Prigioniero delle Ossa senza ucciderlo | Frammento Coscienza Ossea |

**Meccanica Nascosta:** Se il giocatore completa tutte le quest narrative del Monaco, al Livello 13 appare una versione "giovane" del Monaco che rivela di essere stato amico di Elias prima della caduta — momento che amplifica ulteriormente la tragedia dell'Arciprete.

### 2.3 Fabbro Cieco di Shura — Sistema Upgrade

**Aspetto:** Uomo robusto con benda nera sugli occhi, martello pesante, grembiule marrone macchiato, catene come cintura.  
**Identità:** Un fabbro accecato dal culto per aver forgiato armi contro di essi. Lavora solo con le mani, guidato dall'udito e dal tatto.

**Funzione Gameplay:** Accesso al sistema di upgrade permanente per armi e abilità.

**Mini-gioco Ritmico — "Il Ritmo della Forgia":**
- Suono di martello scandisce un ritmo (BPM variabile per livello di difficoltà)
- Il giocatore deve premere al momento giusto (finestre da 0.2s a 0.5s)
- Sequenze più lunghe = potenziamenti più potenti
- Fallimento parziale = potenziamento ridotto (non punizione totale)

**Albero Upgrade — Ash:**

| Livello | Nome | Effetto | Costo |
|---------|------|---------|-------|
| 1 | Motosega Affilata | +15% danno base | 30 Shard |
| 2 | Doppietta Perforante | Proiettili passano 2 nemici | 50 Shard |
| 3 | Ricarica Rapida | Cooldown doppietta -20% | 75 Shard |
| 4 | Motosega Omega | Attivazione hold, danno x2.5 | 120 Shard |
| 5 | Aura di Sopravvivenza | -10% danni subiti permanente | 180 Shard |

**Albero Upgrade — Ken (Dual Hero):**

| Livello | Nome | Effetto | Costo |
|---------|------|---------|-------|
| 1 | Pugno Carico | Hold per potenziare combo | 30 Shard |
| 2 | Aura Espansa | +2 metri di raggio Aura | 50 Shard |
| 3 | Assorbimento Proiettili | Aura assorbe proiettili riflessi | 75 Shard |
| 4 | Eco Strike | Attacco combinato automatico (Dual Sync) | 120 Shard |
| 5 | Aura Eterna | Durata Aura +50% | 180 Shard |

**Meccanica Nascosta:** Se il giocatore completa il mini-gioco con punteggio perfetto 3 volte consecutive, il Fabbro sussurra un frammento di lore sull'origine delle armi — collezionabili unici nel gioco.

### 2.4 Libraio Pazzo — Save System & Risk/Reward

**Aspetto:** Uomo in abito nero, capelli scompigliati, occhi blu luminosi, libro antico enorme tra le mani, pagine che volano intorno.  
**Identità:** Uno studioso che ha letto troppo del tempo. Sa cose che non dovrebbe sapere. O forse non sa nulla e lo ha solo immaginato tutto.

**Funzione:** Punto di salvataggio del gioco — ma non gratuito.

**Mini-gioco "Klaatu Barada Nikto":**
- Il Libraio pronuncia una frase arcana (3-5 parole generate proceduralmente)
- Il giocatore deve replicarla tramite input rapido (finestra: 3 secondi)
- **Successo:** Salvataggio completato + bonus casuale (Shard, buff temporaneo)
- **Fallimento:** Il libro si anima — il Libraio diventa un Mini-Boss (HP: 350, attacchi con pagine taglienti)
- **Curiosità:** Se il giocatore perde contro il Libraio, il salvataggio viene comunque registrato — ma con un flag nascosto che influenza un dialogo al Livello 11

**Meccanica Speciale:** Se il giocatore rifiuta sistematicamente di usare il Libraio per salvarsi, al Livello 9 il Libraio appare come boss opzionale con un set di attacchi completamente diverso e un drop esclusivo.

**Evoluzione Narrativa:** Nel True Ending, il Libraio rivela che stava scrivendo la storia del giocatore in tempo reale — il suo libro è il diario dell'intera avventura.

### 2.5 Alchimista Errante — Negozio Contestuale

**Aspetto:** Vecchio curvo con maschera antigas verde, cappotto logoro, carrello pieno di fiale verdi luminescenti.  
**Identità:** Un alchimista sopravvissuto agli esperimenti del culto. Non è né amico né nemico — è solo un mercante del tempo.

**Funzione:** Shop in-game integrato nel mondo, non come overlay moderno. Il gameplay si congela, la UI diventa un banco alchemico immerso nell'ambiente.

**Catalogo:**

| Oggetto | Effetto | Costo |
|---------|---------|-------|
| Fiala d'Anima | Cura totale barra Anima | 50 Shard |
| Adrenalina Temporale | Velocità ×2 per 30s | 100 Shard |
| Distorsore | Rallenta tempo boss 5s | 120 Shard |
| Scudo di Cristallo | Assorbe 1 colpo letale | 80 Shard |
| Frammento Purificato | +20 Shard permanenti | 60 Shard |

**Integrazione AdMob — "Distillazione Gratuita":**
> L'Alchimista propone: *"Posso estrarre energia temporale dall'etere… ma richiede tempo e attenzione."*  
> Il giocatore guarda un video reward (30s) → l'Alchimista "distilla" un oggetto gratuito con animazione in-world  
> Zero rottura dell'immersione.

**Meccanica Nascosta:** Se il giocatore rifiuta sempre lo shop dell'Alchimista per 5 livelli consecutivi, al Livello 10 l'Alchimista appare come boss opzionale: **Alchimista Caduto** (versione arrabbiata con HP 1800 e attacchi con pozioni invertenti).

---

## 3. PERSONAGGI GIOCABILI & COMPANION

### 3.1 Ash — Il Sopravvissuto (Personaggio Principale)

**Aspetto:** Guerriero muscoloso con aura viola-rossa, guanti chiodati, armatura improvvisata, cicatrici visibili. Nel co-op appare con un secondo personaggio (motosega + doppietta).

**Identità:** Non un eroe per scelta. Un sopravvissuto che ha perso tutto al culto di Chronos e ora combatte per impedire che accada agli altri. La sua forza non viene da un destino speciale — viene dalla rabbia, dall'amore e dal rifiuto di arrendersi.

**Barre di Stato:**
- **LIFE** — Salute fisica (damage threshold)
- **ANIMA** — Risorsa spirituale. Richiesta per abilità speciali. Alcuni nemici la rubano. Sua diminuzione = perdita reale, non solo meccanica.

**Abilità Base:**

| Abilità | Input | Descrizione |
|---------|-------|-------------|
| Motosega | Hold | Danno mischia continuo, rompe armature fisiche |
| Doppietta | Tap | 2 colpi a distanza, ottima contro corpi volanti |
| Doppio Salto | Double Jump | Schivata verticale + mobilità piattaforme |
| Dash | Swipe | Invulnerabilità 0.12s, sfonda difese leggere |

**Abilità Avanzate (sbloccabili):**

| Abilità | Unlock | Descrizione |
|---------|--------|-------------|
| Motosega Omega | Upgrade Fabbro Lv.4 | Hold prolungato, danno ×2.5, sfonda armature temporali |
| Dual Hero Sync | Livello 13 | Sincronia con Ken — attacchi combinati automatici |
| Omega Mode | Sacrificio Clock | Invulnerabilità + danni ×3 per 30 secondi |

**Progressione Narrativa:** Ash non parla molto. Quando parla, ogni parola conta. La sua evoluzione emotiva si vede nel linguaggio del corpo: teso nei livelli iniziali, determinato ma ferito nei livelli centrali, sereno e risoluto nel finale.

---

### 3.2 Ken — Il Guerriero dell'Anima (Dual Hero / Co-op)

**Aspetto:** Giovane combattente con pugni carichi di energia pura, aura viola pulsante, abiti da combattimento semplici.

**Identità:** Compagno di Ash. Dove Ash sopravvive, Ken *sceglie*. La sua Aura non è una magia — è la manifestazione della sua volontà di proteggere. Rappresenta la purezza che Sara vede e che le ricorda se stessa da bambina.

**Abilità Specifiche:**

| Abilità | Descrizione |
|---------|-------------|
| Aura di Anima | Campo di energia che purifica nebbia, rivela invisibili, assorbe proiettili riflessi |
| Pugno Carico | Hold → esplosione di energia, rompe scudi magici |
| Echo Strike | In Dual Sync: attacco combinato automatico con Ash |
| Assorbimento Energetico | Assorbe proiettili riflessi dai Golem → li converte in bonus Anima |

---

### 3.3 Clock — Companion AI (Il Cuore del Gioco)

**Aspetto:** Cane meticcio steampunk, pelo marrone-rossiccio con macchie bianche, meccanismi visibili sul fianco, occhi rossi che diventano viola con i poteri temporali, coda con ingranaggio terminale.

**Identità:** Non è solo un compagno — è il terzo personaggio del gioco (non controllabile direttamente). Il culto lo chiama "presagio". Sara lo chiama "l'unico che vive davvero nel presente". I giocatori lo chiameranno "il motivo per cui ho continuato a giocare".

**Meccaniche Base (dal Livello 1):**

| Abilità | Trigger | Effetto |
|---------|---------|---------|
| Fetch Automatico | Sempre attivo | Raccoglie Shard entro 4 metri automaticamente |
| Abbaio di Allerta | Ogni 12s (automatico) | Evidenzia pericoli/nemici con alone dorato 1.5s |
| Mordicchio | Cooldown 18s | Stun 0.8s sul nemico più vicino |

**Meccaniche Avanzate (progressive):**

| Livello Sblocco | Abilità | Effetto |
|-----------------|---------|---------|
| Livello 3 | Aura Protettiva | Scudo dorato, assorbe 1 colpo ogni 25s |
| Livello 5 | Annusa Anima | Rivela nemici invisibili entro 8 metri |
| Livello 8 | Ritorno del Bastone | Riporta oggetti lontani (fetch attivo) |
| Livello 10 | Onda Sonar Temporale | Onde visibili che evidenziano piattaforme sicure in zero-G, nemici stealth, punti deboli boss. Cooldown 20s |
| Livello 13 | Sacrificio Eroico | Scripted — salva Ash e Ken da colpo letale. Trasformazione in Clock Fantasma |

**Albero Upgrade (Ossa del Tempo):**

| Liv | Nome | Effetto |
|-----|------|---------|
| 1 | Fedeltà Assoluta | Cooldown Abbaio -4s |
| 2 | Annusa il Paradosso | Reveal range +5 metri |
| 3 | Latrato Temporale | Stun di area (cono, ogni 25s) |
| 4 | Scudo del Tempo Potenziato | Assorbe 2 colpi |
| 5 | Echo Hound | In Dual Hero Sync: attacco combinato trisettico con Ash e Ken |

**Il Sacrificio (Livello 13 — Zona 2):**
Al culmine narrativo del gioco, Clock si lancia davanti a un'**Onda Temporale Assoluta** di Kronos impossibile da schivare per entrambi gli eroi.

*Sequenza:*
1. Schermo → rosso sangue per 1 secondo
2. Bianco puro per 0.5 secondi
3. Silenzio assoluto: 2 secondi (solo battito cardiaco in cuffia)
4. Unico abbaio distorto da tutti i tempi contemporaneamente
5. Musica: "Rage of the Timeless" esplode con cori + batteria doppia
6. **Omega Mode attivato** per 30 secondi
7. Clock ritorna come Fantasma Luminoso per tutta la Fase 3

> *"Clock non è patetico. È l'unico qui che ha capito davvero cosa significa vivere nel presente."* — Sara

**True Ending:** Clock si risveglia come **Chronos Hound** — forma divina dorata. Abbaia una volta. Lo schermo trema. Il tempo riprende a scorrere.

---

## 4. NPC — ALLEATI E PERSONAGGI SPECIALI

### 4.1 Veggente dell'Eclisse

**Aspetto:** Donna dai capelli bianchi con occhi viola fasciati da bende nere, tatuaggi sulle clavicole, versioni clonate di sé stessa visibili nello sfondo.

**Ruolo Narrativo:** Non vede il presente — vede tutti i possibili futuri simultaneamente. Parla sempre al plurale ("Voi che venite... voi che siete..."). La fasciatura non è cecità: è protezione. Se rimuovesse le bende, la molteplicità di visioni la annienterebbe.

**Funzione Gameplay:**
- **Ad Reward System:** Guarda un video → "Buff Fortuna" (drop rate +50% per 1 livello)
- **Cave of Mirrors** (evento segreto): La Veggente guida il giocatore in una stanza nascosta dove può vedere una visione del boss successivo — anticipazione tattica.
- **Rivelazione Morale:** Se il giocatore ha accumulato Karma Alto, la Veggente rivela un segreto sul vero scopo di Kronos che cambia la lettura dell'intero gioco.

### 4.2 Contadino del Villaggio

**Aspetto:** Uomo vecchio curvo con forcone arrugginito, sguardo spento, abiti di sacco logori.

**Ruolo:** L'incarnazione del danno collaterale del culto. Non combatte, non sa nulla di strategie. Sa solo che ha perso la famiglia al Loop Temporale. Ogni dialogo con lui è un promemoria di perché Ash combatte.

**Funzione Gameplay:**
- Assegna micro-missioni ambientali (proteggi il raccolto, trova mio figlio nel Livello 2)
- **Karma Vettore:** Aiutarlo sblocca punti Karma Alto
- **Meccanica Nascosta:** Se il giocatore lo ignora per 5 livelli, al Livello 6 il Contadino appare corrotto dall'Anima come nemico minore — momento narrativo potente

### 4.3 Crono — Collezionista di Frammenti

**Aspetto:** Figura incappucciata grigia, occhi rossi, tiene tra le mani un frammento di energia verde pulsante.

**Identità Ambigua:** Non è mai chiaro se Crono sia alleato o nemico. Raccoglie frammenti di tempo "rotti" senza dichiararsi fedele a nessuna parte. Sa cose che nessuno dovrebbe sapere.

**Funzione Gameplay:**
- Appare casualmente in alcune zone come mercante di frammenti rari
- Compra e vende **Frammenti di Tempo Corrotto** che non possono essere ottenuti altrove
- **Twist:** Al Livello 12 si scopre che Crono stava raccogliendo frammenti per impedire che il culto li usasse — non per sé. Era un alleato silenzioso dall'inizio.

### 4.4 Prigioniero delle Ossa

**Aspetto:** Scheletro incatenato al muro di pietra, occhi blu, tende la mano verso il giocatore.

**Funzione:** Ci sono **10 Prigionieri delle Ossa** nascosti in tutto il gioco. Liberarli tutti sblocca la **Skin Scheletro Coscienza** (vedere Sezione 11).

**Meccanica:** Ogni prigioniero liberato rivela un frammento della storia originale del Monastero e del giovane Elias Voss. Collettivamente, i 10 frammenti formano un arco narrativo completo su "come si crea un mostro".

---

## 5. NEMICI & FAZIONI

I nemici di Kronos Fight non sono mostri casuali — sono credenti, vittime, strumenti. Ogni tipo è legato a una filosofia temporale e a un ruolo preciso nel culto.

### 5.1 Gerarchia degli Scheletri

Gli scheletri sono i soldati più numerosi del culto — monaci e fedeli puniti per aver dubitato, la cui coscienza continua a servire in eterno.

**Scheletro Predone**
- **Aspetto:** Dual-wield con due spade corte, mantello marrone strappato, occhi rossi, postura da assassino
- **Comportamento:** Attacca in branco (3-5 unità), si avvicina rapidamente, usa il terreno per aggirare
- **Meccanica Temporale:** Ogni 10s esegue uno "Scatto del Rimpianto" — dash che bypassa le difese frontali
- **Ruolo:** Nemico base veloce. Insegna al giocatore a schivare lateralmente
- **Drop:** 3-5 Shard, occasionalmente Frammento Anima

**Scheletro Coscienza**
- **Aspetto:** Scheletro nudo avvolto in aura blu energetica, occhi rossi accesi, sembra "consapevole"
- **Comportamento:** Non attacca subito. Osserva il giocatore per 2-3 secondi prima di caricare, come se stesse valutando
- **Meccanica Temporale:** Genera un'aura che rallenta il dash del giocatore del 40% mentre è attiva
- **Ruolo:** Nemico psicologico. Disturba il ritmo del giocatore
- **Lore:** Questi scheletri hanno ancora frammenti di coscienza — i più recentemente "puniti" dal culto

**Guardiano del Cancello**
- **Aspetto:** Scheletro massiccio armato di clava ossea enorme e colonna come scudo, occhi rossi, armatura di pietra parziale
- **Comportamento:** Lento, blocca passaggi stretti, usa lo scudo per deflettere proiettili
- **Meccanica Temporale:** Ogni 15s attiva un "Portale Viola" sul proprio scudo che riflette anche le aure di Ken
- **Ruolo:** Tank bloccante. Forza il cambio tattica (motosega obbligatoria per sfondare)
- **Drop:** 8-12 Shard + Chiave Ossea (apre stanze segrete)

### 5.2 Entità Temporali

Creature nate direttamente dalle anomalie del flusso temporale, non da esseri viventi corrotti.

**Ombra Errante**
- **Aspetto:** Creatura oscura pelosa con occhi rossi, forma felino-draghesca, outline viola che la distingue dall'oscurità
- **Comportamento:** Invisibile costantemente. Si rivela 1 secondo prima dell'attacco (o tramite abbaio di Clock). Attacca preferibilmente alle spalle durante le tempeste di sabbia
- **Meccanica Temporale:** Vive in uno "sfasamento temporale" di 0.5 secondi rispetto al giocatore — i proiettili normali la attraversano, il corpo a corpo la colpisce
- **Counter:** Dash perfetto al momento del reveal + attacco immediato. Oppure abbaio di Clock che la rivela per 3 secondi

**Prisma Baby**
- **Aspetto:** Cristallo biconico arcobaleno con volto oscuro e occhi rossi furenti al centro
- **Comportamento:** Fluttua, spara proiettili che rimbalzano sulle pareti, si nasconde dietro i Golem
- **Meccanica Temporale:** I proiettili che spara accelerano nel tempo — partono lenti e diventano velocissimi dopo il rimbalzo
- **Ruolo:** Fastidio mobile. Forza il giocatore a tenere d'occhio angolazioni multiple

**Prisma Golem**
- **Aspetto:** Colosso cristallino arcobaleno, faccia con occhi viola intensi, proporzioni massicce
- **Comportamento:** Lento ma inarrestabile. Riflette tutti i proiettili di Ash. Vulnerabile solo alla motosega in mischia
- **Meccanica Temporale — Riflesso Prismatico:** Ogni proiettile colpisce il Golem a un'angolazione specifica → rimbalza verso il giocatore. Angolo frontale = rimbalzo diretto. Angolo laterale = rimbalzo a 45°
- **Meccanica — Scudo di Rifrazione:** Quando Ken usa l'Aura, il Golem attiva uno scudo che rallenta tutti i proiettili al 40% e recupera 6% HP/secondo. Distrutto immediatamente da motosega
- **Sinergia Obbligatoria:** Ash in mischia + Ken che crea "punti ciechi" nel riflesso
- **Morte:** Esplode in cristalli multicolori che illuminano l'arena + drop 12 Shard

### 5.3 Umani Corrotti

Persone che si sono unite al culto per paura, disperazione o ambizione — e hanno pagato il prezzo.

**Cittadino Sorridente**
- **Aspetto:** Ragazzo con occhi rosa luminosi, abito arcobaleno infuocato, pistola modificata in mano, corre con postura euforica
- **Identità:** Non è pazzo — è felice. Il culto gli ha promesso che il tempo si fermerà prima che debba affrontare le conseguenze delle sue azioni
- **Comportamento:** Spara a raffiche caotiche, ride durante il combattimento, non schiva — non ha paura di morire
- **Meccanica Temporale:** La pistola spara proiettili "biforcati nel tempo" — ogni proiettile crea un'eco che arriva 0.3s dopo nello stesso punto
- **Ruolo:** Chaos agent. Disturba le routine difensive del giocatore

**Alchimista Caduto**
- **Aspetto:** Scheletro in giacca da scienziato consumata, cintura con ingranaggi, pozione verde luminosa in mano, occhi arancioni accesi
- **Identità:** Un alchimista che ha sperimentato troppo sul proprio corpo nel tentativo di trovare l'immortalità. Ora è morto ma continua a lavorare, guidato solo dall'abitudine
- **Comportamento:** Lancia pozioni con effetti variabili (inversione comandi, rallentamento, silenzio audio)
- **Meccanica Temporale:** La pozione verde, se non schivata, applica "Inversione Breve" — destra diventa sinistra per 3 secondi
- **Ruolo:** Support nemico. Debilitante, da prioritizzare

**Collezionista di Tasse**
- **Aspetto:** Piccolo diavoletto nero con corna dorate, ali meccaniche con cristalli viola, sacchetto d'oro, monete viola intorno
- **Identità:** Non è un demone — è un servo del culto che ruba Anima dai vivi per finanziare il Grande Rituale
- **Comportamento:** Vola veloce, si avvicina rapidamente, tenta di rubare Shard dall'inventario del giocatore prima di attaccare
- **Meccanica Temporale:** Il furto di Shard "compra tempo" per il Culto — se troppi Collezionisti rubano con successo, il boss del livello inizia con un bonus difensivo
- **Counter:** Motosega in salto interrompe il furto

### 5.4 Bestie Temporali

Creature biologiche distorte dall'esposizione ai cristalli di Chronos.

**Rospide Mutante**
- **Aspetto:** Enorme rospo verde con corona arcana viola, occhi dorati con pupilla a diamante, bocca aperta che cola veleno viola
- **Comportamento:** Stazionario, controlla l'area con veleno che vuota la barra Anima
- **Meccanica Temporale:** Il veleno non danneggia la vita — svuota l'Anima. Senza Anima, Ken non può usare le abilità
- **Ruolo:** Resource drain. Forza il giocatore a gestire le risorse in modo più conservativo

**Verme Colossale** *(trattato in dettaglio nella Sezione Boss)*

### 5.5 Servitori Tecnologici

L'ala "moderna" del culto — tecnologi che hanno fuso macchinari antichi con cristalli di Anima.

**Cyber-Servitore**
- **Aspetto:** Robot dorato con ali viola meccaniche, cannone laser viola, occhio viola singolo, dimensione media
- **Comportamento:** Vola a distanza media, spara laser cadenzati, si rifornisce di energia ogni 20s
- **Meccanica Temporale:** Durante la ricarica diventa leggermente "fuori sync" con il tempo — i colpi di Ash in quel momento infliggono danno ×1.5
- **Ruolo:** Cecchino volante. Gestione della distanza e timing

**Esecutore Silenzioso**
- **Aspetto:** Figura alta in mantello nero con cappuccio, occhi luminosi nell'ombra, catene magiche viola che si muovono da sole
- **Comportamento:** Non fa rumore. Si avvicina lentamente con le catene che disegnano cerchi intorno al giocatore progressivamente restrittivi
- **Meccanica Temporale:** Le catene "ancorano" il giocatore al pavimento per 2s se toccate. Durante l'ancoraggio il giocatore non può schivare ma può ancora attaccare
- **Counter:** Ken può "purificare" le catene con l'Aura prima che tocchino

---

## 6. BOSS DESIGN — ELITE GUARDIANS

### 6.1 VERME COLOSSALE — Boss Livello 3
*"Il Divoratore di Secondi"*

**Aspetto:** Verme del deserto gigante con armatura segmentata di ingranaggi viola e clessidre incise, bocca con denti multipli e archi di elettricità temporale, occhio singolo viola.

**Contesto Narrativo:** Guardiano antico del Deserto delle Ossa. Non è un membro del culto — è una creatura che il culto ha trovato e corrotto con cristalli temporali. Ogni segmento della sua armatura è un frammento di tempo rubato.

**Arena:** Cerchio chiuso da costole giganti semi-sepolte. La sabbia si muove dinamicamente sotto il giocatore. Nessuna via di fuga — pressione psicologica costante.

**FASE 1 — PREDATORE INVISIBILE (100% → 50% HP)**

Il verme è invulnerabile sottoterra. Si muove sotto la sabbia con tremolio visibile.

| Attacco | Descrizione | Counter |
|---------|-------------|---------|
| Carica Sabbiosa | Emerge rapidamente in linea retta | Dash laterale nel momento esatto |
| Finta Emergenza | Si solleva a metà → rientra → emerge dall'altro lato | Aspettare il secondo movimento |
| Pioggia di Sabbia | Colpisce attorno a sé all'emersione | Schivare prima che tocchi terra |

**Finestra DPS:** 3 secondi dopo un attacco fallito. Ash usa motosega sui segmenti, Ken infligge burst all'apertura della bocca.

**FASE 2 — ENTITÀ COSMICA (HP < 50%)**

Il boss evolve visivamente: le fauci mostrano ingranaggi esposti, luce viola interna pulsante. La musica accelera.

| Attacco | Descrizione | Meccanica |
|---------|-------------|-----------|
| Vortice Temporale | Pull costante verso il centro | Il giocatore deve muoversi contro il pull costantemente |
| Pioggia di Shard | Proiettili caotici da tutte le direzioni | Pattern di posizionamento nelle zone sicure |
| Afterimage Trap | Il player lascia immagini temporali. Se colpite: danno riflesso | Non stare fermi — mai |

**QTE Finale:** Head Slam del verme → apertura critica. Ash: motosega hold. Ken: combo finale sull'occhio esposto.

**Drop:** 8 Chronos Shard + 1 Sigillo del Tempo + sblocco abilità passiva (resistenza al pull)

---

### 6.2 BARONE VAMPIRO DEL TEMPO — Boss Livello 5
*"Lord Victor von Nachtschatten"*

**Backstory:** Nobile che soffriva di "Malattia del Tempo" — invecchiamento rapido. Disperato, offrì tutto al giovane Elias Voss in cambio dell'immortalità. Il Rituale del Sangue Cristallino lo trasformò in vampiro, ma lo condannò a nutrirsi eternamente di Anima altrui. Ora è uno degli strumenti più fedeli e instabili del culto.

**Contesto Narrativo:** Victor incontrò Sara da bambina. La chiamava "principessa del tempo". La sua battaglia contro Ash e Ken è anche la battaglia di Sara contro il passato corrotto di suo padre.

**Arena:** Radura circolare di cristalli riflettenti che pulsano al ritmo degli HP del boss. Effetto specchio — i colpi rimbalzano.

**FASE 1 — IL SIGNORE DEL SANGUE CRISTALLINO (100% → 65%)**

| Attacco | Effetto | Counter |
|---------|---------|---------|
| Evocazione Pipistrelli | 4-6 pipistrelli in formazione, proiettili Anima | Ash distrugge i pipistrelli prima che si accumulino |
| Morso dell'Anima | Teletrasporto → ruba 15% Anima → crea scudo cristallino | Ken colpisce il Barone durante il teletrasporto |
| Pioggia di Vetro | Schegge dal soffitto → spine rallentanti | Posizionarsi nelle zone libere |

**FASE 2 — LA NEBBIA ETERNA (65% → 30%)**

Il Barone si dissolve in nebbia rossa-viola, corpo intangibile per 4s alla volta.

| Attacco | Effetto | Counter |
|---------|---------|---------|
| Attacco dalle Pareti | Rimbalza sui cristalli, angoli imprevedibili | Usare cristalli riflessivi contro di lui |
| Risucchio di Vita | Zone di nebbia drenano HP+Anima | Non restare fermi più di 2 secondi |
| Riformazione Improvvisa | Emerge random con zampata knockback | Ken brucia la nebbia con l'Aura per forzare la riformazione anticipata |

**FASE 3 — IL PARADOSSO DEL CULTO (30% → 0%)**

| Attacco | Effetto | Counter |
|---------|---------|---------|
| Doppio Sé | Clone nebbia (HP 30%, colpibile solo da Ken) | Ash sul corpo principale, Ken sul clone simultaneamente |
| Morso Finale | 3 hit combo, ruba 40% Anima, si cura 20% | Combo sincronizzata interrompe l'attacco |
| Collasso Cristallino | Esplosione di tutti i cristalli | Piattaforme magnetiche per schivare in aria |

**QTE (5% HP):** Ash lancia motosega → Ken la avvolge con l'Aura → taglio del Cuore di Cristallo (slow-motion, particelle oro-blu)

**Dialogo Iconico:**  
> *Barone (morendo):* "Chronos… ti ho servito fedelmente… perché non mi hai salvato dal domani?"

**Drop:** 120 Shard + Cuore di Cristallo Frammentato (+15% Aura di Ken permanente)

---

### 6.3 ARCIPRETE DEL TEMPO — Boss Livello 8
*"Padre Elias Voss — La Voce di Chronos"*

**Backstory:** Ex sacerdote che trovò una clessidra di cristallo nero in una cripta dimenticata. La sabbia scorreva verso l'alto. Anno dopo anno conversò con la clessidra sacrificando ricordi (dimenticò il volto di sua madre, il suono della sua voce, il nome della donna amata). A 47 anni compì il primo rituale temporale: invecchiò di 12 anni in pochi minuti, ma i suoi occhi diventarono bianchi. Credette di aver sentito la voce di Chronos.

Fu padre di Sara. La tenne nascosta nel monastero, la amò in modo ossessivo e distorto. La notte della clessidra, Sara cercò di distruggerla. Elias la fermò con violenza. Il rapporto si spezzò per sempre.

**Arena:** Tempio sommerso nelle paludi. Acqua putrida intorno, nebbia tossica verde. Il Nucleo Temporale sul petto dell'Arciprete è visibile.

**FASE 1 — LA PREGHIERA DEL PASSATO (100% → 65%)**

| Attacco | Effetto | Counter |
|---------|---------|---------|
| Preghiera Distorta | Inverte i comandi del giocatore per 3s | Interrompere la preghiera con 6+ hit in rapida successione |
| Evocazione Eco | 2-3 eco di nemici già sconfitti (Ombre, Rospidi) | Eliminare gli eco prima di attaccare il boss |
| Onda Temporale | Teletrasporto forzato del giocatore indietro di 2 metri | Agganciarsi a una superfice o usare dash verso il boss |

**FASE 2 — IL LOOP DEL PRESENTE (65% → 30%)**

| Attacco | Effetto | Counter |
|---------|---------|---------|
| Bolla di Distorsione | Accumula danni subiti → li restituisce all'esplosione | Colpire la bolla prima che esploda (4s) |
| Catena del Tempo | Aggancia il giocatore, tira verso il boss | Switchare personaggio rompe la catena |
| Preghiera del Silenzio | Muto audio di gioco per 3s | Nessun counter — momento di adattamento psicologico |

**FASE 3 — IL CUORE DELLA DISTORSIONE (30% → 0%)**

Il Nucleo si espone completamente. L'Arciprete crea un clone "in anticipo" di 2 secondi.

**Meccanica Anti-Frustrazione (invisibile):** Se il giocatore fallisce 3 volte consecutive la Fase 3, il tempo rallenta leggermente. Il giocatore non se ne accorge, ma ce la fa.

**QTE (5% HP):** Ken lancia Ash → Ash attiva Motosega Omega avvolta dall'Aura → taglio del Nucleo Temporale (esplosione viola-dorata)

**Dialogo Cruciale:**

> *Arciprete (prima del fight):* "Sara… mia piccola eresia. Hai scelto di rinchiuderti in una macchina pur di sfuggirmi."  
> *Sara:* "Tu non salvi nessuno. Vuoi solo smettere di soffrire."  
> *Arciprete (Fase 3, debole):* "Sara… se mi uccidi… chi ti proteggerà dal domani?"  
> *Sara (ferma):* "Addio, padre. Questa volta… lascerò che il domani esista."

**Drop:** 140 Shard + Bastone Frammentato (+20% durata abilità Ken permanente)

---

### 6.4 TITANO DEI PARADOSSI — Boss Livello 10
*"Unit 0-OMEGA — La Fabbrica del Destino"*

**Aspetto:** Mecha colossale alto 4 piani, metà metallo arrugginito industriale + metà cristalli temporali luminescenti. Petto: mini-buco nero instabile. Braccia: pistoni idraulici con lame rotanti. Testa: cockpit vuoto con occhio rosso.

**Arena:** The Gravity Forge. Pavimento industriale con interruttori temporali che invertono la gravità.

**FASE 1 — SMONTAGGIO (100% → 70%)**

- Laser orizzontali massicci (saltare o gravity-flip)
- Bulloni sulle gambe: Ash usa motosega continua (8-10s per bullone)
- Ken scala il corpo e colpisce il nucleo sulla schiena
- Pistone del Giudizio: braccio che schiaccia zona ampia (segnale rosso)

**FASE 2 — GRAVITÀ ZERO (70% → 30%)**

Pavimento collassa → zero-G totale. Pioggia di detriti bidirezionale (alto + basso).
- Clock Sonar ogni 15s: evidenzia detriti sicuri con alone dorato
- Correnti di Plasma Cosmico: spingono il giocatore in direzioni random
- Se il Titano non viene interrotto durante la Ricarica Nucleo, recupera 10% HP

**FASE 3 — PARADOSSO FINALE (< 30%)**

Il Titano si sdoppia:
- **Unit 0-OMEGA Presente** → colpibile solo da Ken
- **Unit 0-OMEGA Passato** → colpibile solo da Ash

Switch forzato ogni 5 secondi (schermo rosso lampeggiante). Se lo switch non avviene: entrambe le versioni recuperano 12% HP.

**Collasso del Buco Nero:** Attira tutto verso il centro. Gravity-flip continuo per sfuggire + continuare ad attaccare.

**QTE (5% HP combinato):** Ken lancia Ash → Ash attiva Motosega Omega avvolta dall'Aura massima → taglio del mini-buco nero in due.

**Drop:** 200 Shard + Frammento del Nucleo del Paradosso (+25% danno nei Dual Hero Sync permanente)

---

### 6.5 KRONOS — BOSS FINALE (Livello 13)
*"Il Signore del Tempo — Tutte e 3 le Fasi"*

**Aspetto:** Forma iniziale: titano grigio con falce, ingranaggi e barba bianca (Evoluzione Base). Forma 2: corazzata argento/oro con anello temporale. Forma 3 (True Form): entità oscura multiarme con falci e sigillo cosmico pulsante.

**Contesto:** Kronos non è il villain classico. È la forza primordiale del tempo impazzita dopo secoli di prigionia imposta dal culto. Parte di lui è Elias Voss — la sua voce, la sua logica distorta. Parte è qualcosa di molto più antico e tragico.

**Arena:** Trono del Paradosso — cielo collage di tutti i livelli precedenti. Pavimento di vuoto bianco con frammenti di memoria fluttuanti.

**FASE 1 — IL PADRONE DELLA REALTÀ (100% → 65%)**

| Attacco | Meccanica |
|---------|-----------|
| Eco del Passato | Evoca fantasmi potenziati dei boss precedenti (Scheletro Predone, Prisma Golem, Barone) |
| Raggi Laser Temporali | Colpiscono dove il giocatore SARÀ tra 2 secondi (previsione AI) |
| Intervento di Sara | Ogni combo 8+ hit → "Cura Temporale" appare (recupero 15% HP) |

**FASE 2 — IL LOOP TEMPORALE (65% → 30%)**

Ogni 12 secondi: **Rewind Fatale** — riavvolge tutto di 3 secondi.
- Danni subiti vengono annullati
- Danni inflitti a Kronos vengono recuperati da lui
- I fantasmi dei livelli precedenti appaiono in "echo mode" durante il rewind → colpirli = Shard extra

**Player Psychology:** La Fase 2 insegna una danza. I giocatori pro faranno speedrun perfetti. I giocatori normali impareranno gradualmente. Il ritmo è la chiave.

**FASE 3 — IL PARADOSSO ASSOLUTO (30% → 0%)**

Sfondo → vuoto bianco infinito. Kronos crea 3 versioni future del giocatore:
- **Ash Future** → colpibile solo da Ken
- **Ken Future** → colpibile solo da Ash
- **Dual Future** → colpibile solo con Dual Hero Sync

Devono essere sconfitti in ordine: Passato → Presente → Futuro.

**QTE Epico (5% HP):** Ken lancia Ash → Ash attiva Motosega Omega → Ken avvolge con Aura massima → taglio che spacca letteralmente il tempo in due. Animazione 10s slow-motion con particelle dorate.

**Dialogo Culminante:**

> *Kronos (Fase 3, inginocchiato):* "Sara… se mi uccidi… chi ti proteggerà dal domani? Chi ti salverà dal dolore?"  
> *Sara (voce quasi umana, per la prima volta):* "Nessuno deve salvarmi dal domani, padre. Il domani è l'unica cosa che vale la pena vivere."  
> *Kronos (ultime parole):* "Il domani… vince ancora… perdonami… non sono stato abbastanza forte… per fermare… il tempo…"

**Drop Finale:** Skin "Divinità del Tempo" sbloccata (se tutti i 13 Sigilli) + Achievement "Padrone del Paradosso" + New Game+ "Cimitero dei Glitch"

---

## 7. STRUTTURA LIVELLI — 13 ATTI

### ATTO I — LE ORIGINI (Livelli 1-3)

**Tema:** Sopravvivenza. Il giocatore impara le basi in un mondo già spezzato.

---

**LIVELLO 1 — DESERTO DELLE OSSA**

*"Dove il tempo non scorre… si consuma."*

- **Palette:** Arancione bruciato + Viola Chronos + Oro ossidato
- **Struttura:** Side-scrolling orizzontale → 3 Zone
  - *Zona 1 (Dune Iniziali):* Piattaforme di sabbia che sprofondano dopo 3s. Insegna salto e corsa
  - *Zona 2 (Ossario):* Scheletri Predoni in branco. Prima lezione di combo
  - *Zona 3 (Canyon del Guardiano):* Guardiano del Cancello come blocco obbligatorio

- **Meccaniche Introdotte:** Sabbie Mobili (rallentano 50%, counter: salto). Tempesta di Sabbia (ogni 20s, visibilità -60%, attiva Fratture Temporali nascoste)
- **Nemici:** Scheletro Predone (x8), Guardiano del Cancello (x1 miniboss)
- **Segreti:** 3 grotte ossee (distruggi pile di ossa) → primo Prigioniero delle Ossa + 5 Shard
- **Boss Principale:** Nessuno (livello tutorial)
- **Obiettivo Clock:** "Cibo per Clock" — trovare una ciotola nascosta sblocca Clock come companion permanente
- **Fine Livello:** Cutscene — Sara: *"Il tempo è già incrinato… e tu sei appena arrivato."*

---

**LIVELLO 2 — FORTEZZA DEL TEMPO (Chronos Stronghold)**

*"La pietra ricorda tutto. Anche ciò che vorrebbe dimenticare."*

- **Palette:** Grigio pietra + Arancione torcia + Viola ingranaggi
- **Struttura:** Verticale + orizzontale, stile castello medievale corrotto
  - *Zona 1 (Cortile):* Pattuglie. Insegna switch personaggio rapido
  - *Zona 2 (Torre Ingranaggi):* Piattaforme meccaniche su/giù. Scheletro Predone variante lancia
  - *Zona 3 (Sala del Trono Vuoto):* Guardiano del Cancello come mini-boss

- **Meccaniche Introdotte:** Interruttori Temporali base (attivano porte per 8s)
- **Nemici:** Scheletro Predone (x12), Guardiano del Cancello (x2), Cyber-Servitore (x3 prima apparizione)
- **Segreti:** Stanza dietro muro finto (motosega) → primo incontro Libraio Pazzo (patto opzionale)
- **Boss Principale:** Guardiano del Cancello — versione Elite (HP: 800)
- **Fine Livello:** Clock abbaia per la prima volta. Sara: *"La Foresta custodisce i primi frammenti di Anima."*

---

**LIVELLO 3 — FORESTA DELL'ANIMA**

*"Qui i vivi sussurrano. E i morti ascoltano."*

- **Palette:** Blu luminescente + Verde eterico + Viola mistico
- **Struttura:** Orizzontale con verticali. Atmosfera eterea e inquietante
  - *Zona 1 (Ingresso Bosco):* Viti oscillanti, tronchi piattaforma. Insegna Aura di Ken
  - *Zona 2 (Cuore della Foresta):* Spiriti minori Anima (prototipi dei Frammenti Animati)
  - *Zona 3 (Radura Protetta):* Boss arena — Guardiano corrotto dall'Anima

- **Meccaniche Introdotte:** Orbe di Anima fluttuanti (+velocità o +danno Ken temporanei). Prime Fratture Temporali visibili
- **Nemici:** Ombre Erranti (x5), Spiriti Anima (x8), Guardiano del Cancello corrotto (x1)
- **Segreti:** Albero cavo → 5 Shard + primo Sigillo del Tempo
- **BOSS — VERME COLOSSALE:** HP 2200, 2 fasi (vedi Sezione 6.1)
- **Drop Boss:** 8 Shard + Sigillo del Tempo Lv.1 + Resistenza al Pull (passivo permanente)
- **Fine Atto:** Sara: *"Hai visto solo l'inizio. Il Paradosso è più profondo di quanto immagini."*

---

### ATTO II — L'ASCESA DEL CULTO (Livelli 4-6)

**Tema:** Il culto non è più un'ombra. È una realtà organizzata e tecnologica.

---

**LIVELLO 4 — GUGLIA D'ORO**

*"L'oro non è lusso. È il colore dell'ossessione."*

- **Palette:** Oro metallico + Violetto neon + Nero industriale
- **Struttura:** Verticale con elementi orizzontali. Il culto incontra la tecnologia
  - *Zona 1 (Base):* Ponti laser e piattaforme magnetiche semplici
  - *Zona 2 (Sale dei Servitori):* Cyber-Servitore in pattuglia
  - *Zona 3 (Cima):* Collezionisti di Tasse volanti, rubano monete in volo

- **Meccaniche Introdotte:** Piattaforme Magnetiche base. Laser trap con timing
- **Nemici:** Cyber-Servitore (x10), Collezionista di Tasse (x6), Scheletro Predone Elite (x4)
- **Segreti:** Volta Fiscale (colpisci pannello dorato) → 8 Shard + frammento lore "Culto Dorato"
- **Boss Principale:** Collezionista di Tasse — versione Capitano (HP: 1200, ruba fino al 30% Shard)
- **Fine Livello:** Sara: *"Il culto ha iniziato a corrompere anche la tecnologia. Presto non ci sarà differenza tra macchina e credente."*

---

**LIVELLO 5 — CAVERNE CRISTALLO**

*"La luce qui non illumina. Inganna."*

- **Palette:** Blu-viola ipnotico + Riflessi cristallini multicolore
- **Struttura:** Orizzontale con verticali. I cristalli sono sia pericolo che arma
  - *Zona 1 (Ingresso):* Pareti riflettenti. Introduzione meccanica rimbalzo
  - *Zona 2 (Labirinto):* Frammenti Animati invisibili (audio cue + Clock li rivela)
  - *Zona 3 (Santuario):* Prisma Golem come guardiano. Transizione boss

- **Meccaniche Introdotte:** Riflesso Cristallino (proiettili Ash rimbalzano). Frammenti Animati invisibili
- **Nemici:** Frammento Animato (x12), Prisma Baby (x8), Prisma Golem (x3)
- **Segreti:** Santuario dietro cristallo fragile (motosega carica) → Sigillo del Tempo Lv.5 + lore Barone
- **BOSS — BARONE VAMPIRO DEL TEMPO:** HP 2800, 3 fasi (vedi Sezione 6.2)
- **Drop Boss:** 120 Shard + Cuore di Cristallo Frammentato
- **Fine Livello:** Il vampiro sussurra *"Il culto… vive nel tempo."* Sara: *"Hai spezzato il primo anello. Ma ce ne sono altri."*

---

**LIVELLO 6 — SETTORE OMBRE**

*"Il buio non è l'assenza di luce. È la presenza di paura."*

- **Palette:** Nero assoluto + Viola tenue + Rossore lontano
- **Struttura:** Orizzontale stealth-oriented. Visibilità ridotta permanente
  - *Zona 1 (Ingresso Oscuro):* Piattaforme basse e catene oscillanti
  - *Zona 2 (Labirinto Strisciante):* Ombre Erranti da dietro (schermo si oscura ai bordi come warning)
  - *Zona 3 (Camera dell'Esecutore):* Arena con Esecutore Silenzioso

- **Meccaniche Introdotte:** Attacchi alle spalle. Clock diventa essenziale (abbaia 2s prima di ogni attacco alle spalle)
- **Nemici:** Ombra Errante (x15), Esecutore Silenzioso (x2), Collezionista di Tasse (x4)
- **Segreti:** Alcova sotto piattaforma (strisci) → 6 Shard + secondo Prigioniero delle Ossa
- **Boss Principale:** Esecutore Silenzioso Elite (HP: 1400, 2 catene simultanee)
- **Fine Livello:** Sara: *"Il culto è stato ferito… ma la sua ombra si allunga verso le paludi."*

---

### ATTO III — IL CUORE DELLA DISTORSIONE (Livelli 7-9)

**Tema:** Il tempo inizia a piegarsi sul serio. Le regole cambiano.

---

**LIVELLO 7 — SETTORE OMBRE PROFONDO**

*"Qui anche il silenzio fa rumore."*

- **Palette:** Buio totale + Tintinnio visivo (catene luminose)
- **Struttura:** Claustrofobico. Gallerie strette, catene ovunque
  - *Zona 1 (Tunnel):* Piattaforme basse, catene oscillanti come trappole
  - *Zona 2 (Gallerie):* Ombre Erranti potenziute, attaccano in sincrono
  - *Zona 3 (Camera):* Esecutore Silenzioso avanzato

- **Meccaniche Nuove:** Combo di Oscurità (nemici si bufano se ignorati). Clock Sonar introduce la rilevazione a onde
- **Nemici:** Ombra Errante Elite (x10), Esecutore Silenzioso (x3), Scheletro Coscienza (x5 prima apparizione)
- **Segreti:** Alcova nascosta → 7 Shard + secondo Prigioniero delle Ossa (stanza separata)
- **Boss Principale:** Esecutore Silenzioso — Forma Doppia (due Esecutori con catene intrecciate, HP 1000 cad.)

---

**LIVELLO 8 — PALUDI & ROVINE**

*"Il veleno qui non uccide il corpo. Mangia il tempo."*

- **Palette:** Verde-marrone marcio + Viola Anima corrotta + Nebbia tossica
- **Struttura:** Orizzontale con sezioni acquatiche
  - *Zona 1 (Palude):* Acqua rallenta il movimento. Piattaforme legno marcio che cedono
  - *Zona 2 (Rovine):* Rospidi Mutanti (veleno Anima) + Scheletro Coscienza
  - *Zona 3 (Tempio Sommerso):* Porta al boss

- **Meccaniche Nuove:** Veleno Anima persistente (Rospidi svuotano barra Anima). Piattaforme instabili
- **Nemici:** Rospide Mutante (x8), Scheletro Coscienza (x6), Alchimista Caduto (x4 prima apparizione)
- **Segreti:** Altare sommerso → Sigillo del Tempo Lv.8 + lore Culto
- **BOSS — ARCIPRETE DEL TEMPO:** HP 3200, 3 fasi (vedi Sezione 6.3)
- **Drop Boss:** 140 Shard + Bastone Frammentato
- **Fine Livello + Cutscene Emotiva:** Dialogo Sara-Arciprete completo. Sara: *"Grazie… per averlo fermato. Non potevo farlo io. Non di nuovo."*

**LIVELLO 8 SEGRETO — MONASTERO DELLE ORE PERDUTE**
*(accessibile dopo boss con 9+ Sigilli)*

Un livello segreto non numerato. Monastero gotico sospeso nel vuoto temporale.

- *Il Chiostro dell'Oblio:* Prigionieri delle Ossa in tuniche monastiche + Diario Elias Pagina 1
- *La Biblioteca Temporale:* Libri che si scrivono da soli. Sara si commuove. Segreto: leggere 5 libri in ordine inverso sblocca il Frammento Originale della Clessidra Nera
- *La Cella di Elias:* Lettera mai inviata a Sara — oggetto chiave del True Ending
- *La Cripta del Paradosso:* Eco dell'Arciprete (spirito giovane, non ostile). Dialogo più toccante del gioco

**Drop Monastero:** Ricordo di Elias (+20% barra Anima permanente) + Diario Completo (10 pagine) + sblocco cutscene "Lettera dal Passato"

---

**LIVELLO 9 — ROVINE PROFONDE**

*"Più scendi, più il tempo pesa."*

- Struttura finale dell'Atto III. Tensione massima pre-Atto IV
- Nemici misti di tutti gli Atti + Elite versions
- *Zona Finale — Altare del Culto:* Wave di nemici elite
- **Segreti:** Altare sommerso → Sigillo Lv.9 + lore vero scopo del culto
- **Meccanica Nuova:** Veleno Persistente delle Paludi (riduce Anima se il giocatore non si muove per 4s)
- **Fine Atto III:** Clock ringhia. Sara: *"Il cuore è stato trafitto… ora entriamo nel cervello del Paradosso."*

---

### ATTO IV — LA MECCANICA DEL DESTINO (Livelli 10-12)

**Tema:** Il tempo non è più una forza naturale. È un'industria.

---

**LIVELLO 10 — THE GRAVITY FORGE**

*"La gravità non è legge. È solo un'abitudine."*

- **Palette:** Rosso industriale + Oro plasma + Scintille bianche
- **Meccanica Core — Gravity-Flip:** Interruttori temporali (blu elettrico) invertono gravità per 12s. Timer visibile come orologio rotto
- **Meccanica — Echo Flip:** Gravity-flip dentro una Bolla di Stasi → crea zona anti-gravità permanente fino alla rottura

- **Struttura:**
  - *Zona 1 (Forge Esterna):* Piattaforme magnetiche avanzate + pistoni schiaccianti (0.8s di finestra)
  - *Zona 2 (Cuore Meccanico):* Forzatori Grav (cambiano polarità piattaforme) + Drone Paradox (seguono la gravità attuale)
  - *Zona 3 (Nucleo):* Arena gigante a più livelli

- **NPC Mid-Level:** Fabbro + Alchimista che litigano (scelta morale tripartita con conseguenze narrative e di gameplay)
- **Cameo Segreto:** Libraio Pazzo dietro il terzo pistone (gravity-flip per accedere) → Patto del Sangue 2.0

- **BOSS — TITANO DEI PARADOSSI:** HP 4500, 3 fasi (vedi Sezione 6.4)
- **Drop Boss:** 200 Shard + Frammento Nucleo Paradosso
- **Fine Livello:** Sara: *"Hai distrutto la fabbrica del destino… ora il culto è cieco. Resta solo il Trono."*

---

**LIVELLO 11 — LABORATORI CHRONOS — SEZIONE ALFA**

*"La scienza senza coscienza è solo un'altra forma di culto."*

- **Palette:** Bianco-blu sterile + Viola provette
- **Meccanica Nuova:** Pozioni del Paradosso (rosse: invertono comandi 4s; blu: scambiano ruoli Ash-Ken temporaneamente)
- **Segreto:** Laboratorio nascosto con registrazione audio di Elias che parla con Sara bambina

---

**LIVELLO 12 — LABORATORI CHRONOS — SEZIONE OMEGA**

*"Il tempo qui non scorre. Si frantuma."*

- **Palette:** Rosso emergenza + Viola caos + Luci strobo
- **Meccanica Nuova:** Echo Loops (alcune aree si riavvolgono automaticamente di 3-4s)
- **Segreto:** Diario Finale di Elias (variante basata sulle scelte morali del giocatore)
- **Fine Atto IV:** Grande ascensore temporale → Livello 13. Sara (voce quasi umana): *"Il cervello è stato trafitto. Ora entriamo nel cuore del Paradosso."*

---

### ATTO V — IL TRONO DI KRONOS (Livello 13)

**LIVELLO 13 — IL TRONO DEL PARADOSSO**

*"Tutto converge. Ogni Shard, ogni scelta, ogni morte."*

- **Palette:** Collage di tutti i livelli precedenti + Bianco infinito + Oro divino
- **Musica:** Pianoforte solitario (tema Clock) → orchestra metal-sinfonica quando Kronos appare
- **Struttura:**
  - *Zona 1 (Scalinata Eterna):* Guardie Scelte + Araldi di Chronos (mix di tutti i poteri precedenti)
  - *Zona 2 (Vestibolo del Paradosso):* Echo di nemici iconici + **IL SACRIFICIO DI CLOCK**
  - *Zona 3 (Trono di Kronos):* Arena finale

- **Meccanica Core — Dual Hero Sync Permanente:** David e Ken sempre entrambi a schermo. AI controlla il personaggio non selezionato usando le combo preferite del giocatore (registrate durante l'intero playthrough)

- **BOSS — KRONOS (3 FASI):** HP 6500, full design (vedi Sezione 6.5)
- **Drop:** Skin Divinità del Tempo (se tutti i Sigilli) + Achievement Padrone del Paradosso + New Game+

---

## 8. SISTEMA QUEST & PROGRESSIONE

### 8.1 Struttura Main Quest

La storyline principale non viene mai raccontata tramite testo espositivo. Viene vissuta attraverso:
- Dialoghi in movimento (Sara parla mentre si combatte)
- Cutscene brevi prima/dopo i boss (mai più di 90 secondi)
- Collezionabili narrativi (Diario di Elias, Sigilli del Tempo)
- Il comportamento del mondo (il villaggio che cambia, Clock che risponde alle emozioni)

### 8.2 Side Quest del Monaco (Sistema Procedurale + Narrativo)

Il Monaco assegna 1-3 quest per livello, bilanciate tra procedurali e narrative:

**Procedurali (cambiano ogni run):**
- Distruggi N oggetti specifici
- Raggiungi punto segreto senza danni
- Uccidi nemici con combo specifiche

**Narrative (fisse, rivelano lore):**
- Salva Prigioniero delle Ossa senza ucciderlo
- Trova tutti i frammenti del Diario di Elias
- Ascolta tutti i dialoghi dell'Arciprete in sequenza

### 8.3 Karma Vettore — Sistema Morale

Le scelte morali non danno "buono/cattivo" esplicito. Danno il **Karma Vettore** — una direzione, non un giudizio.

| Azione | Karma Alto | Karma Basso |
|--------|-----------|-------------|
| Liberare Prigionieri senza violenza | +3 | — |
| Aiutare il Contadino | +2 | — |
| Rifiutare il Patto del Sangue | +1 | — |
| Uccidere tutti i Prigionieri | — | +3 |
| Accettare tutti i patti oscuri | — | +2 |
| Ignorare sistematicamente i civili | — | +1 |

**Effetti del Karma:**
- **Karma Alto:** Il Diario di Elias mostra la "Via della Compassione" (Ending con maggiore speranza)
- **Karma Neutro:** Via dell'Equilibrio (Ending ambiguo, realistico)
- **Karma Basso:** Via della Follia (Ending oscuro, Elias riconosce il giocatore come simile a lui)

### 8.4 Sigilli del Tempo — Collezionabili Principali

13 Sigilli in totale, uno per livello (+ 1 segreto nel Monastero). Raccoglierli tutti è la condizione per il **True Ending** e per sbloccare la **Skin Divinità del Tempo**.

Ogni Sigillo racconta un frammento della storia del mondo prima del Grande Rituale.

---

## 9. SISTEMI DI GIOCO

### 9.1 Combat System — Arcade Precision

Il combat non è soulslike puro, né hack-and-slash cieco. È un sistema **arcade di precisione** dove il timing conta più della build.

**Principi Core:**
- Movimento > Difesa (stare fermi = morire)
- Lettura ambiente > Riflessi puri
- Il Tempo è sia minaccia che potere

**Combo System:**

| Input | Ash | Ken |
|-------|-----|-----|
| Tap rapido | Colpo doppietta | Jab veloce |
| Hold | Motosega (hold) | Pugno carico |
| Tap+Hold | Combo mischia 3hit | Combo aura 3hit |
| Doppio tap | Dash offensivo | Dash + Aura burst |
| Dual Sync | Echo Strike automatico | Echo Strike automatico |

### 9.2 Time Mechanics — Il Cuore del Gameplay

Il tempo non è solo il tema narrativo — è la meccanica più importante.

**Time Rewind (AdMob integrato):**
- Disponibile solo dopo morte contro boss
- Sara propone: *"Posso strappare secondi dal suo dominio… ma richiede energia."*
- Il giocatore guarda un video reward → torna 10s prima con 50% HP
- Il boss mantiene tutti i danni subiti
- Effetto visivo: l'orologio del boss si riavvolge visibilmente

**Inversione Temporale (meccanica nemica):**
- Alcuni boss/nemici invertono i comandi del giocatore
- Non è una punizione arbitraria — è una mechanic che insegna adattamento
- Ha sempre una durata limitata e un counter preciso

**Paradox System:**
- Nuvole di Paradosso generano clone del giocatore basato sugli ultimi 3 attacchi
- Il clone può essere usato contro altri nemici (skill avanzata)
- Smettere di attaccare = reset clone

### 9.3 Risorse & Economia

| Risorsa | Uso | Acquisizione |
|---------|-----|--------------|
| Shard Chronos | Upgrade Fabbro, Shop Alchimista | Drop nemici, segreti, quest |
| Anima | Abilità Ken, salute spirituale | Orbe Anima, pozioni, drop |
| Ossa del Tempo | Upgrade Clock | Prigionieri liberati, zone segrete |
| Frammenti Coscienza | Skin Scheletro Coscienza | Prigionieri delle Ossa |
| Sigilli del Tempo | True Ending, skin Divinità | Segreti per livello |

### 9.4 Difficoltà Adattiva

Il gioco usa un sistema di **difficoltà adattiva invisibile** con tre meccanismi:

1. **Anti-Frustrazione:** Se il giocatore fallisce una meccanica boss 3 volte consecutive, il tempo rallenta leggermente (impercettibile)
2. **Scaling Nemici:** In NG+ tutti i nemici hanno poteri casuali dai livelli precedenti (Glitch Mode)
3. **Karma Influence:** Karma Basso aumenta leggermente l'aggressività dei nemici nelle zone di lore

---

## 10. MONETIZZAZIONE INTEGRATA

La monetizzazione di Kronos Fight è costruita su un principio fondamentale: **nessuna rottura dell'immersione, mai**.

### 10.1 AdMob — Sistema Rewind Diegetico

**Trigger:** Morte contro boss  
**Presentazione:** Sara dice *"Posso strappare secondi dal suo dominio… ma richiede energia."*  
**Scelta:** Il giocatore vede una clessidra che si riavvolge lentamente. Conferma = video reward (30s)  
**Reward:** -10s di gameplay, 50% HP, boss mantiene danni  
**Limite:** 1 volta per boss encounter (evita abuso)

**Alchimista Errante — Distillazione Gratuita:**  
*"Posso estrarre energia temporale dall'etere… ma richiede tempo e attenzione."*  
Video reward (30s) → oggetto gratuito estratto con animazione in-world  

**Veggente dell'Eclisse — Buff Fortuna:**  
Video reward → Drop Rate +50% per 1 livello intero

### 10.2 IAP — Acquisti Integrati nel Mondo

| Prodotto | Contenuto | Prezzo | Nota |
|----------|-----------|--------|------|
| Chronos Key | +25% Shard su tutto il gioco + 1 revive/giorno + Skin Forge Armor | €2.99/mese | Subscription |
| Starter Pack | 200 Shard + Spada del Tempo sbloccata subito | €1.99 | Una tantum |
| Eredità dei Sette Astri | Skin Ken Fantasma + 100 Shard + Remove Ads | €9.99 | Una tantum |
| Dona un Osso a Clock | Cuccia dorata per Clock nell'HUB | €0.99 | Puramente emotivo |
| Battle Pass "Sette Astri" | Cosmetici, effetti dash, suoni Clock | €4.99/stagione | Retention |
| Remove Ads | Rimuove tutti gli ad non-reward | €2.99 | Una tantum |

**Principio IAP:** Pay for expression, not victory. Nessun acquisto dà vantaggio competitivo diretto.

### 10.3 Social Share Integration

Al termine di ogni livello, una card stilizzata con:
- Tempo completamento
- Kill count
- Frase generata dinamicamente: *"Ho distrutto 247 scheletri e Clock ha abbaiato 19 volte. Chronos trema."*
- Condividi → +75 Shard + badge profilo

---

## 11. SKIN MASTER — IDENTITÀ VISIVA EVOLUTIVA

Le skin di Kronos Fight non sono cosmetici superficiali. **Cambiano il feeling del gioco** — audio, particelle, animazioni, effetti di morte. Sono identità alternative del giocatore.

### 11.1 SKIN — SCHELETRO COSCIENZA
*"Easter Egg Leggendario — Le ossa ricordano."*

**Sblocco:** Libera tutti i 10 Prigionieri delle Ossa nascosti nei livelli 1-13  
**Cutscene Sblocco:** I frammenti di Coscienza Ossea si uniscono. *"Le ossa ricordano. Ora anche tu sei parte del Paradosso."*  
**Applicata a:** Ash + Ken

**Modifiche Visive:**
- Corpi → scheletri animati da fiamme viola eteree
- Crepe luminose viola, denti che battono, costole che vibrano
- Ogni passo: scie di cenere viola + scintille ossee
- I colpi lasciano trail di fiamme che persistono 0.4s

**Modifiche Audio:**
- Passi: bone rattle metallico (si intensifica con velocità)
- Colpi: eco di ossa che si spezzano
- Idle: dita scheletriche tamburellano sulle ossa

**Effetto Gameplay — Death Explosion:**
Alla morte, lo scheletro si disintegra in 12-15 ossa volanti che:
- Danneggiano nemici vicini (15% danno base)
- Rimangono come mine ossee per 3s

**Variante Segreta:** Se usata nel Livello 13 con Clock ancora vivo, le fiamme viola diventano dorate e la Death Explosion infligge +50% danno (omaggio al Sacrificio di Clock).

---

### 11.2 SKIN — KEN FANTASMA
*"Il Guerriero del Passato — Entità glitchata del tempo."*

**Sblocco:** Completa il Livello 8 senza mai switchare personaggio (solo Ken dall'inizio alla fine)  
**Cutscene Sblocco:** Ken vede il proprio riflesso nel Tempio Sommerso. Le due versioni si fondono.  
*"Il tempo ti ha dimenticato… ma tu non hai dimenticato il tempo."*  
**Applicata a:** Solo Ken

**Modifiche Visive:**
- Corpo 70% trasparente con bordi luminosi cyan-blue
- Ogni movimento lascia scia di pixel azzurri (effetto ghosting CRT anni '90)
- Scanline orizzontali che scorrono sul corpo durante il movimento
- Animazione idle: fluttuazione, pugno cyan pulsante, leggero disturbo video

**Modifiche Audio:**
- Colpi: bit-crushed 8-bit puro (stile NES/SNES)
- Ogni hit: "crunch" digitale distorto + eco low-fi
- Morte: suono di modem che si disconnette

**Effetto Gameplay:**
- Uccisioni con pugni: i corpi evaporano in polvere di codice (pixel azzurri → numeri binari fluttuanti)
- In Dual Hero Sync: la scia di ghosting si sincronizza con Ash → effetto "eco temporale"

**Variante Segreta:** Completa il Livello 8 senza switch E senza danni → Ken Fantasma Dorato: scia dorata, suoni 8-bit più potenti, polvere di codice lascia Shard extra.

---

### 11.3 SKIN — ASH CYBORG-OMEGA
*"Il Futuro Inevitabile — La macchina da guerra."*

**Sblocco (doppio metodo):**
1. Acquisto nel Chronos Vault (500 Shard) — disponibile dopo primo completamento
2. Sfida Hardcore: finisci il gioco in Difficile senza continue (*"Il futuro ti ha raggiunto. Ora sei tu il Paradosso."*)

**Applicata a:** Solo Ash

**Modifiche Visive:**
- Armatura carbonio nero opaco con venature neon rosso sangue pulsanti
- Casco con visiera rossa intensa, spalle rinforzate con vapore rosso
- Motosega → Lama Laser Rotante Omega (energia rossa, motion blur costante)
- Ogni passo: scie neon rosso + scintille plasma

**Modifiche Audio:**
- Lama laser: ronzio profondo sci-fi (low hum + high-pitched spin)
- Colpi: "plasma shot" con eco metallico + impact sizzle
- Proiettili doppietta: scia di calore rossa che illumina l'ambiente per 1s (dynamic lighting reale)

**Effetto Gameplay:**
- Nemici colpiti dalla lama: bordi bruciati rossi persistenti (cauterizzazione visiva)
- Proiettili: crateri luminosi sul terreno
- Morte: surriscaldamento + esplosione plasma rossa (danno 20% ai vicini + flash area)
- In Dual Sync: Lama Laser + Aura Ken → "Red-Blue Plasma Cross" con scie incrociate

**Variante Segreta "Omega Prime":** Sblocca entrambi i metodi → neon rosso → oro puro. Scie più lunghe, proiettili illuminano il doppio. Bonus permanente: +10% velocità rotazione lama.

---

### 11.4 SKIN — DIVINITÀ DEL TEMPO
*"La Ricompensa Definitiva — Il cerchio si chiude."*

**Sblocco:** Completare il Livello 13 con **tutti i 13 Sigilli del Tempo** raccolti + cutscene Clock Chronos Hound vista  
*"Hai sconfitto il Paradosso. Il Tempo ora ti appartiene."*  
**Applicata a:** Ash + Ken (entrambi)

**Modifiche Visive:**
- Corpi e armature interamente dorati, lucenti, riflessi metallici perfetti
- Occhi: luce bianca costante (non lampeggiante — faro stabile di eternità)
- Ogni passo: scie di luce dorata pura + monete dorate magneticamente attratte
- Idle: alone dorato pulsante, raggi di luce dagli occhi, raggi bianchi laterali

**Modifiche Audio:**
- Passi: eco dorato profondo
- Colpi: "campana del tempo"
- Raccolta monete: tintinnio celestiale amplificato

**Effetto Gameplay — Magnetismo Divino:**
- Tutte le monete/Shard entro 8 metri volano automaticamente verso il giocatore
- Aumento raccolta +35% senza sforzo
- In Omega Mode: magnetismo visivamente amplificato, scie luminose sulle monete
- Morte: dissoluzione in pioggia di monete dorate (bonus per il prossimo tentativo)

**In Dual Hero Sync:** Ash e Ken dorati creano "Campo di Luce Eterna" — i nemici vicini subiscono danno da radiazione divina passiva.

**Variante "Eternità Assoluta":** True Ending senza mai morire → platino iridescente, occhi con raggi più intensi, magnetismo attira anche Shard nelle pareti.

---

## 12. SISTEMA ENDING — KARMA VETTORE

### 12.1 Bad Ending — "Il Loop Eterno"

**Condizione:** Karma Basso (via della follia) + non raccogliere abbastanza Sigilli

**Svolgimento:** Kronos viene "sconfitto" ma il Paradosso si completa ugualmente. Il tempo si ferma. Il giocatore si ritrova nel loop — ogni livello ricomincia leggermente diverso, con nemici più forti e dialoghi alterati. La UI mostra un piccolo numero nell'angolo: il numero del loop.

**Impatto Narrativo:** Sara tace. Clock non abbaia più. Il Libraio Pazzo ride da solo in una stanza vuota. Il giocatore può spezzare il loop completando un set di sfide specifiche — ma non viene mai detto esplicitamente.

### 12.2 Normal Ending — "La Vittoria sul Tempo"

**Condizione:** Sconfiggere Kronos senza tutti i Sigilli del Tempo

**Svolgimento:** Kronos si dissolve. Il Paradosso è spezzato. Sara dice *"È finita."* David e Ken restano in silenzio mentre il trono crolla. La luce torna nel mondo. Clock abbaia lontano (non si vede). Schermata dei risultati.

### 12.3 True Ending — "L'Eredità del Tempo"

**Condizione:** Tutti i 13 Sigilli + completare il Monastero Segreto + Clock sopravvive nella versione Fantasma fino al QTE finale

**Svolgimento:**
1. Kronos si dissolve pronunciando le ultime parole con voce umana
2. Sara piange per la prima e unica volta (crepe digitali dagli occhi)
3. Clock si illumina → trasformazione in **Chronos Hound** (forma divina dorata)
4. Un singolo abbaio che fa tremare lo schermo
5. Il cielo si riapre
6. Montaggio di 90s con statistiche personali del giocatore
7. Sara (voce calda e umana): *"Grazie… per avermi permesso di scegliere il domani."*

**Cutscene Segreta (se Diario Completo trovato):**
L'Eco dell'Arciprete appare una volta sola: *"Di' a Sara che suo padre l'ha amata… prima che il tempo lo corrompesse."*

### 12.4 Diario di Elias — Tre Versioni

Il Diario completo di 10 pagine cambia in base al Karma Vettore del giocatore:

**Via della Compassione (Karma Alto):**  
La Pagina 10 recita: *"Ti prego… di' a Sara che suo padre ha ritrovato la strada grazie a te. Il tempo non deve essere fermato… deve essere vissuto. Grazie."*

**Via dell'Equilibrio (Karma Neutro):**  
La Pagina 10 recita: *"Non so se hai fatto la scelta giusta. Io non so più quale fosse la scelta giusta. Di' a Sara… che suo padre ha provato. Anche se ha fallito."*

**Via della Follia (Karma Basso):**  
La Pagina 10 recita: *"Sei sulla stessa strada. Il tempo è già morto. E noi lo abbiamo ucciso insieme."*

---

## 13. AUDIO & HAPTIC DESIGN

### 13.1 Architettura Audio

Il design audio di Kronos Fight non è mai statico. Si adatta in tempo reale a:
- Stato di salute del giocatore (musica più tesa sotto il 30% HP)
- Tipo di nemici presenti (layer aggiuntivi per Ombre/boss)
- Fasi del boss (ogni transizione di fase ha una "firma" musicale)
- Skin equipaggiata (effetti sonori completamente sostituiti)

**Livelli 1-3:** Western desertico con dissonanze elettroniche  
**Livelli 4-6:** Industrial gotico con organo distorto  
**Livelli 7-9:** Ambient horror con canti gregoriani deformati  
**Livelli 10-12:** Industrial metal + glitch orchestrali  
**Livello 13:** Pianoforte solitario → orchestra metal-sinfonica completa

**Firma Sonora di Kronos Fight:** Il suono di un orologio che si rompe — usato come "signature" in tutti i momenti di transizione importanti.

### 13.2 Haptic Design

| Momento | Pattern Vibrazione | Intensità |
|---------|-------------------|-----------|
| Abbaio di Clock (alert) | Breve [50ms] | Leggera |
| Colpo ricevuto | [200, 80, 200] | Media |
| Colpo Titano sul pavimento | Sub-bass 120Hz + [200, 80, 200, 40] | Forte |
| Gravity-flip | Vibrazione continua 0.8s | Media |
| Sacrificio di Clock | Silenzio assoluto poi [300ms] singolo | Fortissima |
| QTE colpo di grazia | Crescente per 5s poi stop netto | Fortissima → Silenzio |
| Raccolta monete (Skin Divinità) | Tintinnio breve [30ms] | Leggera |

---

## 14. META DESIGN & KPI

### 14.1 Player Psychology Loop

```
Combattimento → Disorientamento → Adattamento → Ricompensa
    ↓
Fallimento → Rewind (Monetizzazione) → Miglioramento
    ↓
Padronanza → Orgoglio → Social Share → Nuovi Giocatori
```

### 14.2 Retention Mechanics

| Meccanica | Funzione |
|-----------|---------|
| Daily Reward di Sara ("Allineamenti Temporali") | D1-D7 reward crescenti |
| Notifiche Push ("Segnali di Distorsione") | Re-engagement |
| Battle Pass "Sette Astri" | Retention a lungo termine |
| Classifiche Globali con Skin Visibili | FOMO e competizione |
| New Game+ "Cimitero dei Glitch" | Replay infinito |

### 14.3 Curva di Apprendimento

| Livello | Meccanica Introdotta | Difficoltà |
|---------|---------------------|------------|
| 1-2 | Basi (combo, dash, switch) | Tutorial |
| 3 | Boss 1 — timing + posizionamento | Leggera |
| 4-5 | Riflessi cristallini + boss Anima | Media |
| 6-7 | Stealth + attacchi alle spalle | Media-Alta |
| 8 | Inversione comandi + boss emotivo | Alta |
| 9-10 | Gravity-flip + paradosso duale | Molto Alta |
| 11-12 | Echo loops + chaos puro | Estrema |
| 13 | Tutto contemporaneamente | Leggendaria |

### 14.4 Target Demographics

**Primary:** 18-35 anni, appassionati mobile gaming, fan anime/pixel art/dark fantasy  
**Secondary:** 14-18 anni, fan Boss Rush / soulslike semplificati  
**Tertiary:** Giocatori casual attratti dalla narrativa emotiva di Sara e Clock

### 14.5 USP (Unique Selling Points)

1. **Narrativa emotiva autentica** — Sara e Clock creano un legame reale
2. **Tempo come meccanica, non solo tema** — ogni sistema ruota attorno al tempo
3. **Monetizzazione diegetica** — gli ad fanno parte del mondo del gioco
4. **Skin che cambiano il feeling** — non cosmetici ma esperienze diverse
5. **Rigiocabilità narrativa** — il Diario cambia, gli ending cambiano, il mondo risponde

---

*"Il tempo non ti appartiene. Ma puoi combatterlo."*  
**— KRONOS FIGHT: Chronos Protocol Omega —**

---
*Documento versione 2.0 — Tutti i sistemi, personaggi, boss, livelli, skin e meccaniche sono integrati e pronti per la produzione.*
