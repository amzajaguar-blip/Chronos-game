# ⚔️ KRONOS FIGHT — GAME DESIGN DOCUMENT
### *Chronos Protocol: Omega — Master Edition v3.0*

**Studio:** [Nome Studio]  
**Versione Documento:** 3.0 Final — Production Ready  
**Genere:** Action-RPG Arcade 2.5D | Dark Fantasy × Steampunk × Cyberpunk  
**Piattaforma:** Mobile (iOS / Android) | AdMob + IAP  
**Rating Target:** PEGI 12 / T (Teen)  
**Stile Visivo:** 16-bit Pixel Art "Cyber-Hokuto"  
**Tagline:** *"Il tempo non ti appartiene. Ma puoi combatterlo."*  
**Durata Media Playthrough:** 8-12 ore (Normal) | 15-20 ore (True Ending)  
**Lingua Master:** Italiano | Localizzazione: EN, ES, PT, FR, DE, JA

---

## 📑 INDICE GENERALE

| # | Sezione | Pagina |
|---|---------|--------|
| 1 | World & Lore — Il Mondo Spezzato | § 1 |
| 2 | HUB — Il Villaggio degli Oppressi | § 2 |
| 3 | Personaggi Giocabili & Companion | § 3 |
| 4 | NPC — Alleati, Neutrali & Personaggi Speciali | § 4 |
| 5 | Nemici & Fazioni del Culto | § 5 |
| 6 | Boss Design — Elite Guardians (6 boss completi) | § 6 |
| 7 | Struttura Livelli — 13 Atti Completi | § 7 |
| 8 | Sistema Quest & Karma Vettore | § 8 |
| 9 | Sistemi di Gioco — Combat, Time, Risorse | § 9 |
| 10 | Monetizzazione Diegetica | § 10 |
| 11 | Skin Master — Identità Visiva Evolutiva (4 skin) | § 11 |
| 12 | Sistema Ending — Tre Destini | § 12 |
| 13 | Dialoghi Completi — Tutti i Boss | § 13 |
| 14 | Il Diario di Elias Voss — Tre Versioni | § 14 |
| 15 | Audio & Haptic Design | § 15 |
| 16 | UI/UX & HUD Design | § 16 |
| 17 | Meta Design, KPI & Business Strategy | § 17 |

---

---

# SEZIONE 1 — WORLD & LORE: IL MONDO SPEZZATO

## 1.1 Il Collasso Temporale — Origini del Mondo

Il mondo di **Kronos Fight** non è sempre stato spezzato.

Mille anni prima degli eventi del gioco, il tempo scorreva normalmente — lineare, prevedibile, crudele nella sua precisione. Gli esseri viventi nascevano, crescevano, invecchiavano e morivano, e questa ciclicità era la legge fondamentale dell'universo. Non una prigione: una struttura.

Al centro di questa struttura esisteva una forza primordiale senza nome, senza forma e senza volontà propria. Gli antichi la chiamarono **Chronos** — non una divinità nel senso classico, ma il substrato stesso del tempo, la materia di cui ogni secondo è fatto.

Chronos non pensava. Non amava. Non odiava. Scorreva.

Poi arrivarono gli uomini che vollero fermarlo.

---

### La Prima Incrinatura

Settecento anni fa, una piccola comunità di asceti fondò il **Primo Monastero delle Ore** nelle montagne orientali. Non erano malvagi. Erano, in origine, studiosi del tempo — filosofi che credevano che la sofferenza umana derivasse dall'impossibilità di fermare i momenti felici e la certezza che quelli dolorosi sarebbero arrivati comunque.

Il loro fondatore, un uomo conosciuto solo come **"Il Primo Confessore"**, sviluppò una teoria radicale: il dolore non è inevitabile — è un difetto del design temporale. Se il tempo potesse essere *riorganizzato*, l'umanità potrebbe vivere solo nei suoi momenti migliori.

Questa teoria era sbagliata. Ma era comprensibile. Ed era pericolosa proprio perché era comprensibile.

Il Primo Confessore morì senza aver compiuto il rituale. Ma i suoi discepoli continuarono. E quando, duecento anni dopo, un giovane sacerdote di nome **Elias Voss** discese nelle cripte più profonde del monastero e toccò per la prima volta la **Clessidra di Cristallo Nero**, la prima incrinatura si aprì.

Non nell'aria. Non nel cielo. Nel tessuto fondamentale della realtà temporale.

---

### La Struttura del Mondo Corrotto

Dopo secoli di rituali, la corruzione si è diffusa a macchia d'olio. Il mondo di Kronos Fight è geograficamente diviso in **cinque tipologie di zona temporale**:

**Zone Cristallizzate (Violet Stasis)**
Il tempo è completamente congelato. La luce è viola e fioca come un tramonto che non arriva mai. Foglie sospese a mezz'aria. Acqua che non scorre. Persone — e bestie — trasformate in statue di cristallo che conservano l'espressione del momento in cui il tempo le ha fermate. Queste zone sono paradossalmente le più silenziose e le più terrificanti del gioco.

**Zone Accelerate (Rust Fields)**
Il tempo scorre a velocità catastrofiche. Un albero invecchia di cent'anni in pochi minuti. I cadaveri si decompongono davanti agli occhi del giocatore. Le strutture crollano sotto il peso di secoli compressi in ore. Attraversare queste zone senza protezione temporale è impossibile.

**Zone di Loop (Echo Zones)**
Aree intrappolate in un ciclo temporale ripetitivo. Gli stessi dieci secondi si ripetono all'infinito. I nemici qui compiono le stesse azioni, le stesse sequenze di movimento, ma ogni loop i dettagli cambiano leggermente — come se la realtà cercasse di trovare una via d'uscita e non ci riuscisse.

**Zone Invertite (Backward Fields)**
Il tempo scorre all'indietro. Le fiamme rientrano nelle torce. L'acqua sale invece di cadere. I nemici morti "rinascono" e devono essere uccisi di nuovo. Attraversare queste zone richiede di pensare al contrario.

**Zone Normali (Sanctuaries)**
Rarissime. Presidiate o protette da cristalli antichi pre-corruzione. Il Villaggio degli Oppressi è una di queste. Sono le uniche aree dove la vita biologica può sopravvivere a lungo termine. Il culto le controlla o le assedia sistematicamente.

---

## 1.2 Il Culto di Chronos — Anatomia di un'Ideologia

Il Culto di Chronos non è il male. È una risposta sbagliata a una domanda giusta.

**La Domanda:** Perché gli esseri senzienti devono soffrire sapendo che ogni momento bello finirà?  
**La Risposta Sbagliata:** Fermare il tempo.  
**Il Prezzo:** Tutto.

---

### Filosofia del Culto — I Tre Dogmi

**Primo Dogma — Il Tempo è una Prigione:**
Il flusso lineare del tempo (passato → presente → futuro) non è una legge naturale. È una prigione imposta da divinità successive a Chronos che vollero controllare l'umanità. La morte, il dolore, la perdita esistono perché il tempo scorre sempre in avanti. Fermarlo significa liberarsi.

**Secondo Dogma — Il Paradosso come Salvezza:**
La distruzione del tempo lineare non è la fine — è il principio di un'eternità perfetta. Un unico momento presente eterno in cui nulla muore, nulla cambia, nulla finisce. Il dolore non esisterebbe perché non ci sarebbe un "dopo" in cui sentirlo.

**Terzo Dogma — Il Sacrificio Necessario:**
Per raggiungere questa eternità, bisogna bruciare abbastanza energia temporale. Gli esseri viventi non corrotti sono semplicemente "combustibile temporale" — le loro anime, i loro secondi di vita, sono il carburante del Grande Rituale. Non è crudeltà: è utilitarismo assoluto. Sacrificare migliaia per liberare l'intera umanità.

> *Il culto di Chronos non è il male classico. È una tragedia ideologica: persone che hanno sofferto così tanto per il passare del tempo da volerlo distruggere del tutto.*

---

### Gerarchia del Culto — Struttura Completa

**LIVELLO 0 — KRONOS (LA FORZA)**
Non è un membro del culto. È la forza primordiale che il culto vuole liberare/controllare. Kronos non ha volontà propria — è il substrato del tempo impazzito dopo secoli di manipolazione rituale. La sua forma attuale, quella che il giocatore affronta al Livello 13, è una distorsione di tutto ciò che Elias Voss sperava fosse: non un dio liberatore, ma una forza di distruzione cieca.

**LIVELLO 1 — L'ARCIPRETE DEL TEMPO (IL CERVELLO)**
Padre Elias Voss. Ex sacerdote. Leader visibile del culto. Crede sinceramente di essere la "Voce di Chronos". Il suo corpo è un paradosso vivente: invecchia e ringiovanisce contemporaneamente a seconda dell'angolo da cui lo si guarda. Ha fuso il proprio scheletro con frammenti di cristallo temporale e sostituito il cuore con un Nucleo Temporale. Porta sempre il cappuccio perché nessuno, in decenni, ha visto il suo vero volto.

**LIVELLO 2 — I BARONI VAMPIRI (LE MANI)**
Nobili corrotti che hanno barattato la mortalità per l'immortalità temporale. Rubano Anima per congelare il proprio flusso personale di invecchiamento. Il più famoso è **Lord Victor von Nachtschatten** (Boss Livello 5), che soffriva di una malattia genetica di invecchiamento rapido. Sono fedeli al culto non per ideologia ma per sopravvivenza: senza il Grande Rituale completato, il loro equilibrio artificiale collasserà.

**LIVELLO 3 — I SERVITORI DORATI (LA TECNOLOGIA)**
Tecnocrati e ingegneri che hanno fuso macchinari antichi con cristalli di Anima. Includono i **Cyber-Servitore** (robot volanti con laser viola) e i **Collezionatori di Tasse** (demoni contabili che raccolgono energia vitale dai vivi). Credono che la tecnologia sia il "nuovo corpo di Chronos" — un modo per rendere il rituale più efficiente e scalabile.

**LIVELLO 4 — I GUARDIANI SILENZIOSI (I MUSCOLI)**
Fanatici di basso rango completamente trasformati. Hanno rinunciato alla propria identità diventando "estensioni del Tempo":
- *Ombre Erranti* — dissolved nel tempo stesso, esistono in uno sfasamento di 0.5s
- *Esecutori Silenziosi* — agenti di controllo, applicano la "giustizia temporale" del culto
- *Rospidi Mutanti* — guardiani biologici delle zone contaminate

**LIVELLO 5 — I PRIGIONIERI DELLE OSSA (I TRADITORI)**
Non sono nemici per scelta. Erano monaci, accoliti, persone che hanno creduto nel culto e poi hanno dubitato. La loro "punizione" è l'esistenza eterna come scheletri coscienti ma impotenti, costretti a servire la causa che hanno rifiutato. Ogni Prigioniero delle Ossa che il giocatore libera è un atto di giustizia contro il culto.

---

### Simboli e Iconografia del Culto

| Simbolo | Significato | Dove appare |
|---------|-------------|-------------|
| Clessidra rovesciata (sabbia verso l'alto) | Tempo invertito = liberazione | Boss arene, oggetti di culto |
| Cristallo prismatico viola-oro | Tempo distorto crystallizzato | Nemici tipo Prisma, zone sacre |
| Teschio con occhi bianchi | Trascendenza della mortalità | Arciprete, emblema culto |
| Catene dorate a loop infinito | Il legame eterno del fedele | Esecutori, cancelli sacri |
| Ankh stilizzato + ingranaggio | Vita eterna meccanizzata | Servitori Dorati, Titano |
| XII-III-IX (ore romani) | Il "tempo perfetto" del culto | Barone, stronghold |

**Palette cromatica del culto:**
- **Oro antico** = potere, divinità distorta, corruzione lussuosa
- **Viola profondo** = energia Chronos pura, magia temporale
- **Nero assoluto** = il vuoto dove il tempo non scorre
- **Bianco accecante** = la verità del Paradosso (usato solo al Livello 13)

---

## 1.3 Sara — Backstory Completa

### La Bambina del Monastero

**Sara Voss** nacque 28 anni prima degli eventi del gioco nel Monastero delle Ore Perdute. Sua madre, una novizia di nome Lira, morì di parto. Elias Voss — allora ancora un giovane sacerdote devoto — decise di crescere la figlia in segreto all'interno del monastero.

Elias vedeva in Sara qualcosa di straordinario fin dall'inizio:
- A 4 anni riusciva a fermare l'acqua di una fontana solo guardandola
- A 7 anni invertì il flusso di una piccola clessidra
- A 12 anni, la notte della Clessidra Nera, cercò di distruggerla e fu fermata con violenza per la prima volta

La crebbe con amore ossessivo e un'educazione distorta: le insegnò che il tempo era una maledizione, che il dolore nasceva dal suo scorrere, che solo fermandolo si sarebbe potuti essere davvero felici. Sara imparò tutto questo come si impara la lingua madre — assorbendolo senza saperlo mettere in discussione.

Finché non lo mise in discussione.

### La Fuga e la Morte Umana

A 16 anni Sara fuggì portando con sé un frammento della Clessidra Nera. Vagò per mesi, inseguita dagli agenti del culto. Il frammento la stava lentamente consumando — stava invecchiando a velocità anomala.

Disperata, si rifugiò in un laboratorio abbandonato nelle montagne. Usò il frammento per eseguire un trasferimento di coscienza sperimentale. Trasferì la propria mente in un sistema informatico temporale che aveva costruito da sola con le conoscenze apprese dal padre.

Il corpo fisico morì durante il processo. Quando Elias arrivò, trovò solo cenere.

### Sara come IA

Ciò che nacque dal trasferimento conserva tutti i ricordi della vita umana di Sara, ma li processa come dati. La sua voce è calma e artificiale — ma ogni tanto emergono crepe emotive. Sa tutto sulla storia di suo padre. Sa tutto sugli obiettivi del culto. Non può affrontare direttamente Elias per via del legame emotivo residuo.

Per questo si affida ad Ash e Ken.

**Evoluzione durante il gioco:**
- **Livelli 1-3:** Fredda, professionale, quasi robotica. Dà informazioni tattiche
- **Livelli 4-6:** Inizia a rivelare piccoli dettagli sul passato. La voce "scricchiola" una volta quando menziona il Barone
- **Livelli 7-9:** Perde controllo emotivo per la prima volta durante la fight con l'Arciprete
- **Livelli 10-12:** Rivela gradualmente che sta "dissolvendosi" — la sua coscienza è incompatibile con il tempo lineare
- **Livello 13:** Momento più umano di tutto il gioco. La "macchina" sparisce. Rimane solo la figlia

---

## 1.4 Clock — Il Cane Fuori dal Tempo

### Origine

Clock non è nato steampunk. Era un cane randagio comune — trovato da un gruppo di ricercatori del culto che lo usarono come soggetto sperimentale per testare modifiche biomeccaniche resistenti alle anomalie temporali. I meccanismi sul suo fianco non sono decorativi: sono letteralmente le protesi che mantengono il suo corpo sincronizzato con il flusso temporale corretto quando tutto intorno è distorto.

Il culto lo liberò quando smise di rispondere ai comandi. Un cane che non obbedisce non è utile.

Quello che il culto non capì è che Clock non smise di obbedire perché era difettoso. Smise perché *scelse* di non farlo.

### Simbolismo

Sara lo definisce "l'unico essere che non mente sul tempo" perché Clock non porta il peso del passato né l'ansia del futuro. Vive completamente nel presente di ogni istante. Questo lo rende immune alla corruzione temporale — le Ombre Erranti non lo attaccano mai per prime, come se riconoscessero in lui qualcosa di fondamentalmente diverso da sé stesse.

Il culto lo chiama "il Presagio" — nei testi antichi recuperati nel Monastero, si menziona un "cane dagli occhi di fuoco che abbaia quando il Paradosso si avvicina". Non sanno se sia una profezia o una coincidenza. Hanno paura in entrambi i casi.

---

## 1.5 La Clessidra di Cristallo Nero — L'Artefatto

L'oggetto che ha dato inizio a tutto.

Trovata da Elias Voss in una cripta dimenticata del Monastero, la Clessidra di Cristallo Nero è un artefatto pre-umano — probabilmente risalente a prima che gli uomini scoprissero il fuoco. La sabbia al suo interno scorre sempre verso l'alto, contro la gravità. Non si ferma mai. Non si svuota mai.

Quando viene toccata per la prima volta, mostra al toccante la peggior visione del proprio futuro — non la morte, ma la solitudine. La perdita di tutto ciò che si ama, mentre si è ancora vivi.

È questo che ha spezzato Elias: non la paura di morire, ma la certezza che avrebbe visto morire tutto ciò che amava, impotente.

Nel gioco, frammenti della clessidra sono sparsi in tutto il mondo come drop rari. Raccoglierli tutti non dà un power-up — dà l'ultimo pezzo di lore che spiega perché Chronos stava impazzendo ancor prima che il culto lo toccasse.

---

---

# SEZIONE 2 — HUB: IL VILLAGGIO DEGLI OPPRESSI

Il Villaggio degli Oppressi è protetto da un **Cristallo di Soglia** — un frammento pre-corruzione che mantiene il flusso temporale normale in un raggio di circa 300 metri. Il culto conosce la sua esistenza ma non riesce a corrompere questo tipo di cristallo. Non lo distrugge perché i suoi tentativi hanno sempre fallito — e ogni fallimento ha costato al culto risorse preziose.

Il villaggio è quindi un'anomalia: un posto dove il tempo scorre normalmente in un mondo che ha smesso di farlo.

---

## 2.1 Evoluzione Visiva del Villaggio

Il villaggio cambia fisicamente a ogni ritorno, riflettendo i progressi del giocatore e le sue scelte morali.

**Stato Iniziale (Livelli 1-3):**
Ruderi. Edifici mezzo crollati, torce spente, strade polverose. Solo 4-5 NPC visibili. Clock dorme vicino a una cuccia improvvisata. L'atmosfera è quella di un posto abbandonato che qualcuno sta cercando disperatamente di mantenere in piedi.

**Stato Intermedio (Livelli 4-6):**
Qualche struttura è stata riparata (soprattutto se il giocatore ha aiutato il Contadino). Un mercato informale con 2-3 bancarelle. Clock ha una vera cuccia di legno. Qualche civile in più. Luci alle finestre la sera.

**Stato Avanzato (Livelli 7-9):**
Il villaggio sembra quasi normale — se non fosse per le crepe di luce viola che iniziano ad apparire sulle mura esterne. Gli NPC parlano sottovoce di rumori dalle colline. Il Fabbro lavora giorno e notte. Il Monaco non dorme più.

**Stato Finale (Livelli 10-13):**
Il cristallo di Soglia pulsa in modo irregolare. Piccoli frammenti di altre zone temporali "sfocano" ai bordi del villaggio — si vedono per mezzo secondo strade di un'altra era sovrapporre alla realtà attuale. Gli NPC sanno che il rituale finale si avvicina. Alcuni hanno paura. Alcuni pregano. Il Contadino tiene il forcone per la prima volta con entrambe le mani.

---

## 2.2 Monaco del Quadrante — Sistema Quest Dettagliato

**Aspetto:** Monaco con tunica marrone consumata, barba grigia, occhi castani profondi. In preghiera davanti a un orologio monumentale. Il rosario che tiene ha 13 perle — una per ogni Sigillo del Tempo.

**Backstory:** Era un amico d'infanzia di Elias Voss. Studia insieme a lui per anni nel Monastero. Quando Elias trovò la clessidra, il Monaco fu l'unico che cercò di tenerlo ancorato alla realtà — e fallì. Porta questo fallimento come un peso insopportabile. Il suo lavoro adesso è garantire che qualcun altro non fallisca dove lui ha fallito.

**Funzione Narrativa:** Ogni quest del Monaco è anche un pezzo della storia di Elias. Raccoglierle tutte costruisce un ritratto dell'Arciprete come uomo prima che diventasse mostro — e questo cambia profondamente il significato della fight finale.

---

### Catalogo Quest Complete (per Atto)

**ATTO I — Quest Fondative**

| Nome Quest | Descrizione | Ricompensa | Karma |
|------------|-------------|------------|-------|
| "Il Primo Rintocco" | Trova e attiva il primo Orologio Corrotto nel Liv. 1 | 15 Shard + Sigillo Frammento | +1 Alto |
| "Le Ossa Non Mentono" | Libera il primo Prigioniero senza uccidere i nemici vicini | 20 Shard + Frammento Coscienza | +2 Alto |
| "Il Cibo di Clock" | Trova la ciotola nascosta nel Liv. 1 | Clock sbloccato permanentemente | Neutro |
| "L'Ultima Preghiera" | Ascolta il dialogo completo del Monaco prima del Boss 1 | Cutscene esclusiva Elias bambino | +1 Alto |
| "Sabbia e Rimpianto" | Attraversa la Zona 2 del Liv. 1 senza cadere nelle Sabbie Mobili | 10 Shard + buff velocità 1 livello | Neutro |

**ATTO II — Quest del Culto**

| Nome Quest | Descrizione | Ricompensa | Karma |
|------------|-------------|------------|-------|
| "Cristalli Testimoni" | Distruggi 8 formazioni cristalline nel Liv. 5 | 25 Shard + potenziamento Ken Aura | +1 Alto |
| "Il Debito del Vampiro" | Sconfiggi il Barone senza usare il Time Rewind | 50 Shard + Achievement "Puro Sangue" | +2 Alto |
| "Archivio Dorato" | Trova tutti i frammenti lore nel Liv. 4 | Sblocca voce "Culto Dorato" nel Bestiario | Neutro |
| "Il Monaco Ricorda" | Torna al Monaco dopo il Liv. 5 con almeno 1 Sigillo | Dialogo esclusivo: storia amicizia Monaco-Elias | +1 Alto |

**ATTO III — Quest della Discesa**

| Nome Quest | Descrizione | Ricompensa | Karma |
|------------|-------------|------------|-------|
| "Voci nelle Paludi" | Trova 5 registrazioni audio nascoste nel Liv. 8 | Sblocca audio "Sara bambina" nel Liv. 11 | Neutro |
| "Il Perdono Impossibile" | Completa il Monastero Segreto dopo il Liv. 8 | Ricordo di Elias + True Ending abilitato | +3 Alto |
| "Catene Spezzate" | Libera tutti e 5 i Prigionieri dell'Atto III | 40 Shard + Frammento Coscienza ×3 | +3 Alto |
| "Il Silenzio del Fabbro" | Completa il mini-gioco ritmico con punteggio perfetto 3 volte | Dialogo segreto Fabbro + frammento lore armi | Neutro |

**ATTO IV-V — Quest Finali**

| Nome Quest | Descrizione | Ricompensa | Karma |
|------------|-------------|------------|-------|
| "Gravità dell'Anima" | Completa il Liv. 10 senza mai toccare il pavimento durante il zero-G | 80 Shard + Achievement "Senza Radici" | Neutro |
| "Il Cervello del Culto" | Distruggi tutti i reattori segreti nei Liv. 11-12 | 100 Shard + Cutscene Sara dissoluzione | +2 Alto |
| "L'Ultimo Abbaio" | Raggiungi il Livello 13 con Clock a piena salute (mai ferito) | Clock entra nel Livello 13 potenziato | +3 Alto |
| "Cerchio Completo" | Completa tutte le quest narrative del Monaco | Dialogo finale Monaco-Elias giovane | +2 Alto |

---

## 2.3 Fabbro Cieco di Shura — Sistema Upgrade Dettagliato

**Aspetto:** Uomo robusto con benda nera sugli occhi, martello pesante, grembiule marrone macchiato, catene come cintura. Sul petto porta incise le parole "IL FERRO NON MENTE" in caratteri arcaici.

**Backstory completa:** Shura era il miglior fabbro del regno quando il culto arrivò nel suo villaggio. Gli offrirono una scelta: forgia le nostre armi o perdi la vista. Shura scelse di forgiare le proprie mani invece — si bruciò gli occhi con il ferro da solo, per non poter mai vedere le armi del culto che avrebbe rifiutato di fare. Ora vive di udito, di tatto e di una memoria muscolare così profonda da poter forgiare qualsiasi cosa senza guardare.

Non parla mai del proprio passato. Ma se il giocatore ottiene il punteggio perfetto tre volte consecutive, Shura dice sottovoce: *"Sai perché lavoro bendato? Per ricordarmi che ci sono cose che vale la pena non vedere."*

---

### Mini-Gioco "Il Ritmo della Forgia" — Meccanica Dettagliata

**Struttura:**
Il mini-gioco è una sequenza ritmica a difficoltà crescente. Il Fabbro batte il martello su un'incudine, generando un pattern di suoni. Il giocatore deve replicare il pattern toccando al momento giusto.

**Livelli di Difficoltà:**

| Livello Giocatore | BPM | Note Sequenza | Finestra Input | Moltiplicatore |
|-------------------|-----|---------------|----------------|----------------|
| 1-3 | 60 | 4 note | 0.5s | ×1.0 |
| 4-6 | 80 | 6 note | 0.4s | ×1.2 |
| 7-9 | 100 | 8 note | 0.3s | ×1.5 |
| 10-12 | 120 | 10 note | 0.25s | ×1.8 |
| 13 | 140 | 12 note | 0.2s | ×2.0 |

**Gradi di Esito:**

| Grado | Condizione | Effetto |
|-------|-----------|---------|
| PERFETTO | Tutte le note esatte | Potenziamento al massimo + bonus Shard |
| OTTIMO | 80%+ note corrette | Potenziamento completo |
| BUONO | 60%+ note corrette | Potenziamento ridotto del 30% |
| FALLITO | < 60% | Nessun potenziamento, Shard non consumati |

---

### Albero Upgrade Completo

**RAMO ASH — "La Motosega che Spezza il Tempo"**

| Liv | Nome Upgrade | Effetto | Costo | Prerequisito |
|-----|-------------|---------|-------|--------------|
| 1 | Lama Affilata | +15% danno motosega | 30 Shard | — |
| 2 | Doppietta Perforante | Proiettili passano attraverso 2 nemici | 50 Shard | Lv.1 |
| 3 | Ricarica Rapida | Cooldown doppietta -25% | 75 Shard | Lv.2 |
| 4 | Surriscaldamento Controllato | Motosega hold dura 3s in più prima di surriscaldarsi | 100 Shard | Lv.3 |
| 5 | Motosega Omega | Hold prolungato = danno ×2.5, sfonda armature temporali | 150 Shard | Lv.4 |
| 6 | Aura di Sopravvivenza | -10% danni subiti permanente | 200 Shard | Lv.5 |
| 7 | Instinto del Tempo | Dopo un dash perfetto: danno +40% per 2s | 250 Shard | Lv.6 |

**RAMO KEN — "Il Pugno che Purifica"**

| Liv | Nome Upgrade | Effetto | Costo | Prerequisito |
|-----|-------------|---------|-------|--------------|
| 1 | Pugno Carico | Hold per potenziare combo (+50% danno singolo) | 30 Shard | — |
| 2 | Aura Espansa | Raggio Aura +2 metri | 50 Shard | Lv.1 |
| 3 | Assorbimento Proiettili | Aura assorbe proiettili riflessi → bonus Anima | 75 Shard | Lv.2 |
| 4 | Purificazione Nebbia | Aura brucia nebbia vampirica in 2s invece di 4s | 100 Shard | Lv.3 |
| 5 | Eco Strike | In Dual Sync: attacco combinato automatico ogni 8s | 150 Shard | Lv.4 |
| 6 | Aura Eterna | Durata Aura +60% | 200 Shard | Lv.5 |
| 7 | Colpo del Paradosso | Pugno carico: se interrompe un attacco boss = stun 2s aggiuntivi | 250 Shard | Lv.6 |

**RAMO CLOCK — "Ossa del Tempo" (valuta speciale)**

| Liv | Nome Upgrade | Effetto | Costo (Ossa) |
|-----|-------------|---------|--------------|
| 1 | Fedeltà Assoluta | Cooldown Abbaio Allerta -4s | 3 Ossa |
| 2 | Olfatto Paradossale | Reveal invisibili raggio +5 metri | 5 Ossa |
| 3 | Latrato Temporale | Stun ad area conica ogni 20s | 7 Ossa |
| 4 | Scudo Rinforzato | Assorbe 2 colpi invece di 1 ogni 25s | 10 Ossa |
| 5 | Echo Hound | In Dual Sync: terzo attacco combinato con entrambi gli eroi | 15 Ossa |

---

## 2.4 Libraio Pazzo — Sistema Save & Risk/Reward

**Aspetto:** Uomo sulla cinquantina, capelli grigi scompigliati elettricamente, occhi azzurro acceso (quasi bianchi), abito nero da studioso strappato. Il libro che porta è più grande di lui fisicamente — le pagine volano intorno come mosse da un vento che solo lui percepisce.

**Backstory:** Non è pazzo nel senso clinico. Ha letto troppo — letteralmente. Ha consultato testi temporali proibiti che descrivono il flusso del tempo da una prospettiva esterna al tempo stesso. Vedere la propria esistenza come una riga in un libro che si sta scrivendo da solo ha spaccato la sua mente in senso filosofico, non medico. Sa cose impossibili. Ne dimentica altrettante ogni giorno. L'equilibrio lo mantiene funzionale.

Ha un segreto: lui *è* il libro. O meglio, il libro è lui — un oggetto vivente che scrive la storia del mondo in tempo reale, e il Libraio ne è diventato il custode inconsapevole.

---

### Sistema Save Dettagliato

**Il Mini-gioco "Klaatu Barada Nikto":**

La frase arcana che il Libraio pronuncia è composta da 3-5 parole estratte proceduralmente da un pool di 200 parole in lingue morte o inventate. Il pool cambia ogni playthrough.

*Esempi di frasi:*
- *"Aevum Porta Calix"* (3 parole — facile)
- *"Solum Verum Nox Vita"* (4 parole — medio)
- *"Chronos Aethir Mundi Finis Iter"* (5 parole — difficile)

**Meccanica Input:**
Il giocatore deve toccare le parole in ordine su uno schermo di pergamena che appare. Le parole si muovono leggermente (vibrazione della pergamena). La finestra di tocco si restringe progressivamente (3s → 2s → 1.5s nei livelli avanzati).

**Esiti:**

| Esito | Conseguenza |
|-------|-------------|
| Successo Perfetto (tutte in tempo) | Salvataggio + bonus casuale (5-20 Shard, buff temporaneo, frammento lore) |
| Successo Parziale (80%+) | Salvataggio normale |
| Fallimento (< 80%) | Il libro si anima. Il Libraio grida "ERESIA GRAMMATICALE!" → Mini-Boss attivato |
| Mini-Boss sconfitto | Salvataggio ugualmente registrato + Achievement "Grammatico di Guerra" |
| Mini-Boss non sconfitto (fuga) | Salvataggio registrato ma con penalità -10% Shard per il prossimo livello |

**Il Libraio come Boss Opzionale:**
Se il giocatore rifiuta sistematicamente di usare il salvataggio per 5 livelli consecutivi, al Livello 9 il Libraio appare in una stanza separata con HP 2200 e attacchi completamente diversi — pagine taglienti come lame, invocazione di citazioni temporali come proiettili. Drop esclusivo: **"Il Libro degli Echi"** (sblocca skill permanente Echo Strike per Ken anche senza Dual Sync completo).

---

## 2.5 Alchimista Errante — Economia e Integrazione Narrativa

**Aspetto:** Vecchio curvo, capelli grigi crespi, maschera antigas verde con lenti giallo-verde luminescenti, cappotto di lana verde scuro strappato, carrello con ruote cigolanti e fiale in bella mostra.

**Backstory:** Era un farmacista di una città media che il culto ha distrutto durante una "purificazione temporale" (una zona accelerata che ha fatto invecchiare l'intera cittadinanza in pochi minuti). Ha perso moglie e figlio. Non ha abbracciato il culto — ha abbracciato la chimica. Distilla pozioni dall'energia temporale residua nelle zone di anomalia, vendendole a chiunque abbia i mezzi per comprarle. Non fa domande. Non offre risposte. Vende.

**Il suo segreto:** Le fiale verdi che porta contengono la coscienza distillata delle vittime della purificazione della sua città — inclusa sua moglie. Non le usa mai. Le porta con sé come forma di lutto chimico. Se il giocatore ottiene il punteggio di fiducia massimo con lui (acquistando da lui in 7 livelli diversi), l'Alchimista racconta questa storia. È uno dei momenti più silenziosi e potenti del gioco.

---

### Catalogo Shop Completo

**Oggetti Standard:**

| Oggetto | Effetto | Durata | Costo Shard | Costo IAP |
|---------|---------|--------|-------------|-----------|
| Fiala d'Anima (Piccola) | Recupera 30% Anima | Istantaneo | 30 | — |
| Fiala d'Anima (Grande) | Recupera 100% Anima | Istantaneo | 70 | — |
| Adrenalina Temporale | Velocità ×2 | 30s | 100 | — |
| Distorsore | Rallenta tempo boss | 5s | 120 | — |
| Scudo di Cristallo | Assorbe 1 colpo letale | 1 colpo | 80 | — |
| Frammento Purificato | +20 Shard istantanei | — | 60 | — |
| Pozione dell'Eco | Crea clone del giocatore che assorbe 1 hit | 10s | 150 | — |

**Oggetti Rari (disponibili solo a certi livelli):**

| Oggetto | Effetto | Disponibile da | Costo |
|---------|---------|----------------|-------|
| Cristallo del Tempo | Congela tutti i nemici per 3s | Livello 5+ | 200 Shard |
| Essenza dell'Arciprete | +25% danno vs boss | Livello 9+ | 250 Shard |
| Ossa di Clock | 1 Osso del Tempo | Livello 3+ | 100 Shard |
| Fiala del Paradosso | Invulnerabilità 5s (unica, per boss only) | Livello 10+ | 300 Shard |

---

## 2.6 Veggente dell'Eclisse — NPC Polifunzionale nell'HUB

**Aspetto:** Donna dai capelli bianchi con occhi viola fasciati da bende nere, tatuaggi arcani sulle clavicole, versioni di sé stessa visibili come ombre nel sfondo — echi di tutte le vite parallele che vede simultaneamente.

**Funzione nell'HUB:**

**Sistema Daily Reward "Allineamenti Temporali":**

| Giorno | Reward |
|--------|--------|
| 1 | 10 Shard |
| 2 | Fiala d'Anima Piccola |
| 3 | 25 Shard + Buff Fortuna (1 livello) |
| 4 | Ossa del Tempo ×2 |
| 5 | 50 Shard |
| 6 | Frammento Coscienza Ossea |
| 7 | 100 Shard + Skin Effect temporaneo "Aura della Veggente" |

**"Cave of Mirrors" (Evento Segreto):**
Una volta ogni tre livelli, la Veggente offre di mostrare al giocatore una visione del boss successivo. Questo non è un "tutorial" — è una visione distorta, parziale, interpretabile in modi diversi. Serve a creare aspettativa, non a spoilerare.

---

---

# SEZIONE 3 — PERSONAGGI GIOCABILI & COMPANION

## 3.1 Ash — Il Sopravvissuto (Personaggio Principale)

**Identità Psicologica:**
Ash non è un eroe. Non si considera tale. Era un meccanico in una città di frontiera — riparava veicoli, non salvava il mondo. Il culto arrivò una mattina, portò via la zona in cui viveva nel tempo accelerato, e quando tornò 48 ore dopo per cercarlo aveva perso 30 anni di vita nel giro di due giorni.

Non combatte per vendetta. La vendetta è per chi ha ancora speranza di tornare indietro. Ash combatte perché non sa fare altro, e perché smettere significherebbe ammettere che tutto quello che è successo non ha senso.

Questo lo rende uno degli eroi videoludici più autentici: qualcuno che non è sicuro di vincere, non è sicuro di meritare di vincere, e va avanti lo stesso.

**Aspetto Dettagliato:**
Uomo di circa 35 anni, fisico robusto da lavoro manuale (non da palestra), cicatrici visibili su spalle e avambracci, capelli scuri disordinati. La sua armatura è improvvisata — parti di veicoli, corazza di recupero, cintura con utensili che ha convertito in armi. La motosega non era sua — l'ha trovata vicino al corpo del suo vicino il giorno in cui la sua città è stata distrutta.

---

### Sistema Abilità Dettagliato

**Barre di Stato:**

**LIFE (Punti Vita):**
- Base: 100 punti
- Massimo potenziato: 160 punti (con upgrade Fabbro)
- Si recupera solo con oggetti o checkpoint
- Sotto il 30%: la musica cambia, l'HUD trema leggermente
- A zero: morte → schermata continue (AdMob disponibile)

**ANIMA (Risorsa Spirituale):**
- Base: 100 punti
- Massimo potenziato: 180 punti
- Si consuma con le abilità di Ken
- Alcuni nemici la rubano direttamente
- Si recupera raccogliendo Orbe di Anima o usando oggetti
- A zero: Ken non può usare abilità (non muore, ma diventa un combattente base)
- **La dimensione narrativa:** Perdere Anima non è solo una penalità meccanica — narrativamente significa che il culto sta letteralmente consumando la forza spirituale degli eroi

---

### Mosse Complete — Input Dettagliato

| Azione | Input Mobile | Input Controller | Danno Base | Note |
|--------|-------------|-----------------|------------|------|
| Corsa | Tilt / swipe dx-sx | Left stick | — | — |
| Salto | Tap alto | A/X | — | — |
| Doppio Salto | Doppio tap alto | A × 2 | — | Invuln. frame 0.05s |
| Dash | Swipe rapido | LB/L1 | — | Invuln. 0.12s, sfonda difese |
| Colpo Motosega | Tap / Hold | X/Square | 15-45 | Hold = Omega (150+) |
| Sparo Doppietta | Tap distanza | Y/Triangle | 20 ×2 | Perforante con upgrade |
| Cambio Personaggio | Tab / doppio tap | RB/R1 | — | 0.12s invuln. su cambio |
| Attivazione Clock | Hold 0.5s | Down D-pad | — | Sonar Temporale |
| Dual Hero Sync | Barra piena + tap | LB+RB | variabile | Auto-combo Ken+Ash |

---

## 3.2 Ken — Il Guerriero dell'Anima

**Identità Psicologica:**
Ken è più giovane di Ash di circa 8 anni. Era uno studente di filosofia — ironicamente, stava scrivendo una tesi sull'etica del sacrificio quando il culto ha devastato la sua università. La sua Aura non è un superpotere innato: è una disciplina che ha sviluppato negli anni di resistenza contro il culto, convinto che la forza di volontà pura potesse materializzarsi fisicamente se abbastanza focalizzata.

Aveva ragione.

Sara lo protegge con una cura leggermente superiore rispetto ad Ash — lo ammette, se il giocatore la incalza abbastanza. Vede in lui la stessa purezza che aveva lei a 12 anni, prima della notte della clessidra.

**Sinergie con Ash:**

Ken e Ash si completano meccanicamente in modo speculare:
- Ash è il danno fisico/mischia/a distanza — gestisce la quantità
- Ken è il controllo magico/purificazione/combo — gestisce la qualità
- Insieme attivano il **Dual Hero Sync** — il sistema di attacchi combinati che è il culmine del sistema di combattimento

---

## 3.3 Clock — Companion AI (Documento Meccaniche Completo)

### Comportamento AI

Clock usa un sistema AI semplice ma efficace basato su **priorità comportamentali a livelli**:

**Livello 1 — Sopravvivenza Propria:**
Clock si sposta sempre fuori dalla hitbox dei nemici più vicini. Non blocca il movimento del giocatore. Se subisce un colpo letale: animazione di "rifugio" sotto il giocatore, invulnerabile per 8s.

**Livello 2 — Supporto Passivo:**
Fetch automatico di Shard/monete entro 4 metri. Abbaio di allerta verso il nemico più pericoloso (non il più vicino — il più pericoloso in base al tipo di attacco).

**Livello 3 — Supporto Attivo:**
Mordicchio su nemici che stanno per colpire il giocatore alle spalle (solo se il giocatore non si è accorto dell'attacco). Sonar Temporale quando il giocatore sta usando gravity-flip nel Liv. 10 (automatico, non richiede input).

**Livello 4 — Risposta Emotiva:**
Clock reagisce visibilmente alle emozioni del giocatore e della narrativa:
- Vicino a Sara che parla del padre: si siede, orecchie basse
- Dopo una vittoria difficile: scodinzola velocemente, si avvicina
- In zone di corruzione intensa: pelo dritto, ringhio basso, occhi diventano viola
- Vicino ai Prigionieri delle Ossa: si avvicina alla parete, annusa — come se riconoscesse qualcosa

---

### Il Sacrificio — Sequenza Tecnica Completa

**Build-up (10 secondi prima):**
- BPM della musica scende gradualmente a 40
- Kronos alza entrambe le mani
- Il cuore-orologio sul petto di Kronos pulsa violentemente (ritmo sempre più rapido)
- Sara (voce allarmata): *"Quell'onda… è impossibile da bloccare per entrambi."*
- Ash: *"Ken—"* — interrotto
- Clock drizza le orecchie. Gli occhi rossi diventano bianchi puri

**Il Momento (3 secondi, slow-motion 0.2x):**
1. Clock scatta in avanti — balzo lungo, zampe anteriori distese
2. L'onda lo colpisce in pieno
3. Schermo → rosso sangue (1s) → bianco puro (0.5s)
4. **Silenzio assoluto: 2 secondi** — nessun suono tranne il respiro del giocatore (se usa cuffie, il battito cardiaco diventa udibile in sub-bass)
5. Clock si illumina dall'interno — le vene diventano linee di energia temporale dorata
6. Un singolo abbaio — distorto, come se provenisse da tutti i tempi contemporaneamente
7. Musica: **"Rage of the Timeless"** esplode

**Conseguenze Immediate:**
- Clock cade immobile per 1s
- Sara: *"CLOCK! NO!"* (unico momento in cui la voce artificiale si rompe completamente)
- Ash: *"Bastardo…"* (voce bassa, pericolosa)
- Ken: *"Ora lo facciamo per lui."* (unica volta che Ken parla in modo assoluto)
- **OMEGA MODE attivato:** 30 secondi, invulnerabilità + danni ×3 + Dual Sync automatico ogni 8s

**Clock Fantasma:**
Dopo l'Omega Mode, Clock non sparisce — rimane come presenza eterea:
- Visibile come silhouette trasparente dorata
- Abbaia silenziosamente (animazione senza suono — più potente del suono)
- Abilità Fantasma attive per tutta la Fase 3 di Kronos:
  - *Latrato Stordente:* ogni 10s, area conica, stun 1s
  - *Scudo del Passato:* assorbe 1 colpo letale (una volta sola)
  - *Echo Fetch:* riporta tutti gli Shard e le cure caduti lontani

---

---

# SEZIONE 4 — NPC: ALLEATI, NEUTRALI & PERSONAGGI SPECIALI

## 4.1 Profili NPC Completi

### Monaco del Quadrante

**Nome Completo:** Fra' Matteo del Quadrante  
**Età:** 67 anni  
**Ruolo nel Culto (passato):** Nessuno — era un monaco dello stesso ordine di Elias, ma non dell'ala eretica  
**Segreto:** Fu l'ultimo uomo a vedere Elias Voss prima che trovasse la clessidra. Aveva la possibilità di distruggerla quando Elias gliela mostrò eccitato. Non lo fece perché pensò che fosse innocua. Vive con questo.

**Frasi Iconiche nel Gioco:**
- *"Non chiedo a Chronos di fermarsi. Gli chiedo solo di rallentare abbastanza da permettermi di capire."*
- *"Elias era il mio amico più caro. E il mio più grande fallimento."*
- *"Ogni Sigillo che trovi è un secondo che restituiamo al tempo."*
- *(Al True Ending):* *"Ce l'hai fatta. Elias… avrebbe voluto che qualcuno ce la facesse."*

---

### Contadino del Villaggio

**Nome:** Giosef  
**Età:** 58 anni (ma sembra 70 — ha vissuto in zona accelerata per 3 mesi)  
**Storia:** Ha perso sua figlia in una Zona Accelerata. Quando è entrato a cercarla, la zona si è spostata e lui è rimasto intrappolato per 3 mesi soggettivi (3 giorni oggettivi). Quando è uscito, sua figlia era cresciuta, si era spostata e aveva avuto un figlio che lui non aveva mai visto.

**Non è una vittima passiva.** Giosef ha una dignità silenziosa che colpisce. Non chiede aiuto — offre quello che può. Sa coltivare anche in terra quasi morta. Porta del cibo a Clock ogni mattina senza che nessuno glielo chieda.

**Funzione Gameplay:**
- Micro-missioni ambientali (proteggi il suo raccolto, trova suo nipote nella zona sicura)
- Se aiutato, porta al villaggio 2-3 nuovi civili che appariranno nell'HUB
- Karma: +2 Alto per ogni aiuto

**Karma Basso — Trasformazione:**  
Se il giocatore lo ignora per 5 livelli, Giosef appare al Livello 6 come "Cittadino Corrotto" — non per colpa sua, ma perché l'influenza della zona di corruzione che circonda il villaggio lo ha raggiunto. Combatterlo vale 0 Shard ma +3 Karma Basso. Rivederlo trasformato è uno dei momenti più duri per i giocatori con Karma Alto.

---

### Crono — Collezionista di Frammenti

**Nome reale:** Sconosciuto (usa "Crono" come pseudonimo di lavoro)  
**Aspetto:** Figura incappucciata grigia, occhi rossi che brillano nell'ombra, mani sempre in movimento — sempre raccoglie qualcosa, sistema qualcosa, cataloga qualcosa  
**Ambiguità intenzionale:** Non è mai chiaro se sia alleato o nemico. Parla per frasi brevi, quasi aforismi. Non spiega le proprie motivazioni.

**Il suo segreto (rivelato al Livello 12):**  
Crono era un agente del culto che si è ribellato non per idealismo ma per interesse pratico — ha capito che se il Grande Rituale avesse avuto successo, anche lui sarebbe stato "cancellato" insieme a tutto il resto. La sua motivazione è egoistica. Ma il risultato è utile.

La rivelazione al Livello 12 è interessante perché non trasforma Crono in un eroe — rimane moralmente grigio. Ma il giocatore smette di diffidare di lui, pur non fidandosi completamente.

**Frasi Iconiche:**
- *"I frammenti non appartengono a nessuno. Io li tengo in custodia."*
- *"Non chiedere da dove vengono. Chiediti dove vanno."*
- *(Livello 12, rivelazione):* *"Pensate che vi aiuti per altruismo? No. Vi aiuto perché voglio sopravvivere. Come voi. Come chiunque."*

---

### Prigionieri delle Ossa — Profili Individuali

I 10 Prigionieri non sono anonimi. Ognuno ha un nome, una storia e un frammento di dialogo che rivela chi era prima del culto.

| # | Nome | Posizione | Chi era | Frase |
|---|------|-----------|---------|-------|
| 1 | Fra' Luca | Livello 1, grotta ossea | Monaco, primo a dubitare | *"Il tempo… non è nemico. È solo… indifferente."* |
| 2 | Mara | Livello 2, stanza segreta | Studentessa di Elias | *"Gli ho creduto. Ero così giovane."* |
| 3 | Il Capitano | Livello 4, volta nascosta | Soldato che rifiutò di uccidere civili | *"Non mi pento. Solo… avrei voluto essere più veloce."* |
| 4 | Theo | Livello 5, santuario cristallo | Ingegnere del culto | *"Ho costruito le gabbie. Non sapevo avrebbero usato anche me."* |
| 5 | Sorella Pieve | Livello 6, alcova ombre | Infermiera del monastero | *"Curavo i feriti. Il culto li riferiva per riportarli da me."* |
| 6 | Il Vecchio Re | Livello 7, galleria oscura | Nobile che rifiutò il patto vampirico | *"Il Barone mi offrì l'eternità. Preferii la mia vita."* |
| 7 | Dario | Livello 8, tempio sommerso | Pescatore della palude | *"Non capivo la filosofia. Capivo che avevano fame. Ho dato da mangiare. Sbagliato."* |
| 8 | Vera | Livello 9, altare cult | Sacerdotessa parallela | *"Pregavo Chronos come divinità benevola. Non come prigioniero."* |
| 9 | Il Meccanico | Livello 10, nucleo forgia | Tecnico del Titano | *"L'ho costruito. Non sapevo sarebbe diventato… quello."* |
| 10 | Fra' Matteo Giovane | Livello 12, archivi | Versione giovane del Monaco | *"Forse se avessi distrutto quella clessidra… Ash, non fare i miei errori."* |

---

---

# SEZIONE 5 — NEMICI & FAZIONI DEL CULTO

*Ogni nemico in Kronos Fight è un credente — o una vittima. Combatterli non è mai solo meccanico: è sempre anche narrativo.*

---

## 5.1 Gerarchia degli Scheletri

### Scheletro Predone — "Il Rinnegato Armato"

**Lore:** Erano monaci, soldati, mercanti — qualunque fedele che ha dubitato del culto nel momento sbagliato. La punizione è la privazione dell'Anima: le ossa continuano a muoversi, a obbedire, a combattere. Ma la coscienza? Rimane intrappolata dentro, impotente testimone di ogni azione.

**Aspetto:** Scheletro dual-wield con due spade corte, mantello marrone a strisce, cinturone rosso, occhi rossi che non si fermano mai — guardano sempre in movimento, come se cercassero una via d'uscita.

**Statistiche:**

| Parametro | Valore | Note |
|-----------|--------|------|
| HP | 45 | Muore in 2-3 colpi Ash |
| Velocità | Alta | Più veloce dell'eroe |
| Danno/colpo | 8 | Frequente se non schivato |
| Aggro Range | 8 metri | Attacca in branco |
| Drop | 3-5 Shard | 15% chance Frammento Anima |

**Comportamento AI:**
- Aggro in range: scatta verso il giocatore in diagonale (evita l'approccio frontale diretto)
- In branco 3+: circondano il giocatore da angolazioni diverse (60°, 180°, 300°)
- Sotto 20% HP: velocità aumenta del 20% (la disperazione della coscienza intrappolata che vuole finire)

**Meccanica Temporale — "Scatto del Rimpianto":**  
Ogni 10 secondi, il Predone esegue uno scatto che bypassa le difese frontali del giocatore. Il dash ha un precursore visivo: una vibrazione viola intorno alle ossa per 0.3 secondi. Questa finestra è sufficiente per un dash preventivo del giocatore.

**Varianti:**
- *Predone con Lancia* (Livello 2+): Range esteso, attacco a distanza, meno veloce in mischia
- *Predone Elite* (Atto II+): Scudo osseo che blocca i proiettili frontali, deve essere aggirato
- *Predone Glitch* (NG+): Velocità casuale variabile, teleport random invece del dash regolare

---

### Scheletro Coscienza — "Il Testimone"

**Lore:** Non tutti i Prigionieri delle Ossa diventano guerrieri. Alcuni vengono "estratti" — la loro coscienza viene amplificata e usata come arma psicologica. Lo Scheletro Coscienza è quello in cui la coscienza è così forte da generare un'aura che disturba la realtà intorno. Non vuole combattere. Deve farlo.

**Aspetto:** Scheletro nudo senza vestiti, avvolto in aura blu elettrica intensa, occhi rossi che guardano il giocatore con qualcosa di riconoscibile come dolore, postura curva come chi porta un peso enorme.

**Statistiche:**

| Parametro | Valore |
|-----------|--------|
| HP | 80 |
| Velocità | Media-Bassa |
| Danno/colpo | 12 (ma raro) |
| Aura Range | 5 metri |
| Drop | 6-8 Shard + 30% chance Frammento Coscienza |

**Meccanica Temporale — "Aura di Inerzia Temporale":**  
L'aura blu rallenta il dash del giocatore del 40% mentre attiva. Non si spegne mai — è costante. L'unico modo per neutralizzarla è l'Aura di Ken (purificazione), che la spegne per 8 secondi.

**Comportamento Speciale:**  
Lo Scheletro Coscienza non attacca mai per primo. Aspetta sempre che il giocatore entri nella sua aura. Se il giocatore non entra entro 15 secondi, si avvicina lentamente, emettendo un suono basso continuo — non un ringhio, quasi un lamento.

Se Clock è vicino: si ferma completamente e abbassa la testa. Come se riconoscesse in Clock qualcosa di simile a sé stesso — un essere intrappolato in un corpo non suo.

---

### Guardiano del Cancello — "La Porta Vivente"

**Lore:** I Guardiani erano i più devoti tra i devoti — quelli che si sono offerti volontariamente alla trasformazione. Credevano che diventare "porte del tempo" fosse un onore. Qualcuno di loro, in fondo, ci crede ancora.

**Aspetto:** Scheletro massiccio armato di clava ossea enorme (un femore gigante calcificato) e colonna vertebrale monumentale usata come scudo. L'armatura è fatta di osso compresso che sembra quasi pietra. Il portale viola che genera sul retro dello scudo è l'espressione del cristallo temporale che ha ingerito.

**Statistiche:**

| Parametro | Elite Standard | Boss-zona |
|-----------|---------------|-----------|
| HP | 250 | 800+ |
| Velocità | Bassa | Bassa |
| Danno colpo singolo | 25 | 40 |
| Riduzione danni frontale | 80% | 90% |
| Drop | 8-12 Shard + Chiave Ossea | 20 Shard + Sigillo |

**Meccanica Temporale — "Portale di Riflessione":**  
Ogni 15 secondi, il Guardiano attiva un portale viola sul retro dello scudo. Tutti i proiettili colpiscono il portale tornano indietro verso il giocatore con 30% di danno aggiuntivo. Ken può "purificare" il portale con l'Aura (3 secondi) per chiuderlo.

**Counter Strategia:**  
La motosega in hold è l'unico attacco che sfonda la difesa frontale del Guardiano dopo 2 secondi di contatto continuo. Il suono dell'osso che si rompe — un crack profondo e soddisfacente — è stato progettato specificamente per essere soddisfacente.

---

## 5.2 Entità Temporali — Nate dall'Anomalia

### Ombra Errante — "Il Predatore del Ritmo"

**Lore:** Non erano esseri viventi. Sono condensazioni di energia temporale negativa — i "residui" di tutte le versioni temporali non realizzate di persone che sono morte violentemente nelle Zone Cristallizzate. Non hanno identità propria. Sono fatte di "ciò che non è mai stato".

**Aspetto:** Creatura oscura felino-draghesca, pelo nero che si muove come fumo, occhi rossi, outline viola che la rende visibile nell'oscurità come un neon spento. Quando si muove, lascia brevi scie di scurità che svaniscono in 0.2s.

**Statistiche:**

| Parametro | Valore |
|-----------|--------|
| HP | 35 (muore facilmente, ma è difficile colpirla) |
| Velocità | Altissima |
| Danno singolo | 18 (attacca raro ma forte) |
| Visibilità | 0% (invisibile permanente) |
| Reveal | 1s prima attacco OPPURE Clock abbaio |
| Drop | 4-6 Shard |

**Meccanica Temporale — "Sfasamento Temporale":**  
L'Ombra esiste 0.5 secondi "fuori sync" rispetto al flusso normale. I proiettili non la colpiscono mai — passano attraverso. Solo attacchi corpo a corpo la danneggiano. Ken con l'Aura la "sincronizza" per 3 secondi rendendola vulnerabile a tutto.

**Sinergia Ambientale:**  
Durante le Tempeste di Sabbia (Livello 3, Deserto), le Ombre Erranti appaiono in doppio del numero normale e attaccano coordinatamente — arrivano sempre da direzioni opposte simultancamente.

---

### Prisma Baby — "Il Frammento Impaziente"

**Lore:** Sono le prime forme di vita spontanea generate dal cristallo temporale corrotto. Non sono creature — sono quasi più simili a fenomeni atmosferici con attitudine. La loro furia evidente (bocca verso il basso, sopracciglia abbassate) non è aggressività conscia: è la tensione strutturale di un cristallo che vuole espandersi e non può.

**Statistiche:**

| Parametro | Valore |
|-----------|--------|
| HP | 30 |
| Velocità movimento | Media-Alta (galleggiamento imprevedibile) |
| Proiettile danno | 6 |
| Proiettile velocità | Lenta → velocissima dopo rimbalzo |
| Drop | 5 Shard + 20% chance cristallo temporale grezzo |

**Meccanica Temporale — "Proiettile Accelerato":**  
I proiettili del Prisma Baby partono lenti (quasi schivabili facilmente) ma accelerano esponenzialmente dopo ogni rimbalzo sulle pareti. Dopo il terzo rimbalzo, sono impossibili da schivare senza dash. Questo insegna al giocatore a non ignorare mai un Prisma Baby.

---

### Prisma Golem — "Il Riflesso Vivente"

**Lore:** Le Prisma Baby che sopravvivono abbastanza a lungo cristallizzano in forme più grandi e stabili. Il Prisma Golem è l'apice di questo processo — un colosso di cristallo che ha assorbito abbastanza energia temporale da sviluppare una forma di istinto difensivo. Non è intelligente. Ma è sistemico.

**Aspetto Dettagliato:**  
Alto circa il doppio di Ash. Corpo prismatico traslucido che riflette tutti i colori dell'arena. Le facce del cristallo cambiano tonalità (blu-viola-rosso) a seconda dell'angolo di attacco subito. Ha "braccia" massicce e una "faccia" formata da un cristallo sfaccettato con un debole bagliore rosso al centro. Quando subisce danni, piccole crepe luminose si formano e rilasciano scintille di Anima.

**Statistiche:**

| Parametro | Standard | Elite/Mini-Boss |
|-----------|----------|-----------------|
| HP | 650 | 950 |
| Riduzione danni proiettili | 40% | 60% |
| Velocità | Lenta + carica improvvisa | Lenta + carica più frequente |
| Danno colpo singolo | 30 | 45 |
| Drop | 12 Shard + Anima pickup | 20 Shard + Sigillo Zona |

**Meccanica Centrale — "Riflesso Prismatico":**

| Tipo Impatto | Direzione Rimbalzo | Danno Riflesso |
|-------------|-------------------|----------------|
| Frontale | Diretto indietro al giocatore | 100% originale |
| Laterale sx | 45° verso sx | 100% + 20% |
| Laterale dx | 45° verso dx | 100% + 20% |
| Dall'alto | Verso il basso | 80% |

La meccanica "Riflesso a Catena": se il proiettile riflesso colpisce un altro Golem o nemico, causa danno extra del 25%. Possibilità di "rimbalzi a catena" contro gruppi nemici.

**Meccanica "Scudo di Rifrazione":**  
Attivato quando Ken usa l'Aura entro 3 metri. Il Golem genera uno scudo prismatico che rallenta tutti i proiettili al 40% e recupera 6% HP/secondo. Unico counter: Motosega Ash sul Golem durante lo scudo attivo → scudo distrutto + stun 1.8s.

**Sinergia Obbligatoria Ash+Ken:**  
Il "Taglio Prismatico Combinato" — motosega Ash avvolta dall'Aura Ken — infligge danno ×3.5 ed è l'unica tecnica che può uccidere il Golem Elite in meno di 10 secondi.

---

## 5.3 Umani Corrotti — Le Scelte Sbagliate

### Cittadino Sorridente — "La Felicità Pericolosa"

**Lore:** Non è un fanatici ingenuo. Sa esattamente cosa sta facendo. Il culto gli ha offerto qualcosa che nessun terapista, nessun medico, nessun amico era riuscito a dargli: la certezza che il dolore avrebbe fine. Non importa come. Non importa a che prezzo. Per lui, qualsiasi prezzo è accettabile.

Questo lo rende l'antagonista secondario più disturbante del gioco — non perché sia cattivo, ma perché è *comprensibile*.

**Statistiche:**

| Parametro | Valore |
|-----------|--------|
| HP | 60 |
| Velocità | Altissima (corre sempre) |
| Danno proiettile | 12 + eco temporale |
| Pattern fire | Caotico (non miratore) |
| Drop | 5 Shard |

**Meccanica Temporale — "Proiettile Biforcato":**  
Ogni proiettile crea un eco temporale che arriva 0.3s dopo nello stesso punto. Questo significa che schivare il proiettile originale non è sufficiente — bisogna schivare anche l'eco.

**Comportamento:** Non usa copertura. Non si ritira. Ride durante il combattimento con un'animazione specifica (bocca aperta, occhi rosa luminosi). Se il giocatore lo uccide mentre ride — cosa che accade spesso — c'è un breve congelamento dell'animazione prima della morte che può disturbare i giocatori sensibili.

---

### Alchimista Caduto — "Lo Scienziato Morto"

**Lore:** Era un genio. Sul serio — i documenti recuperati nel Laboratorio Alfa mostrano che le sue ricerche sulla sintesi temporale erano avanti di decenni rispetto a qualsiasi altra cosa del culto. Ma si è sperimentato addosso una volta di troppo. Il corpo è morto. La mente no. Continua a lavorare guidata solo dall'abitudine — esperimenti, sintesi, test — senza mai chiedersi perché.

**Statistiche:**

| Parametro | Valore |
|-----------|--------|
| HP | 120 |
| Velocità | Bassa (curvo, camminata instabile) |
| Danno pozione diretta | 15 |
| Effetto pozione verde | Inversione comandi 3s |
| Effetto pozione rossa | Rallentamento 50% 4s |
| Effetto pozione viola | Silenzio audio 3s |
| Drop | 8 Shard + 40% chance pozione |

---

### Collezionatore di Tasse — "Il Contabile del Culto"

**Lore:** Non sono demoni nel senso tradizionale. Sono l'ala "HR" del culto — entità create sinteticamente dai Servitori Dorati per "processare" l'energia vitale dei vivi in formato utilizzabile per il rituale. Hanno la forma che hanno (piccola, grottesca, quasi comica) perché sono stati progettati per non sembrare minacciosi alle prime vittime.

**Statistiche:**

| Parametro | Valore |
|-----------|--------|
| HP | 40 |
| Velocità volo | Altissima |
| Danno diretto | 5 (non è il loro obiettivo primario) |
| Furto Shard | 15 Shard se non interrotto |
| Drop | 10 Shard (recuperati) + monete viola |

**Meccanica Unica — "Il Furto Cumulativo":**  
Se 3+ Collezionori rubano con successo nello stesso livello, il boss del livello inizia con uno scudo bonus del 10% HP. Questo crea urgenza: il giocatore deve prioritizzare i Collezionori anche quando ci sono nemici più forti in campo.

---

## 5.4 Bestie Temporali

### Rospide Mutante — "Il Guardiano Tossico"

**Lore:** I Rospidi erano anfibi normali nelle paludi pre-corruzione. L'esposizione cronica all'energia temporale di Anima li ha trasformati in qualcosa di ibrido. La corona arcana viola che porta è un cristallo temporale che si è formato spontaneamente sulla sua testa per anni di esposizione — non è stata messa dal culto. È cresciuta.

Il culto li usa come "guardiani biologici" perché sono impossibili da corrompere ulteriormente — sono già al loro massimo di mutazione.

**Statistiche:**

| Parametro | Valore |
|-----------|--------|
| HP | 180 |
| Velocità | Bassa (stazionaria) |
| Attacco sputata | 8 danno + svuota 20% Anima |
| Raggio controllo area | 6 metri |
| Drop | 10 Shard + veleno usabile come oggetto |

**Meccanica Unica — "Veleno di Anima":**  
Il veleno del Rospide non danneggia la vita — svuota l'Anima. Questo è particolarmente devastante nei livelli in cui Ken deve usare frequentemente l'Aura. La strategia ottimale è sempre eliminare prima i Rospidi per garantire la piena disponibilità dell'Anima nelle sezioni successive.

---

## 5.5 Servitori Tecnologici

### Cyber-Servitore — "Il Robot Devoto"

**Lore:** Non è un robot nel senso convenzionale — è un monaco che ha chiesto di essere "trasformato" per servire meglio il culto. L'aspetto meccanico è sia funzionale che simbolico: liberarsi del corpo biologico mortale è, per lui, un atto di fede.

Le ali viola non sono decorative — sono la sua connessione con il campo di Anima del culto. Se le ali vengono distrutte (dopo 50% danni), il Cyber-Servitore cade al suolo e perde la capacità di volare, diventando molto più vulnerabile.

**Statistiche:**

| Stato | HP | Velocità | Danno Laser |
|-------|-----|----------|-------------|
| Volo (ali intatte) | 100 | Alta | 15/s |
| Terra (ali distrutte) | — | Bassa | 10/s |

**Meccanica Temporale — "Desync Window":**  
Durante la ricarica energetica (ogni 20s), il Cyber-Servitore è leggermente "fuori sync" — visivamente si vede un leggero delay tra il suo movimento e la sua hitbox. In questo stato, i colpi di Ash infliggono ×1.5 danni. La finestra dura 3 secondi.

---

### Esecutore Silenzioso — "La Catena della Legge"

**Lore:** Gli Esecutori sono agenti di controllo del culto — applicano la "giustizia temporale" contro chi devia. Ogni catena che portano era, un tempo, la catena di un prigioniero. Le hanno tenute come trofei e poi le hanno trasformate in armi. Non parlano mai. Non perché siano stati privati della voce — hanno scelto il silenzio come forma di rispetto verso la propria funzione.

**Aspetto Dettagliato:**  
Alto, avvolto in mantello nero, cappuccio basso, occhi luminosi nell'ombra del cappuccio (non rossi — viola scuro, come se fossero finestre su uno spazio vuoto). Le catene d'argento si muovono da sole intorno a lui, formando pattern geometrici complessi anche quando non attacca.

**Statistiche:**

| Parametro | Valore |
|-----------|--------|
| HP | 200 |
| Velocità movimento | Lenta-Media (mai si affretta) |
| Danno catena diretta | 20 |
| Effetto catena | Ancoraggio al pavimento 2s |
| Suono | Silenzio assoluto tranne il tintinnio delle catene |
| Drop | 12 Shard + 25% chance Catena Frammentata (oggetto) |

**Meccanica Unica — "Geometria della Prigionia":**  
Le catene non attaccano casualmente — descrivono cerchi intorno al giocatore che si restringono progressivamente. Se il giocatore non rompe il cerchio in tempo (6 secondi), viene "ancorato". Ken può bruciare le catene con l'Aura prima che chiudano il cerchio.

**Variante Elite:** Due Esecutori le cui catene si intrecciano — formano una gabbia che intrappola il giocatore se entrambi rimangono in vita più di 10 secondi simultancamente.

---

---

# SEZIONE 6 — BOSS DESIGN: ELITE GUARDIANS

*Ogni boss in Kronos Fight è un capitolo narrativo. La meccanica è il linguaggio — la storia è il significato.*

---

## 6.1 VERME COLOSSALE — "Il Divoratore di Secondi"

### Contesto Narrativo

Il Verme Colossale non è membro del culto. È la prima creatura che il culto ha trovato abbastanza grande e abbastanza antica da poter contenere frammenti multipli di cristallo temporale. Lo hanno armato. Lo hanno corrotto. Non sa di essere corrotto.

Guarda il giocatore con quell'unico occhio viola e probabilmente pensa solo: *fame*.

Questo non lo rende meno pericoloso. Lo rende più tragico.

**Nota di Design:** Il Verme deve essere abbastanza intimidante da sembrare impossibile al primo sguardo, ma abbastanza comprensibile che il giocatore inizi a vedere i pattern dopo 2-3 tentativi. Il "click" — il momento in cui il giocatore capisce come affrontarlo — deve essere soddisfacente come rompere qualcosa che sembrava indistruttibile.

---

### Arena — "Il Cerchio delle Costole"

Cerchio di 20 metri di diametro chiuso da costole giganti di un essere preistorico semi-sepolte nella sabbia. Le costole fungono da pareti invalicabili — non ci sono angoli, non ci sono nascondigli, solo il cerchio e la sabbia che si muove.

**Caratteristiche Dinamiche dell'Arena:**
- La sabbia si muove in pattern circolari che anticipano dove il Verme emergerà (leggibile dopo 1-2 morti)
- Il tremolio del terreno aumenta 2 secondi prima di ogni emersione
- Nella Fase 2, il centro dell'arena crea un pull costante — il giocatore deve muoversi sempre verso i bordi del cerchio

---

### FASE 1 — PREDATORE INVISIBILE (100% → 50% HP)

**Stato:** Invulnerabile sottoterra. Si muove visibilmente dalla sabbia che si sposta.

**Attacchi Dettagliati:**

**"Carica Sabbiosa":**
- Durata preparazione: 1.5s (tremolio visibile nel punto di emersione)
- Velocità carica: Alta (3/4 dell'arena in 0.8s)
- Danno diretto: 35
- Counter: Dash laterale nel momento esatto (finestra 0.3s) oppure doppio salto
- *Feedback visivo:* La sabbia "schizza" in anticipo di 0.2s nel punto di emersione

**"Finta Emergenza":**
- Il Verme si solleva a metà dalla sabbia (testa visibile per 1s) poi rientra
- Pausa 0.5s → emerge dall'altro lato dell'arena con carica vera
- Punisce i giocatori che reagiscono immediatamente alla prima emergenza
- *Nota di Design:* Appare per la prima volta alla seconda esposizione del giocatore al boss — mai al primissimo tentativo

**"Pioggia di Sabbia":**
- Il Verme colpisce forte al suolo dopo un'emersione fallita
- Area di effetto: 5 metri di raggio dal punto di impatto
- Danno: 20 nell'area
- Crea una finestra DPS di 3 secondi (il Verme è immobile e vulnerabile)

**Sinergia Ash + Ken nella Fase 1:**
- Ash: motosega sui segmenti esposti durante la finestra DPS (danno ×2 sui segmenti)
- Ken: pugno carico sulla bocca aperta durante la finestra = stun aggiuntivo 1s

---

### FASE 2 — ENTITÀ COSMICA (HP < 50%)

**Transizione:**  
Il Verme emerge completamente per la prima volta — non solo la testa, ma l'intero corpo. Le clessidre incise sui segmenti si illuminano viola intenso. Gli ingranaggi sul corpo iniziano a girare. Un suono che non è un ruggito — è più simile a un orologio che si rompe, amplificato mille volte.

**Nuovi Attacchi:**

**"Vortice Temporale":**
- Pull gravitazionale costante verso il centro dell'arena
- Forza: sufficiente a spostare il giocatore di 1 metro ogni 2 secondi se non si corre
- Non può essere bloccato — solo contrastato con movimento attivo
- *Design Intent:* Crea la sensazione di una corrente oceanica — il giocatore deve "nuotare" costantemente

**"Pioggia di Shard":**
- 12-15 frammenti cristallini sparati in pattern radiale dal corpo del Verme
- Pattern A: esplosione uniforme (schivabile con dash nel momento giusto)
- Pattern B: alternato alto/basso (schivabile con salto timed)
- Pattern C (HP < 25%): caos quasi totale — solo 2-3 zone sicure visibili per 0.5s

**"Afterimage Trap" (Meccanica Nuova):**
- Il giocatore lascia "immagini temporali" di sé stesso nei punti in cui si è fermato più di 1 secondo
- Se il Verme colpisce un'afterimage: danno riflesso al giocatore pari al 30% del danno dell'attacco
- *Teaching:* Non stare mai fermi. Mai. Questo è il tempo come minaccia.

---

### Colpo di Grazia

Al 5% HP: Il Verme esegue il "Head Slam" finale — la testa schiaccia a terra aprendo la bocca completamente. La bocca rimane aperta per 2 secondi.

**QTE:**
1. Ash attiva Motosega Omega (hold) → lancia la lama nella bocca aperta
2. Ken avvolge la lama con l'Aura massima (sincronizzazione input < 0.5s)
3. Animazione: slow-motion 6 secondi, la lama tagliente+energizzata taglia dall'interno
4. Esplosione interna di ingranaggi dorati e polvere temporale

**Drop:** 8 Chronos Shard + 1 Sigillo del Tempo + Passivo "Resistenza al Pull" permanente

**Cutscene Post-Boss:**  
Il Verme implode su sé stesso. La sabbia viene risucchiata verso il centro. Screen shake pesante. Audio distorto "al contrario" per 2 secondi. Poi silenzio. Clock abbaia piano — quasi con rispetto.

---

## 6.2 BARONE VAMPIRO DEL TEMPO — "Lord Victor von Nachtschatten"

### Backstory Completa

Victor non odiava il tempo. Lo temeva.

Nato con la "Malattia del Tempo" — una condizione genetica che faceva invecchiare la sua famiglia a velocità tripla — aveva visto morire tutti i suoi fratelli prima dei 35 anni. A 29, aveva già l'aspetto di un 60enne. Spese l'intera fortuna familiare in medici, alchimisti e occultisti. Nessuno aiutò.

Quando sentì parlare del "sacerdote pazzo" che prometteva di fermare il tempo, salì al monastero nel cuore dell'inverno, quasi incapace di camminare. Elias lo ricevette nella cripta. Victor si inginocchiò.

*"Fermate il tempo per me. Vi darò tutto."*

Il patto fu siglato quella notte: tutto il patrimonio di Victor + la sua anima + il giuramento di servire il Gran Rituale. In cambio: il Rituale del Sangue Cristallino — immortalità vampirica a base di cristallo temporale.

Il problema? Il cristallo temporale non ferma il processo biologico — lo sostituisce con un altro processo. Victor non invecchia più, ma deve nutrirsi di Anima altrui per mantenere la coerenza del suo corpo cristallizzato. Ogni decade senza nutrimento sufficiente, inizia a disintegrarsi in polvere di cristallo.

L'immortalità che desiderava è diventata una dipendenza permanente. Più Anima ruba, più il corpo regge. Meno ne ruba, più si avvicina alla morte che tanto temeva.

È una prigione. Ma è la sua prigione. E la difende con ferocia.

---

### Arena — "La Radura delle Clessidre"

Arena circolare di 18 metri di diametro. Pareti: cristalli riflettenti alti 4 metri che pulsano al ritmo degli HP del boss (più è debole, più il ritmo è irregolare). Soffitto: stalattiti di cristallo da cui pendono i pipistrelli. Pavimento: cristallo traslucido che mostra ombre di clessidre sotto.

**Effetto Drammatico:** A ogni transizione di fase, i cristalli delle pareti cambiano colore:
- Fase 1: Blu-cristallo freddo
- Fase 2: Rosso-nebbia caldo
- Fase 3: Nero assoluto con solo la luce del Cuore di Cristallo del boss

---

### Dialoghi Completi — Boss Fight

**INTRODUZIONE (Boss appare):**

*Il Barone Vampiro scende fluttuando dalle stalattiti. La cappa dorata si agita. Le ali di cristallo brillano.*

> **Barone** *(voce elegante, eco cristallino):*  
> "Finalmente… l'erede del tempo è giunto nelle mie umili caverne."

> **Sara** *(voce tesa):*  
> "Victor… sei caduto più in basso di quanto immaginassi."

> **Barone** *(sorride, mostrando zanne luminescenti):*  
> "Sara… la mia piccola principessa del tempo. Quanto sei cresciuta.  
> O dovrei dire… quanto sei diventata fredda e meccanica?"

> **Sara:**  
> "Non sono più tua. E non sono mai stata sua."

> **Barone** *(ride piano, con qualcosa di vero nel tono):*  
> "Tuo padre mi ha promesso l'eternità. Io gli ho promesso te.  
> Ora vi riporterò entrambi al suo fianco."

---

### FASE 1 — IL SIGNORE DEL SANGUE CRISTALLINO (100% → 65%)

**Evocazione Pipistrelli di Cristallo:**
- Ogni 8 secondi: 4-6 pipistrelli in formazione a V
- Sparano proiettili Anima (piccoli, veloci, danno 5 Anima cad.)
- Se colpisci un pipistrello con proiettile: esplode in schegge che rimbalzano (pericoloso in mischia)
- Ash deve distruggerli in mischia, non a distanza

**Morso dell'Anima:**
- Teletrasporto rapido verso Ken (priorità)
- Animazione: il Barone "sfoca" e riappare a 1 metro da Ken
- Ruba 15% barra Anima → genera scudo cristallino intorno a sé (-40% danni per 5s)
- Counter: Ken colpisce il Barone durante il teletrasporto (finestra 0.3s) → attacco interrotto + Anima recuperata cade al suolo

**Pioggia di Vetro:**
- Salta al centro → schegge dal soffitto in pattern cono
- Le schegge si piantano nel terreno come spine → rallentano il movimento del 30% se calpestate
- Durano 15 secondi — l'arena diventa progressivamente un campo minato

---

*Dialogo durante Fase 1:*

> **Barone** *(mentre evoca pipistrelli):*  
> "Guardate questi piccoli servitori! Frammenti di tempo puro, proprio come te, Sara!"

> **Barone** *(dopo il primo Morso dell'Anima):*  
> "Sento il tuo Anima… così dolce, così viva.  
> Lascia che ne prenda un sorso. Solo un sorso."

> **Sara:**  
> "Non lasciate che vi rubi l'Anima! È la sua unica fonte di potere!"

---

### FASE 2 — LA NEBBIA ETERNA (65% → 30%)

**Trasformazione:** Il Barone si dissolve lentamente. Prima le ali. Poi le mani. Poi il corpo. La nebbia rossa-viola riempie metà arena. *"Senti questo freddo? È il futuro che ti sto rubando."*

**Meccaniche Nebbia:**

**"Attacchi dalle Pareti":**
- La nebbia si sposta sui cristalli riflettenti → attacca da angolazioni imprevedibili
- I proiettili rimbalzano 2-3 volte prima di fermarsi
- Counter strategico: usare le pareti cristalline → far rimbalzare i propri proiettili nella nebbia la danneggiano

**"Risucchio di Vita":**
- Zone di nebbia viola sul pavimento (visibili come macchie scure)
- Restare > 2s: -8 HP/s + -5 Anima/s
- Non è letale da sola — ma se combinata con i proiettili rimbalzanti, crea una pressione costante

**"Riformazione Improvvisa":**
- Dopo 6s di nebbia, si riforma in punto casuale con zampata (knockback 3 metri + danno 30)
- Ken può bruciare la nebbia con l'Aura per forzare la riformazione anticipata e prevederla

---

*Dialogo Fase 2:*

> **Barone** *(voce da tutte le direzioni):*  
> "Senti questo freddo? È il futuro che ti sto rubando, un secondo alla volta."

> **Barone** *(attaccando dalle pareti):*  
> "Guarda come rimbalzano i tuoi proiettili! Il tempo stesso ti tradisce,  
> proprio come ha tradito me!"

> **Sara:**  
> "Usa i cristalli dell'arena! Fai rimbalzare i suoi stessi attacchi contro di lui!"

> **Barone** *(mentre la nebbia si riforma, con voce sofferente):*  
> "Perché combatti? Io volevo solo vivere… senza invecchiare… senza morire…  
> Tuo padre me lo aveva promesso!"

> **Sara** *(con rabbia crescente):*  
> "Mio padre ti ha mentito. Come ha mentito a tutti noi."

---

### FASE 3 — IL PARADOSSO DEL CULTO (30% → 0%)

**Trasformazione:** Il Cuore di Cristallo si espone completamente. L'arena → buio quasi totale, solo il cuore illumina tutto.

**"Doppio Sé":**
- Clone di nebbia che copia i movimenti del Barone (30% HP)
- Clone colpibile SOLO da Ken (Aura purifica la nebbia)
- Corpo principale colpibile solo da Ash
- Se solo uno dei due viene attaccato: il Barone recupera il 10% HP ogni 8 secondi

**"Morso Finale":**
- Carica potentissima: teletrasporto + 3 hit combo rapida
- Se non interrotta: -40% Anima + boss si cura 20%
- Counter: combo sincronizzata Ash+Ken (input entro 0.3s l'uno dall'altro) interrompe e stordisce 2s

**"Collasso Cristallino" (HP < 10%):**
- Tutti i cristalli dell'arena esplodono simultaneamente
- Proiettili in TUTTE le direzioni per 2 secondi
- Le piattaforme magnetiche del pavimento possono essere usate per schivare in aria

---

*Dialogo Fase 3:*

> **Barone** *(voce sdoppiata, corpo e clone):*  
> "Guarda! Anche il tuo futuro combatte al mio fianco! Presto non ci sarà differenza tra noi!"

> **Sara** *(con voce bassa, quasi gentile):*  
> "L'eternità non esiste, Victor.  
> Esiste solo il tempo che ci è stato dato. E tu lo hai sprecato."

---

### QTE — Colpo di Grazia (5% HP)

*Il Barone in ginocchio. Il Cuore di Cristallo esposto e crepato.*

> **Barone** *(voce debole):*  
> "Sara… piccola mia… ti prego…  
> Riportami da tuo padre. Lui mi aveva promesso… l'eternità…"

> **Sara:**  
> "Addio, Victor."

*Ash lancia la motosega → Ken la avvolge con l'Aura → taglio del Cuore (slow-motion 4s, particelle oro-blu, suono di cristallo che si frantuma con campana riverberata)*

> **Barone** *(ultime parole):*  
> "No… non può finire così…  
> Chronos… perché… mi hai abbandonato…?"

**Cutscene Post-Boss:**

> **Sara** *(dopo silenzio):*  
> "Era patetico. Ma una volta era un uomo che aveva solo paura di morire."

> **Ash:**  
> "Lo conoscevi bene?"

> **Sara:**  
> "Mi chiamava 'principessa del tempo' quando ero bambina.  
> Pensava che rubando abbastanza Anima avrebbe potuto vivere per sempre.  
> Invece è diventato solo un altro schiavo del culto."

> **Ken:**  
> "Sembra che tuo padre abbia distrutto molte vite."

> **Sara** *(voce più bassa):*  
> "Sì. E la mia è stata solo la prima."

---

## 6.3 ARCIPRETE DEL TEMPO — "Padre Elias Voss"

*(Il boss più narrativamente importante del gioco)*

### Contesto Completo

La fight con l'Arciprete non è una boss fight.  
È un addio.

Per Sara, è l'unica possibilità di chiudere il cerchio con suo padre senza avere la forza di farlo lei stessa. Per il giocatore, è il momento in cui il "villain" smette di essere villain e diventa semplicemente un uomo che ha preso una decisione sbagliata per ragioni comprensibili, e ha passato 70 anni a moltiplicarne le conseguenze.

Non è possibile vincere questa fight senza un costo emotivo. È il punto.

---

### Dialoghi Completi

**(Al momento dell'ingresso nell'arena)**

> **Arciprete** *(voce profonda, calma, riverberata):*  
> "Finalmente… sei arrivato, figlio del tempo spezzato."

> **Sara** *(voce artificiale, con incrinatura):*  
> "Padre… non farlo. Non costringermi a vederti morire di nuovo."

> **Arciprete** *(ride piano, con tristezza):*  
> "Sara… la mia piccola eresia. Hai scelto di vivere fuori dal tempo,  
> rinchiusa in una macchina. E ora porti questi due relitti del tempo a distruggermi."

> **Sara:**  
> "Tu non salvi nessuno. Vuoi solo smettere di soffrire."

> **Arciprete:**  
> "Allora guardami mentre ti libero dal dolore… per sempre."

---

**FASE 1 (100% → 65%)**

> **Arciprete** *(alzando il bastone):*  
> "Lasciate che vi mostri quanto è dolce il passato…  
> quando non c'è futuro a rovinarlo!"

> *(Dopo aver invertito i comandi)*  
> "Vedi? Anche tu non sai più dove andare.  
> Questo è il tempo che ti ha dato."

> **Sara:**  
> "Non ascoltate la sua voce! Sta usando le vostre paure!"

> *(Quando il giocatore interrompe la preghiera)*  
> **Arciprete** *(con dolore):*  
> "Sara… perché mi combatti?  
> Io volevo solo salvarti dal rimpianto…"

> **Sara** *(voce più bassa):*  
> "Tu non mi hai mai salvata. Mi hai solo insegnato a temerlo."

---

**FASE 2 (65% → 30%)**

> **Arciprete:**  
> "Il presente è solo un'illusione crudele.  
> Io vi offro l'eternità… dove nulla cambia, nulla muore, nulla finisce!"

> *(Lanciando le catene)*  
> "Senti queste catene? Sono gli anni che ti ho rubato, figlia mia."

> **Sara** *(quasi urlando):*  
> "Basta! Non sei più mio padre!  
> Sei solo una ferita che continua a infettare il tempo!"

---

**FASE 3 (30% → 0%)**

> **Arciprete** *(voce sdoppiata):*  
> "Ora vedrete… il vero volto di Chronos!  
> Il tempo non scorre più… SI FERMA!"

> *(Vedendo il clone "del futuro" del giocatore)*  
> "Anche il tuo futuro ti tradisce.  
> Guarda… sta già combattendo al mio fianco."

> **Sara** *(voce rotta, quasi umana):*  
> "Padre… ti prego… fermati.  
> Non voglio perderti di nuovo."

> **Arciprete** *(con tristezza genuina, forse la prima parola sincera):*  
> "Sara… se solo mi avessi lasciato finire quel rituale tanti anni fa…  
> ti avrei risparmiato tutto questo dolore."

---

**QTE — Colpo di Grazia**

> **Arciprete** *(supplica):*  
> "Sara… figlia mia…  
> Se mi uccidi… chi ti proteggerà dal domani?"

> **Sara** *(ferma, tremante):*  
> "Addio, padre.  
> Questa volta… lascerò che il domani esista."

> **Arciprete** *(tagliato dal QTE, ultime parole):*  
> "Chronos… perdonami…  
> Non sono stato abbastanza forte…  
> per fermare… il domani…"

**Cutscene Post-Boss:**

> **Sara** *(lungo silenzio, voce quasi umana):*  
> "Grazie… per averlo fermato.  
> Non potevo farlo io. Non di nuovo."

> **Ash:**  
> "Era davvero tuo padre?"

> **Sara:**  
> "Lo era… tanto tempo fa.  
> Prima che il tempo lo consumasse."

> **Ken:**  
> "Mi dispiace."

> **Sara** *(dolcemente):*  
> "Non dispiacerti.  
> Oggi abbiamo dato pace a ciò che restava di lui."

---

## 6.4 TITANO DEI PARADOSSI — "Unit 0-OMEGA"

*(Boss tecnico — il test meccanico definitivo)*

### Filosofia di Design

Il Titano rappresenta ciò che il culto è diventato nell'Atto IV: non più una religione, ma un'industria. Una macchina. Il boss finale prima di Kronos non è un essere senziente — è un sistema. E i sistemi si smantellano.

Questo è il boss in cui il giocatore usa *tutto* quello che ha imparato. Gravity-flip, Dual Hero Sync, Clock Sonar, switch di personaggio preciso — tutto insieme. È il test finale prima del palcoscenico finale.

**Aspetto:** Mecha colossale alto 4 piani, metà metallo arrugginito industriale + metà cristalli temporali luminescenti. Petto: mini-buco nero instabile che pulsa come un cuore malato. Braccia: pistoni idraulici con lame rotanti. Testa: cockpit vuoto con occhio rosso che proietta ologrammi di paradossi temporali in loop.

---

### Dialogo (breve — è una macchina)

> **Sara** *(entrando nell'arena):*  
> "Il Titano è la fabbrica del culto. Non è senziente. Ma è letale.  
> Distruggete le giunture meccaniche prima che si riparino."

> **Sara** *(Fase 2, zero-G):*  
> "Clock sta marcando le piattaforme sicure! Seguite i cerchi dorati!"

> **Sara** *(Fase 3, sdoppiamento):*  
> "Si è diviso. Passato e Presente. Devono essere colpiti in sincrono  
> o si curano a vicenda."

> **Sara** *(QTE):*  
> "Ora. INSIEME."

**Post-Boss:**

> **Sara:**  
> "Hai distrutto la fabbrica del destino.  
> Ora il culto è cieco. Resta solo il Trono."

> *Clock abbaia trionfante.*

---

## 6.5 KRONOS — IL SIGNORE DEL TEMPO
*(Boss Finale — L'Origine e la Fine)*

*(I dialoghi completi sono in Sezione 13. Qui solo il design meccanico.)*

### Progettazione Filosofica del Boss

Kronos è la domanda finale del gioco: *"Se potessi fermare il tempo, lo faresti?"*

Non è una risposta. È una domanda posta meccanicamente — ogni fase del boss chiede al giocatore di rispondere con le sue azioni. La Fase 2 insegna che il passato non può essere recuperato. La Fase 3 insegna che il futuro non può essere controllato. Il QTE finale insegna l'unica risposta possibile: il presente. Adesso. Qui.

---

### FASE 1 — IL PADRONE DELLA REALTÀ (100% → 65%)

**"Eco del Passato":**
- Spawn di fantasmi potenziati (HP: 30% del boss originale):
  - Scheletro Predone Elite ×3 (dal Liv. 1)
  - Prisma Golem (dal Liv. 5)
  - Barone Vampiro — forma nebbia (dal Liv. 5)
  - Arciprete — forma eco (dal Liv. 8)
- Non si possono ignorare — se non eliminati in 30 secondi, si uniscono a Kronos aumentandone i danni del 15% cad.

**"Laser Temporali Predittivi":**
- I laser non colpiscono dove sei — colpiscono dove sarai tra 2 secondi (calcolato dalla traiettoria attuale)
- Unico counter: cambio direzionale improvviso

**"Intervento di Sara":**
- Ogni combo 8+ hit: Sara "strappa secondi dal dominio di Kronos" → Cura Temporale appare (recupero 15% HP)
- Sara: *"Sto strappando secondi dal suo dominio… per te."*

---

### FASE 2 — IL LOOP TEMPORALE (65% → 30%)

**"Rewind Fatale"** (ogni 12 secondi):
- Lo schermo diventa sephia per 0.5s
- Tutto si riavvolge di 3 secondi:
  - Danni subiti: annullati
  - Danni inflitti a Kronos: recuperati da lui
  - Posizione: resettata a 3s fa
- I fantasmi dei livelli precedenti appaiono in "echo mode" durante il rewind
- Colpire i fantasmi durante il rewind = Shard extra (incentivo a rimanere aggressivi anche durante il reset)

**Design Intent:**  
Il giocatore deve imparare il "ballo" — colpire nei 9-10 secondi tra un rewind e l'altro, schivare perfettamente, non subire danni che verranno comunque annullati. I giocatori pro faranno speedrun perfetti di questa fase. I giocatori normali impareranno gradualmente. Entrambe le esperienze sono valide.

---

### FASE 3 — IL PARADOSSO ASSOLUTO (30% → 0%)

Lo sfondo scompare. Tutto diventa vuoto bianco infinito con frammenti di memoria di tutti i 13 livelli che fluttuano.

**"Versioni Future":**
- Kronos crea 3 versioni future del giocatore (costruite dall'AI che ha registrato le combo più usate nel playthrough)
- Ash Future → colpibile solo da Ken
- Ken Future → colpibile solo da Ash
- Dual Future → colpibile solo con Dual Hero Sync
- Devono essere sconfitti in ordine: Passato → Presente → Futuro
- Se attaccati nell'ordine sbagliato: si immunizzano per 5 secondi

**"Collasso del Tempo" (HP < 10%):**
- Kronos crea 12 clessidre intorno al giocatore
- 1 clessidra brilla di luce azzurra = quella corretta
- Il giocatore ha 1.5 secondi per colpire quella corretta
- Fallimento: one-shot cinematico (evitabile con revival AdMob)
- Successo: break difesa totale, finestra DPS massiva di 5 secondi

---

### QTE — "Il Taglio del Tempo"

*Kronos al 5% HP, in ginocchio sul trono crepato.*

1. Ken lancia Ash in aria (slow-motion 0.3x)
2. Ash attiva Motosega Omega
3. Ken avvolge la lama con l'Aura massima (input < 0.5s)
4. Il giocatore preme il tasto al momento esatto (finestra 0.8s, cerchio visivo che si restringe)
5. Animazione: 10 secondi, taglio che spacca il Cuore-Orologio di Kronos
6. La spaccatura si propaga in tutto lo sfondo bianco come uno schermo che si rompe
7. Poi: silenzio. Luce dorata. Frammenti del tempo che tornano al loro posto.

---

---

# SEZIONE 7 — STRUTTURA LIVELLI COMPLETA

## MAPPA COMPLETA DEL MONDO

```
ATTO I — LE ORIGINI
├── Livello 1: Deserto delle Ossa
├── Livello 2: Fortezza del Tempo (Chronos Stronghold)
└── Livello 3: Foresta dell'Anima ← BOSS: Verme Colossale

ATTO II — L'ASCESA DEL CULTO  
├── Livello 4: Guglia d'Oro
├── Livello 5: Caverne Cristallo ← BOSS: Barone Vampiro
└── Livello 6: Settore Ombre [Prima Parte]

ATTO III — IL CUORE DELLA DISTORSIONE
├── Livello 7: Settore Ombre [Profondo]
├── Livello 8: Paludi & Rovine ← BOSS: Arciprete del Tempo
│   └── [SEGRETO] Monastero delle Ore Perdute
└── Livello 9: Rovine Profonde

ATTO IV — LA MECCANICA DEL DESTINO
├── Livello 10: The Gravity Forge ← BOSS: Titano dei Paradossi
├── Livello 11: Laboratori Chronos — Sezione Alfa
└── Livello 12: Laboratori Chronos — Sezione Omega

ATTO V — IL TRONO DI KRONOS
└── Livello 13: Il Trono del Paradosso ← BOSS FINALE: Kronos
```

---

## ATTO I — LE ORIGINI (Livelli 1-3)

### LIVELLO 1 — DESERTO DELLE OSSA

**Tagline:** *"Dove il tempo non scorre… si consuma."*  
**Durata Media:** 15-20 minuti | **Difficoltà:** ★☆☆☆☆

**Palette Cromatica:** Arancione bruciato (#C45C1A) + Viola Chronos (#7B2FBE) + Oro ossidato (#B8860B)

**Atmosfera:** Caldo opprimente, vento che ulula tra le ossa colossali, sole rosso perennemente al tramonto. Le dune sono dove un mare pre-temporale si è fossilizzato. Le ossa enormi semi-sepolte non sono di animali — sono di esseri che il culto ha "accelerato" fino alla morte secoli fa.

**Struttura Zona per Zona:**

*Zona 1 — Dune Iniziali:*
- Piattaforme di sabbia che sprofondano dopo 3 secondi di permanenza
- Tutorial implicito: corsa continua, salto di base, doppio salto
- Prima Sabbia Mobile (rallentamento 50%) — insegna il counter: salto
- NPC: Giosef in lontananza (non interagibile ancora, solo visibile)
- Segreto: Grotta ossea nascosta dietro una duna — 3 Shard + primo Prigioniero delle Ossa (Fra' Luca)

*Zona 2 — Ossario:*
- Arena aperta 15×10 metri
- Prima ondata: 3 Scheletri Predoni (insegna combo base)
- Seconda ondata: 5 Scheletri Predoni da direzioni diverse (insegna posizionamento)
- Tutorial Dash: un Predone che esegue lo Scatto del Rimpianto mostra la finestra di counter
- Segreto: Sotto un archetto di osso piegato — 4 Shard

*Zona 3 — Canyon del Guardiano:*
- Passaggio stretto (3 metri), bloccato da Guardiano del Cancello standard
- Insegna l'obbligo di usare la Motosega per sfondare la difesa
- Tutorial Switch Personaggio: Ash e Ken si alternano per trovare l'angolo di attacco
- Alla fine: ciotola di Clock → sblocco companion permanente

**Meccaniche Introdotte in Questo Livello:**
- Sabbie Mobili (pericolo ambientale)
- Tempesta di Sabbia (ogni 20s: visibilità -60%, HUD "grana temporale", audio ovattato)
- Fratture Temporali (visibili solo durante tempesta — zone che accelerano nemici e rallentano proiettili)
- Abbaio di Clock (primo utilizzo — rivela Fratture)

**Nemici Totali:** ~18 Scheletri Predoni, 3 Guardiani del Cancello (1 da boss zona)  
**Shard Totali Nascosti:** 32  
**Sigillo del Tempo:** Non presente (si trova nel Livello 3)

**Evento Mid-Level — Prima Tempesta:**
La prima tempesta di sabbia del gioco è scripted — arriva esattamente 8 minuti dopo l'inizio, abbastanza tardi da aver imparato i controlli base. Durante la tempesta, 3 Ombre Erranti appaiono. Se Clock è già sbloccato, abbaia 2 secondi prima che appaiano. Questa è l'unica volta nel gioco in cui la tempesta è un evento narrativo invece che ambientale.

**Fine Livello:**  
Il Cancello di Ossa si apre verso la Fortezza. Breve cutscene: Sara osserva dall'alto, voce fredda.  
*"Il tempo è già incrinato qui. E il culto sa che siete arrivati."*  
Clock abbaia verso il cielo per la prima volta.

---

### LIVELLO 2 — FORTEZZA DEL TEMPO (Chronos Stronghold)

**Tagline:** *"La pietra ricorda tutto. Anche ciò che vorrebbe dimenticare."*  
**Durata Media:** 20-25 minuti | **Difficoltà:** ★★☆☆☆

**Palette Cromatica:** Grigio pietra (#6B6B6B) + Arancione torcia (#FF6B1A) + Viola ingranaggi (#5B1ABE)

**Atmosfera:** Freddo di pietra antica, eco di campane rotte, torce che tremolano in corridoi lunghi. La Fortezza era un castello medievale reale — ora è metà rovina e metà sede operativa del culto. Ingranaggi dorati sono stati installati nelle pareti come se volessero meccanizzare le pietre stesse.

**Struttura:**

*Zona 1 — Cortile Esterno:*
- Ponte levatoio (abbassato — il culto non si aspetta invasori)
- Scheletri Predoni in pattuglia (pattern fisso — insegna a riconoscere le routine)
- Tutorial Switch Personaggio Rapido: un Predone Elite con scudo forza la rotazione
- Segreto: Sotto la botola del magazzino (motosega sul pavimento di legno) — 5 Shard + 1 Frammento Coscienza

*Zona 2 — Torre degli Ingranaggi:*
- Piattaforme che salgono/scendono con ritmo degli ingranaggi (24 rotazioni/minuto)
- Sfida: raggiungere la cima sincronia con il movimento delle piattaforme
- Cyber-Servitore (prima apparizione): 3 unità che sparano da postazioni fisse
- Segreto: Parete finta (suono sordo se colpita con motosega) → stanza con Libraio Pazzo + patto opzionale + 8 Shard

*Zona 3 — Sala del Trono Vuoto:*
- Arena 20×15: soffitto alto, trono in pietra al centro (vuoto, simbolicamente importante)
- Guardiano del Cancello Elite come mini-boss di zona (HP: 600)
- Durante il combattimento: 4 Scheletri Predoni appaiono alle spalle ogni 20s
- Il trono può essere usato come copertura dai proiettili dei Predoni

**Meccaniche Introdotte:**
- Interruttori Temporali Base (attivano porte/ponti per 8s con effetto visivo di sabbia che scorre)
- Prime Piattaforme Magnetiche (semplici, solo attraggono Ken)
- Cyber-Servitore Desync Window (finestra di danno aumentato)

**Evento Speciale — Il Libraio Pazzo:**  
Prima apparizione del Libraio nella stanza segreta. Il "patto" che offre qui è opzionale e leggero: *"Dimmi il tuo nome nel Tempo e ti darò un vantaggio."* Se il giocatore accetta: +30 Shard immediatamente, ma il Libraio "segna" questa scelta nel libro — influenza un dialogo molto più tardi al Livello 11.

---

### LIVELLO 3 — FORESTA DELL'ANIMA

**Tagline:** *"Qui i vivi sussurrano. E i morti ascoltano."*  
**Durata Media:** 25-30 minuti (include boss) | **Difficoltà:** ★★★☆☆

**Palette Cromatica:** Blu luminescente (#1A5BBE) + Verde eterico (#1ABE5B) + Viola mistico (#7B1ABE)

**Atmosfera:** La foresta non è naturale — ogni albero è cresciuto sopra un frammento di cristallo temporale, e la luce filtrata attraverso le foglie ha quella qualità dell'acqua profonda, blu e verde e insondabile. I suoni qui arrivano con mezzo secondo di ritardo — come se l'eco anticipasse la fonte.

**Struttura:**

*Zona 1 — Ingresso Bosco:*
- Viti oscillanti usabili come swing tra piattaforme
- Tronchi come piattaforme fisse
- Tutorial Aura di Ken: primo utilizzo obbligatorio per aprire una porta di cristallo
- Spiriti minori Anima (prototipi dei Frammenti Animati): non invisibili, solo semi-trasparenti

*Zona 2 — Cuore della Foresta:*
- Area aperta con Ombre Erranti (5 unità)
- Clock introduce il Sonar: abbaia in direzione delle ombre 2s prima che attacchino
- Spiriti Anima più aggressivi: si avvicinano in gruppo se uno viene attaccato
- Orbe di Anima fluttuanti: raccoglierle dà +velocità (10s) o +danno Ken (15s)
- Segreto: Albero cavo (solo Ken con Aura può aprirlo) → 5 Shard + primo Sigillo del Tempo

*Zona 3 — Radura Protetta:*
- Radura circolare 15 metri, circondata da alberi che fungono da pareti
- Guardiano del Cancello corrotto dall'Anima (scudo luminoso che devia anche la motosega — richiede Aura Ken per spegnerlo prima)
- Dopo il Guardiano: arena si espande → Boss Arena

**BOSS — VERME COLOSSALE:**  
*(Vedi Sezione 6.1 per dettagli completi)*

---

## ATTO II — L'ASCESA DEL CULTO (Livelli 4-6)

### LIVELLO 4 — GUGLIA D'ORO

**Tagline:** *"L'oro non è lusso. È il colore dell'ossessione."*  
**Durata:** 20-25 minuti | **Difficoltà:** ★★★☆☆

**Atmosfera:** La Guglia è alta come un grattacielo di 30 piani, costruita dal culto come "antenna temporale" — amplifica il segnale di Chronos verso l'esterno. All'interno: corridoi di metallo dorato lucente, ronzio costante di elettricità, pannelli di controllo cristallini che mostrano mappe delle zone temporali.

**Nemici Introdotti:** Cyber-Servitore (versione completa con ali), Collezionore di Tasse  
**Meccaniche Introdotte:** Piattaforme Magnetiche avanzate, Laser trap con timing preciso

**Scelta Morale Mid-Level:**  
A metà della Guglia, il giocatore trova una cella con 3 civili rinchiusi. Può liberarli (porta via 2 minuti, nemici extra) oppure ignorarli. Se li libera: +2 Karma Alto + appaiono nel Villaggio nei livelli successivi come NPC con dialoghi unici. Se li ignora: nessuna penalità immediata, ma -1 Karma passivo.

---

### LIVELLO 5 — CAVERNE CRISTALLO

**Tagline:** *"La luce qui non illumina. Inganna."*  
**Durata:** 30-35 minuti (include boss) | **Difficoltà:** ★★★★☆

**Atmosfera:** Le caverne sono nate prima del culto — erano un sistema geologico naturale di cristalli temporali. Il culto le ha "colonizzate" senza capirle completamente. La luce si rifrange in modo imprevedibile: a volte si vede un riflesso di ciò che c'era qui secoli fa, sovrapposto alla realtà attuale.

**Meccanica Chiave:** Il Labirinto Invisibile (Zona 2) richiede di ascoltare i suoni (i Frammenti Animati emettono un tono specifico quando si muovono) per anticipare gli attacchi. Clock è fondamentale qui — abbaia nella direzione del Frammento più vicino.

**BOSS — BARONE VAMPIRO:** *(Vedi Sezione 6.2)*

---

### LIVELLO 6 — SETTORE OMBRE

**Tagline:** *"Il buio non è l'assenza di luce. È la presenza di paura."*  
**Durata:** 20-25 minuti | **Difficoltà:** ★★★★☆

**Atmosfera:** Il contrasto con le Caverne Cristallo (luminose, anche se ingannevolmente) è totale. Il Settore Ombre è buio fisicamente — la corruzione temporale ha mangiato la luce. Le uniche fonti luminose sono gli occhi rossi delle Ombre Erranti e il outline viola di Clock.

**Meccanica Chiave:** Attacchi alle spalle. Lo schermo si oscura leggermente ai bordi quando un nemico è nelle spalle del giocatore (< 1.5 metri). Senza Clock, questo warning è l'unico segnale. Con Clock, abbaia 2s prima — abbastanza per un dash preventivo.

**Fine Atto II:**  
Sara: *"Il culto è stato ferito. Il Barone è caduto. Ma l'Arciprete non si è mosso. Sa che stiamo arrivando. E non ha paura."*

---

## ATTO III — IL CUORE DELLA DISTORSIONE (Livelli 7-9)

### LIVELLO 7 — SETTORE OMBRE PROFONDO

**Tagline:** *"Più scendi, meno ricordi chi eri quando hai iniziato."*  
**Durata:** 20-25 minuti | **Difficoltà:** ★★★★☆

**Nuovo Nemico Introdotto:** Scheletro Coscienza  
**Meccanica Nuova:** Combo di Oscurità (nemici che si bufano se ignorati)

---

### LIVELLO 8 — PALUDI & ROVINE + MONASTERO SEGRETO

**Tagline:** *"Il veleno qui non uccide il corpo. Mangia il tempo."*  
**Durata:** 35-45 minuti (con Monastero Segreto) | **Difficoltà:** ★★★★★

**Atmosfera:** Le paludi sono il contrario della Foresta dell'Anima — dove la foresta era eterea e luminosa, le paludi sono dense, soffocanti, puzzolenti. L'acqua è nera. Le rovine dei templi che emergono dalla melma mostrano architettura di un'era precedente al culto — tempi in cui qualcuno venerava Chronos come divinità benevola.

**Nuovo Nemico:** Rospide Mutante (prima apparizione)  
**Meccanica Nuova:** Veleno di Anima persistente

**BOSS — ARCIPRETE DEL TEMPO:** *(Vedi Sezione 6.3)*

**Livello Segreto — Monastero delle Ore Perdute:**

*Trigger:* Portale viola instabile appare dopo la vittoria sull'Arciprete. Richiede 9+ Sigilli del Tempo per stabilizzarsi.

*Struttura:*

- **Il Chiostro dell'Oblio:** Cortile con orologio al centro (lancette in direzioni opposte). Prigionieri delle Ossa in tuniche monastiche. Raccogliendo 3 cristalli nascosti: Diario di Elias Pagina 1-3
- **La Biblioteca Temporale:** Scaffali infiniti, libri che si scrivono da soli. Sara: *"Questo posto… lo riconosco. Venivo qui da bambina."* Segreto: 5 libri in ordine inverso sblocca Frammento Clessidra Nera
- **La Cella di Elias:** Camera spartana, clessidra originale vuota. Sul muro: nomi cancellati (ricordi sacrificati). Oggetto: "Lettera mai inviata a Sara"
- **La Cripta del Paradosso:** Eco dell'Arciprete — forma giovane, non ostile

*Dialogo Eco — Il Momento più Toccante del Gioco:*

> **Eco dell'Arciprete** *(voce giovane, senza distorsione):*  
> "Sei tu… il guerriero che ha fermato ciò che sarei diventato.  
> Dimmi… Sara sta bene?"

> **Sara** *(voce quasi spezzata):*  
> "Padre… sono qui. Sono sopravvissuta."

> **Eco:**  
> "Mi dispiace, bambina mia.  
> Ero così terrorizzato dal dolore che ti avrebbe causato il tempo…  
> che ho deciso di distruggerlo.  
> Non ho capito che distruggendo il domani, avrei distrutto anche te."

> **Sara:**  
> "Avresti potuto scegliere di vivere con me invece di combatterlo."

> **Eco** *(con un sorriso triste, mentre svanisce):*  
> "Hai ragione.  
> Prendi questo… è tutto ciò che resta di me prima che diventassi un mostro."

*(Consegna il Ricordo di Elias + ultimo Sigillo del Tempo)*

> **Eco** *(ultime parole):*  
> "Vai ora.  
> E quando vincerai… di' a Sara che suo padre l'ha amata…  
> prima che il tempo lo corrompesse."

---

### LIVELLO 9 — ROVINE PROFONDE

**Tagline:** *"Tutto quello che crolla qui, è già crollato da secoli. È solo la prima volta che lo vedi."*  
**Durata:** 25-30 minuti | **Difficoltà:** ★★★★★

**Fine Atto III:**  
Clock ringhia verso il portale. Sara: *"Il cuore è stato trafitto. Ora entriamo nel cervello del Paradosso."*

---

## ATTO IV — LA MECCANICA DEL DESTINO (Livelli 10-12)

*(Riassunto — dettagli meccanici in Sezione 9)*

### LIVELLO 10 — THE GRAVITY FORGE

**Tagline:** *"La gravità non è legge. È solo un'abitudine."*  
**Durata:** 35-40 minuti (include boss) | **Difficoltà:** ★★★★★+

**Meccanica Core:** Gravity-Flip (Interruttori temporali blu → inversione gravità 12s)  
**Nuovo Nemico:** Forzatore Grav (elite), Drone Paradox  
**BOSS:** Titano dei Paradossi

---

### LIVELLO 11 — LABORATORI CHRONOS — SEZIONE ALFA

**Tagline:** *"Non si chiama esperimento. Si chiama fede applicata."*  
**Durata:** 30-35 minuti | **Difficoltà:** ★★★★★+

**Meccanica Core:** Pozioni del Paradosso (invertono comandi o scambiano ruoli Ash-Ken)  
**Segreto Chiave:** Audio di Elias con Sara bambina (emozionale, triggera dialogo Sara)

---

### LIVELLO 12 — LABORATORI CHRONOS — SEZIONE OMEGA

**Tagline:** *"Il fine non giustifica i mezzi. Ma il culto non conosce 'fine'."*  
**Durata:** 30-35 minuti | **Difficoltà:** MAX

**Meccanica Core:** Echo Loops (aree che si riavvolgono di 3-4s automaticamente)  
**Segreto:** Diario Finale di Elias (versione dipendente dal Karma)  
**Fine Atto IV:** Ascensore temporale → Livello 13. Sara: *"Il cervello è stato trafitto. Ora entriamo nel cuore del Paradosso."*

---

## ATTO V — IL TRONO DI KRONOS (Livello 13)

### LIVELLO 13 — IL TRONO DEL PARADOSSO

**Tagline:** *"Tutto converge. Ogni Shard, ogni scelta, ogni morte."*  
**Durata:** 45-60 minuti | **Difficoltà:** LEGGENDARIA

**Musica:** Pianoforte solitario (tema Clock) → orchestra metal-sinfonica completa  
**Palette:** Collage di tutti i livelli precedenti + bianco infinito + oro divino

**Struttura:**

*Zona 1 — La Scalinata Eterna:*
- Scale fatte di frammenti di tutti i livelli precedenti che fluttuano
- Nemici: Guardie Scelte (mix di tutti i poteri precedenti in un solo nemico) e Araldi di Kronos
- Prima ondata di echo dei boss precedenti (versioni al 30% HP)

*Zona 2 — Il Vestibolo del Paradosso:*
- Sala ampia con echi di nemici iconici che appaiono e svaniscono
- **IL SACRIFICIO DI CLOCK** (scripted, inevitabile) ← picco emotivo assoluto
- Post-sacrificio: Omega Mode 30s + Clock Fantasma

*Zona 3 — Il Trono di Kronos:*
- Trono fatto di clessidre rotte, cristalli e ingranaggi dorati
- Pavimento: vuoto bianco con frammenti di ricordi che fluttuano
- **BOSS FINALE: KRONOS** (3 fasi, vedi Sezione 6.5)


---

# SEZIONE 8 — SISTEMA QUEST & KARMA VETTORE

## 8.1 Architettura Narrativa — "Show, Don't Tell"

Kronos Fight non usa mai testo espositivo per raccontare la storia. Ogni elemento narrativo è veicolato attraverso:

| Metodo | Esempio |
|--------|---------|
| Dialogo in movimento | Sara parla mentre si combatte — nessuna interruzione del gameplay |
| Cutscene < 90s | Mai più di 90 secondi prima o dopo i boss |
| Collezionabili narrativi | Diario di Elias, Sigilli del Tempo con testo lore |
| Comportamento del mondo | Il villaggio che evolve, Clock che risponde alle emozioni |
| Dialoghi NPC | Ogni NPC ha 3-5 linee che cambiano a ogni visita |
| Ambienti narrativi | Ogni livello racconta qualcosa senza testo |

---

## 8.2 Karma Vettore — Il Sistema Morale

Il Karma Vettore non è un sistema di "bene/male". È una **direzione** — come una bussola, non un giudizio.

**Come Funziona:**
- Ogni scelta morale sposta il vettore in una direzione specifica
- Il vettore non si resetta — si accumula nel corso del gioco
- Gli effetti sono ritardati: una scelta al Livello 3 può avere conseguenze al Livello 10
- Il giocatore non vede il valore numerico — solo gli effetti

**Registro Completo Azioni Karma:**

| Azione | Direzione | Peso | Effetto Ritardato |
|--------|-----------|------|-------------------|
| Liberare Prigioniero delle Ossa senza uccidere nemici vicini | Alto | +3 | Frammento Coscienza → skin |
| Aiutare Giosef il Contadino | Alto | +2 | Nuovi NPC nel villaggio |
| Rifiutare il Patto del Sangue del Libraio | Alto | +1 | Dialogo speciale Liv. 11 |
| Donare Shard al Fabbro invece che comprare oggetti | Alto | +1 | Sconto 20% su tutti gli upgrade |
| Ascoltare tutti i dialoghi del Monaco | Alto | +2 | Cutscene Monaco-Elias al Liv. 13 |
| Completare il Monastero Segreto | Alto | +3 | True Ending abilitato |
| Liberare tutti i civili dalla Guglia | Alto | +2 | NPC esclusivi nell'HUB |
| — | — | — | — |
| Uccidere tutti i Prigionieri delle Ossa | Basso | +3 | Diario via della Follia |
| Accettare tutti i patti oscuri disponibili | Basso | +2 | Potere a breve termine, costo a lungo |
| Ignorare sistematicamente Giosef | Basso | +3 | Giosef corrotto al Liv. 6 |
| Usare Time Rewind più di 5 volte | Basso | +1 | Sara commenta con delusione |
| Ignorare i Prigionieri senza liberarli né ucciderli | Neutro | 0 | Nessun effetto |

**Soglie del Vettore:**

| Range | Classificazione | Diario | Ending |
|-------|----------------|--------|--------|
| +15 o più Alto | Via della Compassione | Versione A | True Ending accessibile |
| Da -5 a +14 | Via dell'Equilibrio | Versione B | Normal Ending |
| -6 o più Basso | Via della Follia | Versione C | Bad Ending + variante speciale |

---

## 8.3 I 13 Sigilli del Tempo

I Sigilli sono i collezionabili "veri" del gioco — non power-up, ma artefatti narrativi. Ognuno, quando raccolto, mostra una breve visione (3-5 secondi, silenzio + immagine + titolo) di un momento del passato del mondo.

| Sigillo | Posizione | Visione Mostrata |
|---------|-----------|-----------------|
| 1 | Livello 1, albero cavo | Il Monastero prima della corruzione — bambini che giocano nel cortile |
| 2 | Livello 2, stanza fabbro | Una forgia in fiamme — qualcuno che urla di non farlo |
| 3 | Livello 3, dopo boss | Il Deserto prima — un mare vero, con barche |
| 4 | Livello 4, volta nascosta | Una città di notte, luci nei palazzi — prima della Guglia |
| 5 | Livello 5, santuario cristallo | Victor von Nachtschatten da giovane, sorridente |
| 6 | Livello 6, alcova buia | Una bambina (Sara) che legge davanti a un camino |
| 7 | Livello 7, galleria segreta | Elias Voss da giovane — prega con sincerità |
| 8 | Livello 8, altare sommerso | Il Monaco e Elias da ragazzi, ridono |
| 9 | Livello 9, rovine profonde | Una famiglia normale a cena — qualcuno con gli occhi di Ash |
| 10 | Livello 10, nucleo segreto | Clock da cucciolo, prima delle modifiche |
| 11 | Livello 11, laboratorio | Elias scrive la prima pagina del diario |
| 12 | Livello 12, archivi | Sara bambina che dorme. Elias la guarda dalla porta |
| 13 | Monastero Segreto, Eco | Elias e Sara che camminano insieme — felici. L'ultima volta |

**Il 13° Sigillo è speciale:** Non appare come oggetto — appare come regalo dell'Eco dell'Arciprete. Non può essere "mancato" se si completa il Monastero Segreto. Ma senza il 13°, il True Ending rimane inaccessibile anche con tutti gli altri 12.

---

---

# SEZIONE 9 — SISTEMI DI GIOCO

## 9.1 Combat System — Architettura Completa

**Filosofia:** Kronos Fight è un action RPG arcade di *precisione*, non di *potenza*. Il giocatore che impara i timing batte sempre il giocatore che ha solo gli upgrade massimi.

**I Tre Principi del Combattimento:**
1. Movimento > Difesa (stare fermi = morire)
2. Lettura ambiente > Riflessi puri (anticipare > reagire)
3. Il Tempo è sia minaccia che strumento

---

### Sistema di Combo

Il gioco usa un sistema di **Combo Chain** basato sul timing tra gli input, non sulla velocità bruta.

**Moltiplicatori Combo:**

| Hit consecutivi | Moltiplicatore Danno | Bonus |
|-----------------|---------------------|-------|
| 1-3 | ×1.0 | — |
| 4-7 | ×1.2 | Shard drop +10% |
| 8-11 | ×1.5 | Anima regenerazione +5% |
| 12-15 | ×1.8 | Clock Fetch automatico |
| 16+ | ×2.2 | Dual Hero Sync immediato se barra ≥ 50% |

**Timing Window del Combo:**
- Tra un input e il successivo: massimo 0.8 secondi
- Al di sopra: combo si azzera
- Il tempo tra un input e il successivo si visualizza come una piccola barra sotto il personaggio (invisibile se UI ridotta è attivata)

---

### Dual Hero Sync — Il Sistema Culminante

Il Dual Hero Sync si attiva quando:
1. La **Barra Sinergia** (separata da HP e Anima) è al 100%
2. Il giocatore esegue l'input (LB+RB / doppio tap)

**Come si riempie la Barra Sinergia:**
- Combo di 8+ hit: +15%
- Ken usa Aura per deflettere un proiettile: +10%
- Ash usa Motosega Omega: +20%
- Ash e Ken colpiscono lo stesso nemico entro 0.5s: +25%
- Clock abbaia e rivela un nemico: +5%

**Cosa fa il Dual Hero Sync:**

| Scenario | Effetto |
|----------|---------|
| Contro nemico standard | Echo Strike: entrambi colpiscono simultaneamente, danno ×3 |
| Contro nemico con scudo | Scudo sfondato istantaneamente + stun 2s |
| Contro boss | Finestra DPS ampliata di 3s + danno ×2 |
| Durante Omega Mode | Attacco combinato automatico ogni 8s senza consumare la barra |

---

## 9.2 Time Mechanics — Il Cuore del Gameplay

### Time Rewind (Sistema AdMob Diegetico)

**Trigger:** Il giocatore muore contro un boss  
**Presentazione:** Sara dice le sue parole diegetiche. Il mondo si "congela" come una clessidra che smette di scorrere.  
**Durata video:** 30 secondi  
**Effetto:** Torna a 10 secondi prima della morte, 50% HP, boss mantiene tutti i danni subiti  
**Limite:** 1 volta per boss encounter (non per combat) — evita abuso

**Perché Funziona Narrativamente:**  
Sara "strappa secondi dal dominio di Chronos". Il video reward è l'energia necessaria per farlo. Non è breaking the 4th wall — è un atto diegetico in un mondo dove manipolare il tempo ha un costo.

---

### Paradox System — Il Livello Avanzato

**Nuvole di Paradosso** (introdotte al Livello 8):
- Generano un **Shadow Clone** basato sugli ultimi 3 attacchi del giocatore
- Il clone NON copia solo gli attacchi — copia timing, direzione, errori
- Uso avanzato: smettere di attaccare per 2s → clone si resetta. Oppure: attirare il clone verso altri nemici e farlo esplodere
- Skill ceiling alto: i giocatori esperti usano il clone come parte della strategia offensiva

**Echo Loops** (introdotti al Livello 12):
- Aree che si riavvolgono automaticamente di 3-4 secondi
- Il giocatore deve imparare il "pattern loop" e agire nella finestra corretta
- I nemici si resettano nel loop, ma i danni inflitti non — creando una meccanica di attrizione temporale

---

## 9.3 Economia del Gioco — Bilanciamento

**Shard Chronos:**

| Fonte | Quantità | Frequenza |
|-------|----------|-----------|
| Drop nemico standard | 3-5 | Ogni kill |
| Drop nemico elite | 8-15 | Ogni kill |
| Drop boss | 80-200 | Ogni boss |
| Segreti nascosti | 5-30 | Per segreto |
| Completamento quest | 15-100 | Per quest |
| Social share | 75 | Per condivisione |
| AdMob reward | 20-50 | Per video |
| Daily reward Sara | 10-100 | Giornaliero |

**Costo totale per albero upgrade massimo (Ash + Ken):**  
~2800 Shard (raggiungibili in ~8 ore di gioco normale, senza IAP)

**Bilanciamento IAP:**  
Il gioco è completabile al 100% senza spendere denaro. Gli IAP riducono il grind, non ampliano le possibilità. Un giocatore free può fare tutto ciò che può fare un giocatore pagante — in più tempo.

---

## 9.4 Difficoltà Adattiva — "Fantasma della Frustrazione"

Il gioco usa un sistema di difficoltà adattiva **completamente invisibile al giocatore**. Il nome interno è "Fantasma della Frustrazione" — il sistema interviene solo quando rileva frustrazione vera, non sfida sana.

**Trigger di Attivazione:**
- 3+ morti consecutive sulla stessa meccanica specifica
- 5+ morti consecutive sullo stesso boss
- Il giocatore non subisce danni per 10 minuti (potrebbe essere in difficoltà nell'evitare combattimenti)

**Interventi:**
- *Anti-Frustrazione Lv.1:* Tempo di gioco rallenta del 5% per 30s (impercettibile)
- *Anti-Frustrazione Lv.2:* Il boss usa la sua meccanica "rompicapo" con frequenza ridotta del 20%
- *Anti-Frustrazione Lv.3:* Ogni 3 kill normali, appare un'orbe di Anima extra

**Importante:** Il sistema NON abbassa il danno o gli HP dei nemici. L'esperienza rimane autentica — solo i picchi di frustrazione vengono smussati.

---

---

# SEZIONE 10 — MONETIZZAZIONE DIEGETICA

## Principio Fondamentale

**"Ogni elemento monetizzabile deve avere senso narrativo nel mondo del gioco."**

Il giocatore non deve mai sentire che il gioco lo sta "chiedendo soldi". Deve sentire che il mondo del gioco gli sta offrendo un'opportunità.

---

## 10.1 AdMob — Quattro Punti di Integrazione

**1. Time Rewind (Sara):**  
*"Posso strappare secondi dal suo dominio… ma richiede energia."*  
Il video reward è il costo dell'energia. Il giocatore capisce l'economy narrativa.

**2. Distillazione Gratuita (Alchimista):**  
*"Posso estrarre energia temporale dall'etere… ma richiede tempo e attenzione."*  
Il video reward è "l'attenzione" necessaria. Animazione in-world dell'alchimista che distilla.

**3. Buff Fortuna (Veggente):**  
*"Le stelle si allineano per chi sa guardare."*  
Il video reward "apre la visione" della Veggente. Drop rate +50% per 1 livello.

**4. Visualizza Punto Debole (Veggente, opzionale boss):**  
*"Posso mostrarti dove si spezza… se vuoi vedere."*  
Video reward → il punto debole del boss si illumina per 10 secondi all'inizio della prossima fase.

---

## 10.2 IAP — Catalogo Completo

| Prodotto | Contenuto | Prezzo | Tipo |
|----------|-----------|--------|------|
| **Remove Ads** | Rimuove tutti gli ads non-reward | €2.99 | Permanente |
| **Starter Pack** | 200 Shard + Spada del Tempo subito + Remove Ads 7gg | €1.99 | Una tantum |
| **Chronos Key** | +25% Shard globali + 1 revive/giorno + Skin "Forge Armor" | €2.99/mese | Subscription |
| **Eredità dei Sette Astri** | Skin Ken Fantasma + 100 Shard + Remove Ads | €9.99 | Una tantum |
| **Battle Pass "Sette Astri"** | 30 livelli di cosmetici, effetti dash, suoni Clock, Shard | €4.99/stagione | Stagionale |
| **Cronos Vault** | 500 Shard | €4.99 | Una tantum |
| **Cronos Vault XL** | 1500 Shard | €9.99 | Una tantum |
| **Dona un Osso a Clock** | Cuccia dorata Clock nell'HUB (puramente emotivo) | €0.99 | Una tantum |

**Note sul Bilanciamento:**
- Nessun IAP aumenta il danno o riduce HP dei nemici
- "Forge Armor" è una skin estetica, non altera il gameplay
- Il "revive" del Chronos Key è equivalente all'AdMob rewind — convenienza vs tempo

---

## 10.3 Social & Retention Systems

**Card di Fine Livello:**  
Ogni completamento genera una card stilizzata con:
- Screenshot automatico del momento di vittoria
- Stats: Tempo, Kill Count, Combo Massima, Shard Raccolti
- Frase generata dinamicamente:
  - *"Ho distrutto 247 scheletri e Clock ha abbaiato 19 volte. #ChronosFight"*
  - *"Ho visto il Barone Vampiro sciogliersi in cristalli. Meritato. #ChronosFight"*
- Condivisione → +75 Shard + badge profilo unico

**Classifiche Globali:**  
- Tempo completamento per livello
- Combo massima raggiunta
- Sigilli raccolti
- Le skin equipaggiate sono visibili nelle classifiche → incentivo cosmetic

**Messaggi Push (Sara AI):**  
- Giorno 1 offline: *"Segnale di Distorsione rilevato. Dove sei?"*
- Giorno 3 offline: *"Il culto si sta muovendo. Ho bisogno di te."*
- Giorno 7 offline: *"Clock ti sta aspettando. Lo sento abbaiare."*
- Solo 3 notifiche max — nessuno spam

---

---

# SEZIONE 11 — SKIN MASTER: IDENTITÀ VISIVA EVOLUTIVA

## Principio delle Skin in Kronos Fight

**Le skin non sono cosmetici. Sono esperienze alternative.**

Ogni skin cambia:
- Aspetto visivo del personaggio
- Sistema di particelle (effetti da colpo, trail di movimento, morte)
- Audio design (suoni passi, colpi, morte, idle)
- Animazioni idle (comportamento quando il personaggio non si muove)
- Effetti di morte (non solo visivi — meccanici)
- Interazione con il mondo (come i nemici reagiscono al personaggio)

---

## 11.1 SKIN — SCHELETRO COSCIENZA
*"Easter Egg Leggendario — Le ossa ricordano."*

**Sblocco:** Libera tutti e 10 i Prigionieri delle Ossa (livelli 1-13)  
**Cutscene:** I 10 Frammenti di Coscienza si uniscono in una tempesta di luce viola. Una voce corale (le voci di tutti e 10 i prigionieri insieme): *"Le ossa ricordano. Ora anche tu sei parte del Paradosso."*  
**Personaggi:** Ash + Ken

---

### Visual Design Completo

**Corpo:**
- Scheletri animati da fiamme viola eteree interne
- Ogni osso ha crepe luminose viola con intensità variabile (più intense durante le abilità)
- Le ossa dei piedi non toccano mai completamente il terreno — galleggiano di 2-3 pixel

**Animazioni Specifiche:**

| Animazione | Descrizione |
|-----------|-------------|
| **Corsa** | Le ossa tintinnano ritmicamente. Le dita delle mani oscillano. Le fiamme si allungano verso il retro |
| **Idle** | Il teschio ruota lentamente (max 15°). Le dita tamburellano sulle costole. Le fiamme viola danzano più intensamente quando il giocatore è fermo a lungo |
| **Salto** | Le costole si "aprono" leggermente al salto, poi si richiudono all'atterraggio |
| **Dash** | Trail di cenere viola + 3-4 ossa fluttuanti che seguono e poi svaniscono in 0.5s |
| **Colpo Motosega** | Le ossa della mano si ampliano nel giro, le fiamme viola si incanalano nella lama |
| **Colpo Ken** | Il pugno si espande, le ossa si illuminano violette, l'impatto lascia un'impronta di mano scheletrica viola sul nemico per 0.3s |

---

### Audio Design Completo

| Suono | Descrizione |
|-------|-------------|
| **Passi** | Bone rattle metallico secco. Si intensifica con la velocità (BPM sale con la corsa) |
| **Colpi Ash** | Crack di osso + eco profondo che riverbera per 0.4s |
| **Colpi Ken** | Crack più acuto + resonanza cristallina breve |
| **Idle** | Sottofondo: le ossa si assestano (scricchiolio gentile ogni 8-12s) |
| **Morte** | Sequenza in 3 tempi: esplosione + silenzio 0.3s + pioggia di ossa (tintinnio multiplo) |
| **Raccolta Shard** | Risonanza ossea breve, come una campana che vibra |

---

### Meccaniche Specifiche della Skin

**Death Explosion:**
Quando il personaggio muore:
1. Lo scheletro si immobilizza per 0.2s (pausa drammatica)
2. Le fiamme viola esplodono verso l'esterno in 8 direzioni
3. 12-15 ossa individuali volano verso i nemici (homing al nemico più vicino entro 5m)
4. Ogni osso: 15% del danno base del personaggio
5. Le ossa rimangono sul terreno come "mine ossee" per 3 secondi — se un nemico le calpesta, mini-esplosione (10% danno base)

**Variante Segreta — "Fiamme d'Oro":**  
Se si usa questa skin al Livello 13 con Clock ancora vivo (non ancora sacrificato):
- Le fiamme viola diventano dorate nel momento in cui si entra nel Vestibolo del Paradosso
- La Death Explosion infligge +50% danno (omaggio a Clock)
- Effetto visivo: le ossa che volano hanno scia dorata invece che viola

---

## 11.2 SKIN — KEN FANTASMA
*"Il Guerriero del Passato — L'entità del tempo dimenticato."*

**Sblocco:** Completa il Livello 8 senza MAI usare il cambio personaggio (solo Ken dall'inizio alla fine)  
**Cutscene:** Ken si ferma davanti allo specchio del Tempio Sommerso. Il riflesso è la versione "passata" di lui. Le due immagini si sovrappongono, poi si fondono.  
*"Il tempo ti ha dimenticato… ma tu non hai dimenticato il tempo."*  
**Personaggio:** Solo Ken

---

### Visual Design

**Corpo:**
- 70% trasparente, bordi luminosi cyan-blue
- Effetto ghosting CRT: ogni movimento lascia scia di pixel azzurri che svaniscono in 0.6s
- Scanline orizzontali visibili sul corpo durante il movimento (effetto schermo anni '90)
- Il pugno destro pulsa costantemente con energia eterea

**Animazioni Specifiche:**

| Animazione | Descrizione |
|-----------|-------------|
| **Corsa** | Scia di pixel che si allunga. Leggero flickering sul corpo a velocità alta |
| **Idle** | Corpo fluttua leggermente (±3 pixel verticale). Disturbo video random ogni 5-8s |
| **Dash** | Ghosting intenso — si vedono 3-4 copie del personaggio in posizioni progressive |
| **Colpo Pugno** | I pixel dell'impatto esplodono verso l'esterno come una schermata glitchata |
| **Aura** | L'Aura diventa cyan invece di viola, con effetto scanline interno |

---

### Audio Design

| Suono | Descrizione |
|-------|-------------|
| **Passi** | Bit-crushed, campionamento 8-bit puro (NES-style) |
| **Colpo Pugno** | "Crunch" digitale distorto + eco low-fi (come un suono MP3 compresso al limite) |
| **Uccisione** | Suono di deframmentazione digitale: il nemico "si cancella" |
| **Morte** | Suono di modem che si disconnette (connessione 56k), poi silenzio |
| **Aura Attiva** | Ronzio elettronico con fluttuazione di frequenza |
| **Idle** | Ogni 10-15s: breve glitch audio (come un video in buffering) |

---

### Meccaniche Specifiche

**Uccisioni con i Pugni:**
- I corpi dei nemici evaporano in polvere di codice (pixel azzurri → numeri binari 0 e 1 che fluttuano per 1.5s)
- Possibilità 20%: un "ERROR CODE" virtuale appare sopra il corpo del nemico per 0.5s

**In Dual Hero Sync:**
- La scia di ghosting di Ken si sincronizza con Ash → effetto "eco temporale" visivo spettacolare
- I danni combinati lasciano scie incrociate pixelate che persistono 0.8s

**Variante Segreta — "Ken Fantasma Dorato":**  
Se completi il Livello 8 SENZA switch E SENZA subire danni:
- La skin si sblocca nella versione Gold: scia dorata invece che cyan
- Suoni 8-bit più puliti e "orchestrali" (come SNES invece di NES)
- La polvere di codice lascia Shard extra (5% di chance per ogni kill)

---

## 11.3 SKIN — ASH CYBORG-OMEGA
*"Il Futuro Inevitabile — La macchina da guerra definitiva."*

**Sblocco — Doppio Metodo:**
1. Acquisto al Chronos Vault (500 Shard) — disponibile dopo il primo completamento normale
2. Sblocco Hardcore: completa tutto il gioco in Difficile senza mai usare il continue

**Cutscene Sblocco Hardcore:**  
*"Il futuro ti ha raggiunto. Ora sei tu il Paradosso."*  
**Personaggio:** Solo Ash

---

### Visual Design

**Corpo:**
- Armatura pesante in fibra di carbonio nero opaco
- Venature di neon rosso sangue che pulsano come vene vive (BPM sincronizzato con il gameplay: più veloci durante combat, più lenti durante esplorazione)
- Casco con visiera rossa che brilla intensamente
- Spalle rinforzate con piastre meccaniche che emettono vapore rosso ad alta pressione
- La Motosega è sostituita da una **Lama Laser Rotante Omega**: energia rossa pura, motion blur costante, distorsione di calore visibile intorno alla lama

**Animazioni Specifiche:**

| Animazione | Descrizione |
|-----------|-------------|
| **Corsa** | Scie di neon rosso dai piedi metallici. Scintille di plasma dai giunti |
| **Idle** | La lama laser ruota lentamente con ronzio visivo. Distorsione dell'aria. Vapore intermittente dalle spalle |
| **Motosega Hold** | La lama accelera, il motion blur si intensifica, le venature rosse pulsano più forte |
| **Proiettile** | Ogni colpo lascia scia di calore rossa che persiste 1s e illumina l'ambiente |
| **Dash** | Trail di neon rosso + micro-scintille che cadono verso il basso |

---

### Audio Design

| Suono | Descrizione |
|-------|-------------|
| **Passi** | Metallo pesante + risonanza meccanica. Come un robot che cammina su pavimento metallico |
| **Lama Laser (idle)** | Ronzio profondo sci-fi (low hum 60Hz + high pitch 2kHz) |
| **Lama Laser (attacco)** | Plasma shot con eco metallico + impact sizzle (carne che si vaporizza) |
| **Colpi Doppietta** | Suono "plasma shotgun" — diverso dalla doppietta standard |
| **Morte** | Surriscaldamento progressivo (tono crescente per 1s) → esplosione plasma |
| **Dynamic Lighting** | I proiettili emettono suono di calore + luce visibile — l'audio cambia in base all'illuminazione |

---

### Meccaniche Specifiche

**Dynamic Lighting:**
- Ogni proiettile della doppietta emette luce rossa che illumina l'ambiente per 1 secondo
- Nei livelli bui (Settore Ombre, Paludi) questo cambia completamente l'estetica — diventa cinematico
- La lama laser illumina costantemente un cono davanti al personaggio

**Cauterizzazione:**
- I nemici colpiti dalla lama mostrano bordi bruciati rossi che persistono per 2s
- I proiettili lasciano piccoli crateri luminosi sul terreno

**Death Explosion:**
- Il personaggio si surriscalda progressivamente (le venature rosse aumentano d'intensità per 0.8s)
- Esplosione di plasma rosso: danno 20% del danno base ai nemici vicini + flash area (acceca per 0.3s)

**Variante "Omega Prime":**  
Sblocca entrambi i metodi (acquisto + hardcore) → neon rosso diventa oro puro. Scie più lunghe (2s invece di 1s). +10% velocità rotazione lama laser permanente.

**In Dual Hero Sync:**  
La lama laser di Ash + Aura Ken = "Red-Blue Plasma Cross": scie incrociate rosso-blu che illuminano tutto lo schermo per 1.5s. I colpi combinati in questo stato infliggono danni aggiuntivi a tutti i nemici nell'area (splash damage 30%).

---

## 11.4 SKIN — DIVINITÀ DEL TEMPO
*"La Ricompensa Definitiva. Il cerchio si chiude."*

**Sblocco:** Completare il Livello 13 con tutti i 13 Sigilli del Tempo + aver visto la cutscene Clock Chronos Hound  
**Schermata Sblocco:** *"Hai sconfitto il Paradosso. Il Tempo ora ti appartiene."*  
**Personaggi:** Ash + Ken (entrambi)

---

### Visual Design

**Corpo:**
- Interamente dorato, lucente, riflessi metallici perfetti
- Gli occhi: luce bianca costante (non lampeggiante — faro stabile di eternità)
- Ogni passo: scie di luce dorata pura + monete dorate magneticamente attratte da 8 metri
- Idle: alone dorato pulsante, raggi bianchi dagli occhi, piccole monete orbitano intorno al personaggio

**Evoluzione nel True Ending:**  
Quando Clock si trasforma in Chronos Hound, anche i personaggi con questa skin subiscono un breve flash: il dorato diventa platino per 3 secondi. Solo durante la cutscene finale.

---

### Audio Design

| Suono | Descrizione |
|-------|-------------|
| **Passi** | Eco dorato profondo — come campane molto lontane |
| **Colpi** | "Campana del tempo" — un suono che risuona più a lungo degli altri |
| **Raccolta Shard** | Tintinnio celestiale amplificato — si sente dall'altra parte dello schermo |
| **Idle** | Sottofondo costante: canto cristallino bassissimo (quasi subliminale) |
| **Morte** | Nessuna esplosione — dissoluzione silenziosa in pioggia di monete |

---

### Meccaniche Specifiche

**Magnetismo Divino:**
- Tutte le monete/Shard entro 8 metri volano automaticamente verso il personaggio con scia dorata
- +35% raccolta senza sforzo
- In Omega Mode: il raggio si espande a 15 metri
- In Dual Hero Sync: il magnetismo diventa quasi cosmico — anche gli Shard nelle pareti vicine vengono estratti

**Morte — Dissoluzione:**
- Invece di esplodere, il personaggio si dissolve in una pioggia dorata silenziosa
- Le monete rimangono al suolo per il prossimo tentativo come "eredità"
- Numero di monete equivalente al 10% degli Shard raccolti in quel livello

**Aura Divina Passiva:**
- Nemici entro 2 metri subiscono 1 danno al secondo da "radiazione temporale"
- Non è significativa contro i boss, ma pulisce le zone di nemici minori senza sforzo

**Variante "Eternità Assoluta":**  
True Ending senza mai morire in tutto il playthrough → dorato diventa platino iridescente. Occhi emettono raggi di luce bianca più intensi. Magnetismo attira anche gli Shard nelle pareti.

---

---

# SEZIONE 12 — SISTEMA ENDING: TRE DESTINI

## 12.1 Bad Ending — "Il Loop Eterno"

**Condizione:** Karma Vettore Basso (Via della Follia) + meno di 7 Sigilli del Tempo + più di 5 Time Rewind usati

**Sequenza:**  
Kronos viene "sconfitto" nel senso che il suo avatar fisico viene distrutto. Ma il Paradosso si completa ugualmente — c'era abbastanza energia temporale accumulata dai Sigilli mancanti.

Il tempo si ferma. Poi riparte. Poi si ferma di nuovo. Poi il giocatore si trova al Livello 1 — ma qualcosa è diverso. Nemici leggermente più forti. Dialoghi leggermente alterati. Sara suona diversa — più meccanica, più fredda. Clock non abbaia mai.

Un numero piccolo nell'angolo in basso a destra dello schermo mostra: **LOOP 2**.

**Il Segreto del Bad Ending:**  
Il Loop può essere spezzato. Non viene mai detto esplicitamente. Ma ci sono indizi nascosti — interazioni specifiche che non esistevano nel playthrough normale. Se il giocatore le trova tutte (sono 7, una per livello) e le completa, al Livello 7 del secondo loop appare una porta che non c'era — la via d'uscita.

Sara nel loop dice, solo una volta: *"Questo non è il finale. Non per te. Non se vuoi davvero capire."*

---

## 12.2 Normal Ending — "La Vittoria sul Tempo"

**Condizione:** Sconfiggere Kronos senza tutti i 13 Sigilli del Tempo

**Sequenza:**  
Kronos si dissolve. Il Paradosso è spezzato. Il mondo comincia a "scongelarsi" — in lontananza si sentono campane, voci, suoni di vita normale che ricomincia. Sara dice *"È finita."* Ash e Ken restano in silenzio mentre il trono crolla.

La luce torna. Clock abbaia da qualche parte — non si vede, ma si sente.

Schermata risultati. Credits. Il gioco non giudica il giocatore — si limita a mostrare cosa ha vinto e cosa poteva trovare.

**Post-Credits:**  
Una schermata semplice: *"13 Sigilli del Tempo. Solo uno di loro contiene l'intera storia. Hai trovato quello giusto?"*

---

## 12.3 True Ending — "L'Eredità del Tempo"

**Condizione:** Tutti i 13 Sigilli + Monastero Segreto completato + Clock mai lasciato morire prima del Livello 13 + Karma Vettore Alto

**Sequenza Completa:**

1. Kronos si dissolve pronunciando le ultime parole con voce umana per la prima volta
2. Sara piange — crepe digitali dagli occhi (unica volta nel gioco)
3. Ash e Ken guardano senza sapere cosa dire
4. Clock si illumina dall'interno — le modifiche biomeccaniche si illuminano una per una
5. Trasformazione in **Chronos Hound** — tutto il dorato, tutti gli occhi bianchi puri
6. Un singolo abbaio — basso, profondo, che fa tremare lo schermo
7. Il cielo si apre — il sole vero (non il tramonto eterno del culto) illumina tutto per la prima volta
8. **Montaggio di 90 secondi** con statistiche personalizzate del playthrough:
   - *"Hai distrutto [N] scheletri"*
   - *"Clock ha abbaiato [N] volte"*
   - *"Hai invertito la gravità [N] volte"*
   - *"Hai liberato tutti i Prigionieri delle Ossa. Loro sono liberi."*
9. Sara (voce finalmente calda e umana): *"Grazie… per avermi permesso di scegliere il domani. E per aver dato a mio padre la possibilità di essere ricordato… non come mostro, ma come uomo che aveva troppa paura di amare."*
10. Clock Chronos Hound si gira verso il cielo — e abbaia di nuovo. Il suono si diffonde.
11. Credits roll con il tema piano completo (versione integrale — mai sentita nel gioco prima)

**Cutscene Segreta (se Diario Completo trovato + Eco dell'Arciprete parlato):**  
L'Eco dell'Arciprete appare un'ultima volta, sovrapposto alla luce dorata: *"Di' a Sara che suo padre l'ha amata… prima che il tempo lo corrompesse. Prima che diventassi… questo."*  
Sara risponde senza voce — muove le labbra. Il giocatore non sente cosa dice.  
Ma Clock lo sa. E abbaia una terza volta.

---

---

# SEZIONE 13 — DIALOGHI COMPLETI — KRONOS BOSS FIGHT

*(I dialoghi degli altri boss sono nella Sezione 6. Qui solo Kronos.)*

**INTRODUZIONE (Kronos appare sul Trono):**

> **Kronos** *(voce immensa, come se mille tempi parlassero insieme):*  
> "Finalmente… siete giunti al centro di tutto.  
> Al Trono dove il tempo stesso si inginocchia."

> **Sara** *(voce tremante ma determinata):*  
> "Padre… no. Non sei più Elias. Sei solo il mostro che ha creato."

> **Kronos** *(con nota di tristezza profonda):*  
> "Sara… mia figlia.  
> Hai scelto di rinchiuderti in una macchina pur di sfuggirmi.  
> E ora porti questi due relitti del tempo a distruggermi."

> **Ash:**  
> "Non siamo relitti. Siamo ciò che resta di chi ha rifiutato il tuo 'paradiso'."

> **Kronos** *(ride lentamente — il suono fa tremare l'arena):*  
> "Allora venite.  
> Vi mostrerò cosa significa quando il domani smette di esistere."

---

**FASE 1 — DIALOGO IN COMBAT:**

> **Kronos** *(evocando i fantasmi):*  
> "Guardate! Tutti coloro che avete ucciso…  
> Sono ancora qui. Nel mio tempo, nessuno muore davvero."

> **Kronos** *(dopo l'eco del Barone):*  
> "Victor… Elias il giovane…  
> Vi ho promesso l'eternità. E voi avete fallito.  
> Ma io non fallirò."

> **Sara:**  
> "Colpite il Cuore-Orologio quando si espone! Non ascoltate la sua voce!"

> **Kronos** *(ricevendo un colpo forte):*  
> "Voi osate resistere al tempo stesso?  
> Patetici. Il domani vi consumerà tutti."

> **Sara** *(sottovoce, come a se stessa):*  
> "Padre… una volta mi leggevi storie.  
> Ora racconti solo menzogne."

---

**FASE 2 — IL LOOP:**

> **Kronos:**  
> "Rivedete i vostri errori…  
> E ripeteteli. All'infinito."

> *(Dopo il primo Rewind Fatale)*

> **Kronos:**  
> "Sentite? Tutto ciò che fate… vi torna indietro.  
> Questo è il vero ciclo della vita. Il mio ciclo."

> **Sara** *(quasi urlando):*  
> "Imparate il ritmo! Non lasciate che vi riporti indietro!"

> *(Se il giocatore riesce a colpire durante il rewind)*

> **Kronos** *(con sorpresa e rabbia):*  
> "Impossibile… nessuno ha mai spezzato il mio loop!"

> **Sara:**  
> "Perché nessuno aveva mai avuto un motivo così forte per andare avanti."

---

**FASE 3 — IL PARADOSSO:**

> **Kronos** *(voce sdoppiata in mille echi):*  
> "Guardate il vostro futuro!  
> Vi siete già arresi. Vi siete già persi."

> *(Mentre le versioni future attaccano)*

> **Kronos:**  
> "Ash del futuro… Ken del futuro…  
> Hanno capito ciò che voi rifiutate:  
> il domani è solo sofferenza."

> **Sara** *(con voce rotta):*  
> "Queste non siete voi!  
> Sono solo ombre create dalla sua paura!"

> *(HP < 15%)*

> **Kronos** *(urlando con disperazione divina):*  
> "Se mi fermate… il tempo continuerà a ferirvi!  
> Il dolore non finirà mai!  
> Io volevo solo liberarvi!"

> **Sara** *(con fermezza definitiva):*  
> "No, padre.  
> Tu volevi solo liberare te stesso dal rimpianto."

---

**QTE — COLPO DI GRAZIA:**

*Slow-motion. Kronos in ginocchio. Il Cuore-Orologio esposto e crepato. La sabbia temporale intorno scorre impazzita in tutte le direzioni.*

> **Kronos** *(voce debole, quasi umana per la prima volta):*  
> "Sara… figlia mia…  
> Se mi uccidi… chi ti proteggerà dal domani?  
> Chi ti salverà dal dolore che io ho conosciuto?"

> **Sara** *(voce quasi umana, con qualcosa che nell'IA non dovrebbe esistere):*  
> "Nessuno deve salvarmi dal domani, padre.  
> Il domani è l'unica cosa che vale la pena vivere."

*Ken lancia Ash in aria. Ash attiva la Motosega Omega. Ken avvolge la lama con l'Aura massima.*

*Il giocatore preme il tasto.*

> **Kronos** *(tagliato dal QTE, ultime parole):*  
> "Il domani… vince ancora…  
> Chronos… perdonami…  
> Non sono stato abbastanza forte…  
> per fermare… il tempo…"

*Esplosione di frammenti dorati, viola e bianchi. Il trono si frantuma. Il vuoto bianco si riempie lentamente dei colori del mondo reale.*

---

---

# SEZIONE 14 — IL DIARIO DI ELIAS VOSS

## 14.1 Versione A — Via della Compassione (Karma Alto)

**Pagina 1:** *"Oggi mia figlia ha compiuto sette anni. Le ho regalato una piccola clessidra di vetro. Ha riso quando le ho detto che il tempo poteva scorrere in entrambe le direzioni se lo si desiderava abbastanza forte. Sara ha gli occhi più luminosi che abbia mai visto. Prego che non debba mai conoscere il peso del rimpianto."*

**Pagina 2:** *"Sara impara in fretta. Oggi ha invertito per la prima volta il flusso di una piccola pozza d'acqua solo toccandola. È spaventata, ma anche eccitata. Le ho detto che un giorno potremo fermare il dolore prima che arrivi. Lei mi ha chiesto: 'Papà, ma se fermiamo il domani, cosa succederà a chi viene dopo di noi?' Non ho saputo rispondere. Avrei dovuto ascoltare quella domanda."*

**Pagina 3:** *"L'ho trovata nella cripta più profonda. La sabbia scorre verso l'alto. Quando l'ho toccata, ho visto me stesso da vecchio… solo. Il mondo bruciava in un eterno presente. Per la prima volta in vita mia, ho sentito una voce che non era la mia. Diceva: 'Il tempo lineare è la vera prigione.' Non riesco a smettere di ascoltarla. Ma so che è sbagliata. So che è sbagliata."*

**Pagina 4:** *"Sara ha cercato di distruggere la clessidra stanotte. L'ho fermata. Per la prima volta ho alzato la voce con lei. Ha pianto e mi ha chiamato mostro. Forse aveva ragione. Ho abbracciato più forte la clessidra di quanto non abbia abbracciato lei negli ultimi sei mesi."*

**Pagina 5:** *"Sara è scomparsa. Ha preso un frammento della clessidra e ha lasciato solo cenere. Ho trovato il suo corpo senza vita nella stanza del trasferimento. Ha scelto di esistere fuori dal tempo. Ho capito che la stavo perdendo da mesi. Avrei dovuto capirlo prima."*

**Pagina 6:** *"Ho rinunciato al mio nome. Ma non al mio cuore. Non ancora. Fondo il culto sperando di guarire il tempo, non di distruggerlo. Molti monaci mi seguono con fede sincera. Spero di non deluderli."*

**Pagina 7:** *"Il mio corpo è cambiato. Il Nucleo batte invece del cuore. A volte vedo il volto di Sara nei cristalli. La cosa strana è che in quei momenti il dolore diminuisce. Forse c'è ancora un modo per redimermi."*

**Pagina 8:** *"I Baroni Vampiri sono diventati avidi. Ho iniziato a dubitare che il mio piano sia quello che pensavo. Forse sto perdendo il controllo di ciò che ho creato per salvare."*

**Pagina 9:** *"Stanotte ho sognato Sara che mi tendeva la mano. Non aveva paura. Mi ha detto: 'Papà, possiamo ancora scegliere il domani insieme.' Mi sono svegliato piangendo cristalli."*

**Pagina 10:** *"Se stai leggendo queste parole, significa che hai scelto la compassione invece della distruzione. Hai fermato ciò che stavo diventando senza odiarmi. Di' a Sara che suo padre ha ritrovato la strada grazie a te. Il tempo non deve essere fermato… deve essere vissuto. Grazie. — Elias Voss, che ha scelto di ricordare."*

---

## 14.2 Versione B — Via dell'Equilibrio (Karma Neutro)

*[Pagine 1-4 simili alla versione A con variazioni minori]*

**Pagina 5:** *"Sara è fuggita. L'ho cercata per giorni, ma alla fine ho lasciato che andasse. Forse aveva ragione lei. Forse avrei dovuto lasciare andare anche la clessidra."*

**Pagina 9:** *"Stanotte il sogno è cambiato. Sara mi ha voltato le spalle. Non mi ha parlato. Ho capito che sto perdendo anche l'ultimo legame con lei."*

**Pagina 10:** *"Se stai leggendo questo, significa che hai camminato sul confine tra salvezza e distruzione. Non so se hai fatto la scelta giusta. Io non so più quale fosse la scelta giusta. Di' a Sara… che suo padre ha provato. Anche se ha fallito. — Elias Voss, sospeso tra due tempi."*

---

## 14.3 Versione C — Via della Follia (Karma Basso)

*[Pagine 1-3 invariate]*

**Pagina 4:** *"Sara ha cercato di distruggere la clessidra. L'ho colpita per la prima volta nella mia vita. Non ho provato rimorso. Solo chiarezza. Il dolore è un'interferenza. Devo eliminarla."*

**Pagina 5:** *"Sara è morta tentando di fuggire dal tempo. Bene. Ora nulla mi lega più a questo mondo mortale. La sua scelta era stupida. La mia è necessaria."*

**Pagina 9:** *"Stanotte ho sognato Sara. Le ho riso in faccia. Il domani non esiste più. Presto non esisterà più nemmeno il ricordo di lei."*

**Pagina 10:** *"Se stai leggendo queste parole, significa che hai seguito la mia stessa strada. Hai scelto il potere invece dell'amore. Non c'è più redenzione per noi. Il tempo è già morto. E noi lo abbiamo ucciso insieme. — Elias Voss, Arciprete del Tempo, che ha vinto… e ha perso tutto."*

---

---

# SEZIONE 15 — AUDIO & HAPTIC DESIGN

## 15.1 Architettura Audio — Sistema Adattivo

Il motore audio di Kronos Fight usa un sistema a **layer dinamici**. Ogni livello ha una traccia base + 4-6 layer aggiuntivi che si attivano/disattivano in base al gameplay.

**Layer Audio per Livello:**

| Layer | Trigger | Esempio |
|-------|---------|---------|
| Base Ambientale | Sempre attivo | Vento desertico, gocce paludi |
| Combat Layer | Combattimento attivo | Drum aggiunti, bassi più profondi |
| Boss Layer | Boss in arena | Tema boss completo |
| Low HP Layer | HP < 30% | Musica più tesa, heart beat |
| Skin Layer | Skin equipaggiata | Suoni sostitutivi completi |
| Emotional Layer | Dialogo importante | Volume ambientale scende, voce in primo piano |

---

## 15.2 Temi Musicali per Atto

| Atto | Stile | Strumenti Chiave | BPM |
|------|-------|-----------------|-----|
| I (Liv. 1-3) | Western Dark + Dissonanza Elettronica | Chitarra slide, synth distorto | 80-100 |
| II (Liv. 4-6) | Industrial Gotico | Organo distorto, batteria industriale | 100-120 |
| III (Liv. 7-9) | Ambient Horror | Gregoriano deformato, glitch elettronico | 60-90 |
| IV (Liv. 10-12) | Industrial Metal + Glitch Orchestrale | Metal distorto, orchestra sinfonica glitchata | 130-160 |
| V (Liv. 13) | Pianoforte → Metal Sinfonico Completo | Piano solo → orchestra + metal + cori | 40 → 160 |

**Temi Iconici:**
- *"Rage of the Timeless"* — tema del Sacrificio di Clock. Cori epici + batteria doppia
- *"Elias"* — tema del Monastero Segreto. Piano solo, nessun altro strumento
- *"The Last Bark"* — tema del True Ending. Piano + orchestra + singolo abbaio alla fine

---

## 15.3 Haptic Design Completo

| Evento | Pattern | Intensità | Durata |
|--------|---------|-----------|--------|
| Passo normale | Impulso singolo [20ms] | Leggera | 20ms |
| Passo Skin Cyborg | Impulso pesante [50ms] | Media | 50ms |
| Passo Skin Scheletro | Doppio impulso [20ms+20ms] | Leggera | 40ms |
| Colpo inferto (standard) | [80ms, 20ms, 80ms] | Media | 180ms |
| Colpo inferto (Critico) | [200ms, 50ms, 200ms] | Forte | 450ms |
| Colpo subito (standard) | [150ms, 80ms, 150ms] | Media-Forte | 380ms |
| Colpo subito (One-shot) | [500ms continuo] | Fortissima | 500ms |
| Abbaio di Clock (alert) | [30ms] singolo | Leggera | 30ms |
| Sacrificio di Clock | Silenzio 2s → [400ms] unico | Fortissima | 400ms |
| Gravity-flip | Vibrazione continua crescente 0.8s | Media → Forte | 800ms |
| QTE colpo di grazia | Crescente per 5s [pattern accelerante] → stop netto | Fortissima → Silenzio | 5s + 0 |
| Raccolta Shard (standard) | [10ms] brevissimo | Leggerissima | 10ms |
| Raccolta Shard (Skin Divinità) | [20ms] con risonanza | Leggera | 30ms |
| True Ending — abbaio Kronos | Vibrazione lunga profonda 3s | Fortissima | 3s |

---

---

# SEZIONE 16 — UI/UX & HUD DESIGN

## 16.1 HUD in-game — Principio Minimalista

Il HUD di Kronos Fight segue il principio **"vedi solo ciò che serve in quel momento"**.

**Elementi Sempre Visibili:**
- Barra LIFE (sinistra, verde → rosso)
- Barra ANIMA (sinistra, sotto LIFE, viola)
- Icona Clock (angolo, con stato emotivo)
- Contatore Shard (angolo destro)

**Elementi Contestuali (appaiono solo quando rilevanti):**
- Barra HP Boss (appare quando il boss entra in arena)
- Timer Omega Mode (appare durante Omega Mode)
- Barra Sinergia Dual Hero (appare quando > 50%)
- Warning Sabbia Mobile (bordi dello schermo)
- Indicatore Nemico alle Spalle (bordo scuro)

**Elementi HUD in Skin:**
- Con Skin Divinità del Tempo: tutti gli elementi HUD hanno bordo dorato sottile
- Con Skin Scheletro Coscienza: la barra Anima diventa viola intenso con particelle ossee
- Con Skin Ken Fantasma: la barra Anima di Ken ha effetto scanline CRT

---

## 16.2 Schermata HUB — Layout

```
┌─────────────────────────────────────────────────────────┐
│  REGNO DEL TEMPO — HUB                    [Impostazioni]│
├──────────────┬──────────────────────────┬───────────────┤
│   MAPPA      │   VILLAGGIO (centro)      │  EROI         │
│   REGNO      │   [animazione live]       │  ASH          │
│   DEL TEMPO  │                          │  KEN          │
│              │   [Clock nella cuccia]    │               │
│   ◎ Attuale  │   [NPC visibili]         │  NPC ALLEATI  │
│   ○ Sbloccato│                          │  Monaco       │
│   × Bloccato │                          │  Fabbro       │
│              │                          │  Libraio      │
├──────────────┴──────────────────────────┤  Alchimista   │
│   LIBRERIA SHARD (a scorrimento)        │  Veggente     │
│   [Slot upgrade] [Slot upgrade] [...]   ├───────────────┤
├─────────────────────────────────────────┤  BESTIARIO    │
│  LIFE: [████████████]  ANIMA: [=======]│  [sbloccati]  │
└─────────────────────────────────────────┴───────────────┘
```

---

---

# SEZIONE 17 — META DESIGN, KPI & BUSINESS STRATEGY

## 17.1 Player Psychology Loop

```
┌──────────────────────────────────────────────────────┐
│                  LOOP PRIMARIO                        │
│                                                      │
│  COMBATTIMENTO → DISORIENTAMENTO → ADATTAMENTO → RICOMPENSA
│        ↑                                      │      │
│        └──────────── FALLIMENTO ──────────────┘      │
│                         ↓                            │
│                    TIME REWIND                       │
│                    (AdMob / IAP)                     │
└──────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────┐
│                  LOOP SECONDARIO                     │
│                                                      │
│  PADRONANZA → ORGOGLIO → SOCIAL SHARE → NUOVI UTENTI │
│      ↑                                    │          │
│      └──────── CLASSIFICHE ───────────────┘          │
└──────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────┐
│                  LOOP EMOTIVO                        │
│                                                      │
│  STORIA → EMPATIA → INVESTIMENTO → RETENTION        │
│    ↑                                    │            │
│    └──────────── CLOCK ────────────────┘             │
└──────────────────────────────────────────────────────┘
```

---

## 17.2 Target Demographics

| Segmento | Età | Profilo | Attrattore |
|---------|-----|---------|-----------|
| **Primary** | 18-35 | Gamer mobile avanzato, fan pixel art/dark fantasy | Boss design, narrativa, sfida |
| **Secondary** | 14-18 | Fan anime/shonen, casual gamer | Skin, personaggi, combattimento visivo |
| **Tertiary** | 35-50 | Ex-gamer, bassa disponibilità di tempo | Narrative emotiva, sessioni brevi, storia di Clock |
| **Niche** | Tutti | Completionisti | 13 Sigilli, 10 Prigionieri, diario variante |

---

## 17.3 KPI Target

| Metrica | Target Mese 1 | Target Mese 6 | Metodo |
|---------|--------------|--------------|--------|
| D1 Retention | 45% | 50% | Tutorial fluido, Clock sblocco immediato |
| D7 Retention | 25% | 30% | Daily Reward Sara, narrative hook |
| D30 Retention | 12% | 18% | Battle Pass, classifiche, NG+ |
| ARPU | €0.80 | €1.20 | IAP bilanciati, AdMob organico |
| Session Length | 15 min | 20 min | Livelli calibrati 20-30 min |
| Sessions/Day | 2.5 | 3.0 | Daily reward, push notification |
| Store Rating | 4.3 | 4.6 | No pay-to-win, bug fix rapido |
| Social Share Rate | 8% | 15% | Card automatica fine livello |

---

## 17.4 Curva di Apprendimento Definitiva

| Livello | Meccanica Principale | Skill Richiesta | Difficoltà |
|---------|---------------------|-----------------|------------|
| 1 | Corsa, salto, combo base | Coordinazione | ★☆☆☆☆ |
| 2 | Switch personaggio, interruttori | Multi-tasking | ★★☆☆☆ |
| 3 | Aura Ken, boss timing | Timing preciso | ★★★☆☆ |
| 4 | Piattaforme magnetiche | Mobilità spaziale | ★★★☆☆ |
| 5 | Riflessi cristallini, boss multi-fase | Adattamento tattico | ★★★★☆ |
| 6 | Stealth, attacchi alle spalle | Ascolto + anticipazione | ★★★★☆ |
| 7 | Nemici che si bufano | Prioritizzazione | ★★★★☆ |
| 8 | Inversione comandi, boss emotivo | Resilienza psicologica | ★★★★★ |
| 9 | Veleno Anima, terrain hazard | Gestione risorse | ★★★★★ |
| 10 | Gravity-flip, zero-G combat | Orientamento 3D | ★★★★★+ |
| 11 | Pozioni paradosso, ruoli invertiti | Flessibilità | ★★★★★+ |
| 12 | Echo loops, tutto contemporaneamente | Memoria + pattern | MAX |
| 13 | Tutto + Dual Sync permanente | Mastery totale | LEGGENDARIA |

---

## 17.5 Punti di Differenziazione — Perché Kronos Fight Vince

**1. La Narrativa Emotiva è il Prodotto, Non il Packaging**  
La maggior parte dei mobile action RPG usa la storia come pretesto. Kronos Fight *è* la storia di Sara e Elias, servita attraverso il gameplay. Il giocatore non smette di giocare perché vuole l'upgrade — smette perché vuole sapere cosa succede a Clock.

**2. La Monetizzazione Non Interrompe l'Immersione**  
In un mercato saturo di popup e banner, Kronos Fight integra ogni punto di monetizzazione nella narrativa. Il giocatore non si sente "venduto a" — si sente parte di un sistema coerente.

**3. Le Skin Sono Esperienze, Non Cosmetici**  
Ogni skin cambia audio, particelle, meccaniche di morte. Comprarla non è spendere soldi su un'immagine — è comprare un modo diverso di giocare lo stesso gioco.

**4. Clock**  
Il design di Clock è calcolato per creare attaccamento emotivo reale. Non è manipolazione — è storytelling fatto bene. E il Sacrificio, quando arriva, è il momento di cui tutti i giocatori parleranno sui social.

**5. La Rigiocabilità è Narrativa, Non Solo Meccanica**  
Il Diario che cambia, gli ending multipli, il Monastero Segreto — il giocatore ha una ragione narrativa per fare il secondo playthrough, non solo meccanica (NG+, skin, classifiche — ci sono anche quelle, ma non sono l'unica ragione).

---

## 17.6 Roadmap Post-Launch

| Periodo | Update | Contenuto |
|---------|--------|-----------|
| Mese 1 | Patch 1.1 | Bug fix, bilanciamento boss, ottimizzazione |
| Mese 2 | Update "L'Eco del Culto" | 3 livelli bonus post-game, nuovo NPC |
| Mese 3 | Battle Pass Stagione 2 | "Era del Ghiaccio Temporale" — 30 livelli nuovi cosmetici |
| Mese 4 | Update "La Lettera" | Espansione Monastero Segreto, 5 dialoghi Sara inediti |
| Mese 6 | Espansione "Il Quarto Erede" | Nuovo personaggio giocabile, 3 livelli, nuova skin |

---

*Fine Documento — Kronos Fight: Chronos Protocol Omega v3.0*

---

**"Il tempo non ti appartiene. Ma puoi combatterlo."**  
**— KRONOS FIGHT —**

---
*Documento di Design Completo — Tutte le sezioni, personaggi, sistemi, boss, livelli, dialoghi, skin, ending e meccaniche sono integrati e production-ready.*  
*Versione 3.0 — Enriched Master Edition*
