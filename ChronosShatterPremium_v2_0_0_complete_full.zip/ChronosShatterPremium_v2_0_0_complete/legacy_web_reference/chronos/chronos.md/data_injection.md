Claude, analizza questo materiale /DATA_INJECTION. Estrai lo stile del tratto, la palette cromatica e il dinamismo delle inquadrature. Voglio che l'ambiente 'Cyber-Hokuto Punk' rifletta questa sporcizia post-apocalittica e la maestosità delle rovine. Usa questo stile per definire come gli Shader devono distorcere la luce e come i nemici devono muoversi (es. movimenti a scatti, ombre lunghe)."

🚫 NO SHOP MODERNI (Gacha/Microtransazioni)

Siamo d'accordo al 100%. Il Miliardmentalist Game è un'opera d'arte, non un centro commerciale.

    Logica Old School: Niente tasti "Compra Monete" o "Energia Limitata".

    Progressione Pura: Se vuoi una spada più forte, devi battere un boss o trovarla in un tempio nascosto.

    Shop Narrativo: Lo "Shop" deve essere un PNG misterioso (es. un vecchio eremita o un mercante robotico rotto) che scambia oggetti per "Scrap Metal" o "Ki-Essence" trovati in gioco. È parte della storia, non del marketing.
    percorsi da guardare per SPRITE:
/home/locoomo/Scrivania/CHRONOSO_GAME/assets/images/sprite/ 
