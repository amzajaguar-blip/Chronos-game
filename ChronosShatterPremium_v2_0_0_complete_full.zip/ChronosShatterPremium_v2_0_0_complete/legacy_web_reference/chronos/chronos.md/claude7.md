EPIC AUDIO ENGINE (DYNAMO-SOUND)

    Implementa una classe AudioManager che gestisca il cross-fade tra i brani.

    Soundscapes: Crea descrizioni dettagliate (prompt audio) per musiche in stile 'Cyber-Orchestral Post-Apocalyptic'.

    Adaptive Music: La traccia deve aumentare di BPM (battiti al minuto) proporzionalmente alla KillStreak di Kairo.

    SFX Shader: Sincronizza i colpi della combo (Z, X, C) con suoni impattanti 'Heavy Metal Crush'. Ogni colpo critico deve attivare un effetto di riverbero 'Reverse Reverb' per dare profondità.

    Mossa Segreta: Durante i 7 tocchi delle stelle, ogni tocco deve emettere una nota di una scala minore armoniva, culminando in un coro celestiale nell'esplosione finale."
