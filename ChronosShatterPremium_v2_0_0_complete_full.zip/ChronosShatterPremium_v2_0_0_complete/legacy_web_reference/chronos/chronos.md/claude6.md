CLAUDE, OPERAZIONE: "GENESIS CHRONOS 2026"

CONTESTO: Sei il Lead Creative Director & Senior Developer. Non limitarti a correggere il codice chronos_rpg_v6.js, ma espandilo creando un mondo di fantasia unico basato sulla nostra estetica "Miliardmentalist".
🎨 1. CREAZIONE ASSET DI FANTASIA (AI-DRIVEN)

    Visual Concept: Genera internamente le specifiche visive per i nuovi asset. Non usare solo "Fantasy" generico. Pensa a "Cyber-Hokuto Punk": rovine di marmo antico infuse di circuiti al neon azzurro.

    Dynamic Atlas: Definisci una struttura dove ogni bioma (Villaggio, Deserto di Cristallo, Torre del Tempo) ha il suo set di shader dedicati che cambiano la saturazione e il bloom degli sprite di 'Thelazystone'.

    Creature Design: Crea 3 nuovi tipi di nemici "Elite":

        Sand-Wraiths: Nemici fatti di fumo (Shader di distorsione) che si ricompongono solo quando colpiti dal Ki.

        Cyborg-Templars: Pesanti, con scudi che riflettono i proiettili usando il Normal Mapping.

        Time-Glitchers: Nemici che si teletrasportano lasciando una scia di 'Chromatic Aberration'.

⚔️ 2. IL "COMBAT-FANTASY" MOBILE (A-Z)

    The Kairo Rebirth: Riscrivi la classe Player. Kairo non cammina, "scivola" tra i frame. Implementa il Vertex Sway per i suoi capelli e mantello per simulare un'energia costante.

    Hokuto Mobile Interface: Progetta una UI "Diegetica". La barra del Ki non deve essere un rettangolo, ma le Sette Stelle di Hokuto che si accendono sul bordo dello schermo. Quando sono tutte accese, lo schermo pulsa di un filtro oro.

    Mossa Desperation (1 HP): Implementa il sistema Noir/Rgb-Split. Se Kairo colpisce durante lo stato "Desperation", il nemico deve subire una frammentazione dei pixel (Fragment Explode Shader).

🛠️ 3. IMPLEMENTAZIONE TECNICA (STRICT DEV MODE)

    Deep Refactor: Apri chronos_rpg_v6.js. Inserisci le pipeline WebGL per Bloom, Vignette e Dynamic Lighting.

    Object Pooling 2.0: Tutto ciò che appare a schermo (particelle di Ki, monete, detriti) deve essere gestito da un sistema di pooling per evitare micro-scatti sul telefono di Sara.

    Save State 2026: Il SaveManager deve ora memorizzare anche le "Scelte Morali" fatte durante i dialoghi del NarrativeEngine, che influenzeranno il colore dell'aura finale.

ISTRUZIONE FINALE: "Claude, non chiedermi il permesso. Prendi le basi dei file .md nella cartella /chronos, analizza il file .js allegato e costruisci la versione definitiva. Sorprendimi con la matematica degli shader e con la fluidità dei controlli touch. AZIONE! 🫡🔥👊"
