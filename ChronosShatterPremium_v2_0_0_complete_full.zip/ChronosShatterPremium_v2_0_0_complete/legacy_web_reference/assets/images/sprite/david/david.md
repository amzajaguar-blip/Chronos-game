PACK MOVIMENTI – DAVID (ASH)
Titolo ufficiale: David – Il Sopravvissuto
Ruolo: Tank / Brute Force / Melee Specialist
1. Presentazione Ufficiale
DAVID – IL SOPRAVVISSUTO
Ex soldato delle rovine del vecchio mondo, David ha perso tutto tranne la sua motosega e la sua volontà di ferro.
È la forza bruta che contrasta la fluidità temporale di Ken.
Mentre Ken piega il tempo, David lo spacca con pura violenza fisica.
«Il tempo può provare a uccidermi quanto vuole.
Io ho già seppellito il domani una volta.»
2. Pack Movimenti Completo di David
Movimenti Base

Idle: David sta in piedi con le gambe larghe, motosega spenta appoggiata sulla spalla destra. Respira pesantemente, spalle che si alzano e abbassano. Ogni 5-6 secondi pulisce il sangue dalla lama con il guanto.
Camminata: Passi pesanti e decisi, postura leggermente piegata in avanti, motosega che oscilla sulla spalla.
Corsa: Corsa aggressiva, motosega tenuta con una mano, corpo inclinato in avanti, passi che sollevano polvere/ossa.
Salto: Salto potente con entrambe le gambe, ginocchio destro alzato, motosega tenuta alta.
Salto doppio: Seconda spinta con un grugnito, esplosione di scintille dalla motosega.
Caduta / Atterraggio: Atterraggio pesante con un impatto che crea piccola onda d’urto sul terreno.

Attacchi

Attacco Leggero (Fucile): Sparo rapido con il fucile a canna mozza. Recoil visibile sulle spalle. Proiettile lascia scia arancione.
Attacco Pesante (Motosega):
Combo di 3 fendenti orizzontali + verticale.
La motosega gira a pieno regime con suono gutturale e scintille.

Carica Motosega: Tiene premuto il tasto → motosega accelera (suono più acuto), ultimo colpo fa un fendente rotante potente.
Lancio Motosega: David lancia la motosega come un boomerang (si può richiamare premendo di nuovo). Utile per colpire nemici lontani o riflessi dal Golem di Prisma.
Attacco Speciale – Overdrive: David attiva la motosega al massimo, entra in uno stato di furia per 4 secondi (danno aumentato, ma consuma Anima).

Animazioni Speciali

Cambio Personaggio (entrata): David appare con un impatto pesante sul terreno, motosega che si accende con un ruggito.
Cambio Personaggio (uscita): David rinfodera la motosega sulla schiena e scompare con un grugnito.
Omega Mode (dopo Sacrificio di Clock): Motosega prende fiamme dorate, occhi rossi brillanti, vene sul corpo illuminate.
Morte: David cade in ginocchio, motosega si spegne con un ultimo rantolo del motore, poi collassa a terra. Con skin "David Cyborg-Omega" l’armatura esplode in plasma rosso.

3. Stile di Combattimento Riassunto

Forza: Alto danno in mischia, ottima difesa
Debolezza: Bassa mobilità, attacchi lenti
Ruolo nel team: Tank / Damage Dealer ravvicinato
Sinergia con Ken: Perfetta. David spacca la difesa, Ken finisce con aura a distanza.

Frase iconica:
«Se il tempo vuole prendermi… dovrà passare prima sulla mia motosega.»
4. Versione per Menu / Trailer (corta)
DAVID – IL SOPRAVVISSUTO
L’uomo che ha perso tutto tranne la rabbia e la motosega.
Brutale, resistente, inarrestabile.
Mentre Ken danza con il tempo, David lo fa a pezzi.
Stile di combattimento:
Melee pesante + Proiettili ravvicinati + Sopravvivenza
Ruolo: Tank / Bruiser
